Bamboo drop-in (no invented leaves)
Unzip into the PROJECT ROOT (the folder with build.gradle) and overwrite. Only these files are included:
- models/block/_bampl.json : original 16 elements of the 1.12.2 model + a closed top (5 "up" faces using the 4x4 pole end texture of each species (bamboo_<species>_pole_end, the filling you liked)). No extra leaf planes.
- models/block/bamboo_<species>_s0..s4.json (45) : parent _bampl, textures m (segment) and e (end cap).
- textures/block/bamboo_<species>_s0..s4.png and bamboo_<species>_pole_end.png : the original stalk/leaf textures and the pole end textures.
Delete these if they still exist in your project (they are the leaves I made up):
- src/main/resources/assets/pmp_mikexxx/models/block/_bampl_top.json
- src/main/resources/assets/pmp_mikexxx/textures/block/bamboo_*_crown.png

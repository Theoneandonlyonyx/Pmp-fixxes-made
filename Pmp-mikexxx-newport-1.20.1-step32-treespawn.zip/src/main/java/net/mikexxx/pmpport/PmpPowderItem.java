package net.mikexxx.pmpport;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.FluidTags;
import net.minecraft.tags.TagKey;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraftforge.registries.ForgeRegistries;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;

/**
 * The plant powders. Every kind does something when used on a block (aloe: right-click in the air):
 * fern / cactus / coral / mushroom / poison mushroom powder scatter plants like bone meal does grass,
 * defoliant kills plants, fertilizer is a stronger bone meal, moss powder mosses stone, conditioner improves soil,
 * berry powder ripens fruit, leaf powder grows saplings, aloe powder heals. Brewing: see PmpBrewing.
 */
public class PmpPowderItem extends PmpItem {
    public enum Kind { FERN, CACTUS, CORAL, MUSHROOM, MUSHROOM_POISON, DEFOLIANT, FERTILIZER, MOSS, CONDITIONER, BERRY, LEAF, ALOE }

    private final Kind kind;

    public PmpPowderItem(Properties p, int color, String latin, Kind kind) {
        super(p, color, latin);
        this.kind = kind;
    }

    @Nullable
    public static Kind kindOf(String id) {
        return switch (id) {
            case "item_powder_fern" -> Kind.FERN;
            case "item_powder_cactus" -> Kind.CACTUS;
            case "item_powder_coral" -> Kind.CORAL;
            case "item_powder_defoliant" -> Kind.DEFOLIANT;
            case "item_powder_fertilizer" -> Kind.FERTILIZER;
            case "item_powder_moss" -> Kind.MOSS;
            case "item_powder_conditioner" -> Kind.CONDITIONER;
            default -> null;
        };
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tip, TooltipFlag flag) {
        super.appendHoverText(stack, level, tip, flag);
        tip.add(Component.translatable("tooltip." + PmpMod.MODID + ".powder." + kind.name().toLowerCase()).withStyle(net.minecraft.ChatFormatting.DARK_GRAY));
    }

    // ------------------------------------------------------------------ use

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        if (kind == Kind.ALOE) return InteractionResult.PASS; // aloe works in the air (use)
        if (level.isClientSide) return InteractionResult.SUCCESS;
        ServerLevel sl = (ServerLevel) level;
        BlockPos pos = ctx.getClickedPos();
        Direction face = ctx.getClickedFace();
        boolean done = switch (kind) {
            case FERN -> scatter(sl, pos, face, pool("powder_fern", b -> b instanceof PlantBlock || b == Blocks.FERN || b == Blocks.LARGE_FERN), false);
            case CACTUS -> scatter(sl, pos, face, pool("powder_cactus", b -> b instanceof PlantBlock), false);
            case MUSHROOM -> mushrooms(sl, pos, face, "powder_mushroom");
            case MUSHROOM_POISON -> mushrooms(sl, pos, face, "powder_mushroom_poison");
            case CORAL -> scatter(sl, pos, face, pool("powder_coral", b -> b instanceof PlantBlock || b instanceof BaseCoralPlantTypeBlock), true);
            case DEFOLIANT -> defoliate(sl, pos);
            case FERTILIZER -> fertilize(sl, pos);
            case MOSS -> moss(sl, pos);
            case CONDITIONER -> condition(sl, pos);
            case BERRY -> ripen(sl, pos);
            case LEAF -> saplings(sl, pos);
            default -> false;
        };
        if (!done) return InteractionResult.PASS;
        Player pl = ctx.getPlayer();
        if (pl == null || !pl.getAbilities().instabuild) ctx.getItemInHand().shrink(1);
        return InteractionResult.CONSUME;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (kind != Kind.ALOE) return InteractionResultHolder.pass(stack);
        if (!level.isClientSide) {
            player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 0));
            player.clearFire();
            level.playSound(null, player.blockPosition(), SoundEvents.SLIME_SQUISH_SMALL, SoundSource.PLAYERS, 1.0F, 1.2F);
            if (!player.getAbilities().instabuild) stack.shrink(1);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    // ------------------------------------------------------------------ plants from an item tag

    private static List<Block> pool(String tagName, Predicate<Block> ok) {
        List<Block> out = new ArrayList<>();
        TagKey<Item> tag = TagKey.create(Registries.ITEM, new ResourceLocation(PmpMod.MODID, tagName));
        var tags = ForgeRegistries.ITEMS.tags();
        if (tags == null) return out;
        for (Item it : tags.getTag(tag)) {
            Block b = Block.byItem(it);
            if (b != Blocks.AIR && ok.test(b) && !out.contains(b)) out.add(b);
        }
        return out;
    }

    private static BlockState stateFor(Block b, RandomSource r) {
        BlockState s = b.defaultBlockState();
        if (b instanceof PlantBlock pb && s.hasProperty(PlantBlock.STAGE)) {
            int max = Math.max(0, pb.maxStage());
            s = s.setValue(PlantBlock.STAGE, Math.max(0, max - (max > 1 ? r.nextInt(2) : 0))); // grown, sometimes one stage younger
        }
        return s;
    }

    private static boolean putPlant(ServerLevel level, BlockPos p, Block b, BlockState s) {
        if (b instanceof PlantBlock pb) return pb.placeGen(level, p, s);
        if (b instanceof DoublePlantBlock) {
            if (!level.isEmptyBlock(p.above())) return false;
            DoublePlantBlock.placeAt(level, s, p, 3);
            return true;
        }
        level.setBlock(p, s, 3);
        return true;
    }

    /** like bone meal on grass: tries a number of spots around the clicked block and puts random plants of the list on them */
    private boolean scatter(ServerLevel level, BlockPos clicked, Direction face, List<Block> plants, boolean water) {
        if (plants.isEmpty()) return false;
        RandomSource r = level.random;
        BlockPos c = clicked.relative(face);
        if (water && !level.getFluidState(c).is(FluidTags.WATER) && !level.getFluidState(clicked).is(FluidTags.WATER)) return false;
        if (water && !level.getFluidState(c).is(FluidTags.WATER)) c = clicked;
        int placed = 0;
        for (int i = 0; i < 40 && placed < 7; i++) {
            BlockPos p = c.offset(r.nextInt(7) - 3, r.nextInt(3) - 1, r.nextInt(7) - 3);
            BlockState here = level.getBlockState(p);
            if (water) {
                if (!here.is(Blocks.WATER) || !level.getFluidState(p).isSource()) continue;
            } else if (!here.isAir() && !(here.canBeReplaced() && level.getFluidState(p).isEmpty())) continue;
            Block b = plants.get(r.nextInt(plants.size()));
            BlockState s = stateFor(b, r);
            if (water && s.hasProperty(BlockStateProperties.WATERLOGGED)) s = s.setValue(BlockStateProperties.WATERLOGGED, true);
            if (!s.canSurvive(level, p)) continue;
            if (putPlant(level, p, b, s)) placed++;
        }
        if (placed > 0) level.levelEvent(1505, c, 15);
        return placed > 0;
    }

    private boolean mushrooms(ServerLevel level, BlockPos clicked, Direction face, String tag) {
        BlockState cs = level.getBlockState(clicked);
        // a small vanilla mushroom grows into a huge one, like with bone meal
        if (cs.getBlock() instanceof MushroomBlock mb && mb.isValidBonemealTarget(level, clicked, cs, false)) {
            mb.performBonemeal(level, level.random, clicked, cs);
            level.levelEvent(1505, clicked, 15);
            return true;
        }
        return scatter(level, clicked, face, pool(tag, b -> b instanceof PlantBlock || b == Blocks.BROWN_MUSHROOM || b == Blocks.RED_MUSHROOM), false);
    }

    // ------------------------------------------------------------------ defoliant

    private static boolean isPlant(Block b) {
        return b instanceof BushBlock || b instanceof VineBlock || b instanceof LeavesBlock || b instanceof GrowingPlantBlock
                || b instanceof CactusBlock || b instanceof SugarCaneBlock
                || b instanceof ClimbingPlantBlock || b instanceof HangingPlantBlock || b instanceof EpiphyteBlock || b instanceof EpiphyteFloorBlock
                || b instanceof WaterPlantBlock || b instanceof TreeFruitBlock || b instanceof BambooStalkBlock;
    }

    /** kills every plant around (leaves, flowers, crops, vines, kelp ...), grass blocks become dirt. Plants drop what they drop without a tool: grass blocks nothing, shear-only drops nothing */
    private boolean defoliate(ServerLevel level, BlockPos c) {
        int n = 0;
        for (int dx = -3; dx <= 3; dx++) for (int dy = -2; dy <= 3; dy++) for (int dz = -3; dz <= 3; dz++) {
            BlockPos p = c.offset(dx, dy, dz);
            BlockState s = level.getBlockState(p);
            Block b = s.getBlock();
            if (b == Blocks.GRASS_BLOCK) {
                level.setBlock(p, Blocks.DIRT.defaultBlockState(), 3);
                n++;
            } else if (isPlant(b)) {
                Block.dropResources(s, level, p);
                level.setBlock(p, s.getFluidState().createLegacyBlock(), 3);
                n++;
            }
        }
        if (n > 0) level.playSound(null, c, SoundEvents.GRASS_BREAK, SoundSource.BLOCKS, 1.0F, 0.7F);
        return n > 0;
    }

    // ------------------------------------------------------------------ fertilizer, berry, leaf (bone meal on a small area)

    private static boolean grow(ServerLevel level, BlockPos p, BlockState s) {
        if (s.getBlock() instanceof BonemealableBlock bm && bm.isValidBonemealTarget(level, p, s, false)) {
            if (bm.isBonemealSuccess(level, level.random, p, s)) bm.performBonemeal(level, level.random, p, s);
            return true;
        }
        return false;
    }

    /** bone meal alternative: everything that can grow within 2 blocks gets one bone meal (grass: only the clicked block) */
    private boolean fertilize(ServerLevel level, BlockPos c) {
        int n = 0;
        BlockState cs = level.getBlockState(c);
        if (grow(level, c, cs)) n++;
        for (int dx = -2; dx <= 2; dx++) for (int dy = -1; dy <= 1; dy++) for (int dz = -2; dz <= 2; dz++) {
            BlockPos p = c.offset(dx, dy, dz);
            if (p.equals(c)) continue;
            BlockState s = level.getBlockState(p);
            if (s.is(Blocks.GRASS_BLOCK)) continue;
            if (grow(level, p, s)) n++;
        }
        if (n > 0) level.levelEvent(1505, c, 15);
        return n > 0;
    }

    private boolean ripen(ServerLevel level, BlockPos c) {
        int n = 0;
        for (int dx = -2; dx <= 2; dx++) for (int dy = -2; dy <= 2; dy++) for (int dz = -2; dz <= 2; dz++) {
            BlockPos p = c.offset(dx, dy, dz);
            BlockState s = level.getBlockState(p);
            Block b = s.getBlock();
            boolean fruit = b instanceof SweetBerryBushBlock || b instanceof CaveVines || b instanceof TreeFruitBlock
                    || (b instanceof PlantBlock pb && pb.harvest != null);
            if (fruit && grow(level, p, s)) n++;
        }
        if (n > 0) level.levelEvent(1505, c, 15);
        return n > 0;
    }

    private boolean saplings(ServerLevel level, BlockPos c) {
        int n = 0;
        for (int dx = -2; dx <= 2; dx++) for (int dy = -1; dy <= 2; dy++) for (int dz = -2; dz <= 2; dz++) {
            BlockPos p = c.offset(dx, dy, dz);
            BlockState s = level.getBlockState(p);
            if (s.getBlock() instanceof SaplingBlock || s.getBlock() instanceof SaplingTreeBlock) {
                for (int k = 0; k < 2; k++) { // the first round only advances the sapling, the second one can grow the tree
                    BlockState cur = level.getBlockState(p);
                    if (!(cur.getBlock() instanceof BonemealableBlock) || !grow(level, p, cur)) break;
                }
                n++;
            }
        }
        if (n > 0) level.levelEvent(1505, c, 15);
        return n > 0;
    }

    // ------------------------------------------------------------------ moss

    private static final Map<Block, Block> MOSSY = Map.ofEntries(
            Map.entry(Blocks.COBBLESTONE, Blocks.MOSSY_COBBLESTONE), Map.entry(Blocks.COBBLESTONE_SLAB, Blocks.MOSSY_COBBLESTONE_SLAB),
            Map.entry(Blocks.COBBLESTONE_STAIRS, Blocks.MOSSY_COBBLESTONE_STAIRS), Map.entry(Blocks.COBBLESTONE_WALL, Blocks.MOSSY_COBBLESTONE_WALL),
            Map.entry(Blocks.STONE_BRICKS, Blocks.MOSSY_STONE_BRICKS), Map.entry(Blocks.STONE_BRICK_SLAB, Blocks.MOSSY_STONE_BRICK_SLAB),
            Map.entry(Blocks.STONE_BRICK_STAIRS, Blocks.MOSSY_STONE_BRICK_STAIRS), Map.entry(Blocks.STONE_BRICK_WALL, Blocks.MOSSY_STONE_BRICK_WALL));

    private static <T extends Comparable<T>> BlockState copyProp(BlockState from, BlockState to, Property<T> prop) {
        return to.hasProperty(prop) ? to.setValue(prop, from.getValue(prop)) : to;
    }

    private static BlockState transfer(BlockState from, Block target) {
        BlockState to = target.defaultBlockState();
        for (Property<?> pr : from.getProperties()) to = copyProp(from, to, pr);
        return to;
    }

    /** stone with a mossy variant (cobblestone, stone bricks, their slabs / stairs / walls) becomes mossy: the clicked block always, its neighbours with a 50 % chance */
    private boolean moss(ServerLevel level, BlockPos c) {
        int n = 0;
        for (int dx = -1; dx <= 1; dx++) for (int dy = -1; dy <= 1; dy++) for (int dz = -1; dz <= 1; dz++) {
            BlockPos p = c.offset(dx, dy, dz);
            if (!p.equals(c) && level.random.nextBoolean()) continue;
            BlockState s = level.getBlockState(p);
            Block m = MOSSY.get(s.getBlock());
            if (m != null) {
                level.setBlock(p, transfer(s, m), 3);
                n++;
            }
        }
        if (n > 0) level.levelEvent(1505, c, 15);
        return n > 0;
    }

    // ------------------------------------------------------------------ conditioner

    /** improves soil within 2 blocks: coarse dirt -> dirt, dirt under open sky -> grass, gravel -> coarse dirt, farmland gets fully wet */
    private boolean condition(ServerLevel level, BlockPos c) {
        int n = 0;
        for (int dx = -2; dx <= 2; dx++) for (int dy = -1; dy <= 1; dy++) for (int dz = -2; dz <= 2; dz++) {
            BlockPos p = c.offset(dx, dy, dz);
            BlockState s = level.getBlockState(p);
            Block b = s.getBlock();
            if (b == Blocks.COARSE_DIRT) { level.setBlock(p, Blocks.DIRT.defaultBlockState(), 3); n++; }
            else if (b == Blocks.GRAVEL) { level.setBlock(p, Blocks.COARSE_DIRT.defaultBlockState(), 3); n++; }
            else if (b == Blocks.DIRT && level.isEmptyBlock(p.above()) && level.canSeeSky(p.above())) { level.setBlock(p, Blocks.GRASS_BLOCK.defaultBlockState(), 3); n++; }
            else if (b instanceof FarmBlock && s.getValue(FarmBlock.MOISTURE) < 7) { level.setBlock(p, s.setValue(FarmBlock.MOISTURE, 7), 3); n++; }
        }
        if (n > 0) level.levelEvent(1505, c, 15);
        return n > 0;
    }
}

package net.mikexxx.pmpport;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * One shape per species, drawn after the render pictures of the original Plant Mega Pack trees (oaks, birches, spruces,
 * nut trees, acacias). Every tree rolls its own height, width and crown, so no two look the same.
 * Logs and leaves are collected first; a leaf is only placed where a log is at most 6 steps away, so the leaves decay
 * as usual when the tree is cut down.
 */
final class TreeShapes {
    private TreeShapes() {}

    private static final Direction[] HZ = {Direction.NORTH, Direction.EAST, Direction.SOUTH, Direction.WEST};

    static boolean free(BlockState s) {
        return s.isAir() || s.canBeReplaced() || s.is(BlockTags.LEAVES);
    }

    static boolean has(String key) {
        if (key.startsWith("leave_birch_wht")) return true;
        switch (key) {
            case "leave_oak_blue": case "leave_oak_engli": case "leave_oak_gray": case "leave_oak_japem":
            case "leave_spruc_black": case "leave_spruc_marti": case "leave_spruc_norwa": case "leave_spruc_red":
            case "leave_birch_chdwa": case "leave_birch_silve": case "leave_birch_water":
            case "leave_dkoak_bur": case "leave_dkoak_everg": case "leave_dkoak_itali": case "leave_dkoak_sessi":
            case "leave_nut_maya": case "leave_nut_pecan": case "leave_nut_pista": case "leave_nut_walnu":
            case "leave_nut_almon": case "leave_nut_brazi": case "leave_nut_butte": case "leave_nut_candl":
            case "leave_nut_cashe": case "leave_nut_gabon": case "leave_nut_hazel": case "leave_nut_macad":
            case "leave_acaci_baobo": case "leave_acaci_cucum": case "leave_acaci_rivbu": case "leave_acaci_whist":
                return true;
            default:
                return false;
        }
    }

    /** collects the logs and leaves of one tree */
    static final class B {
        final ServerLevel lv;
        final RandomSource r;
        final BlockPos base;
        final BlockState logS;
        BlockState leafS;
        final Map<BlockPos, BlockState> logs = new LinkedHashMap<>();
        final Set<BlockPos> leaves = new LinkedHashSet<>();

        B(ServerLevel lv, BlockPos base, Block log, Block leaf, RandomSource r) {
            this.lv = lv;
            this.base = base;
            this.r = r;
            this.logS = log.defaultBlockState();
            BlockState ls = leaf.defaultBlockState();
            if (ls.hasProperty(LeavesBlock.DISTANCE)) ls = ls.setValue(LeavesBlock.DISTANCE, 6);
            this.leafS = ls;
        }

        BlockPos at(int dx, int y, int dz) {
            return base.offset(dx, y, dz);
        }

        int rnd(int a, int b) {
            return a + r.nextInt(b - a + 1);
        }

        boolean chance(int pct) {
            return r.nextInt(100) < pct;
        }

        void log(BlockPos p) {
            logs.put(p.immutable(), logS);
        }

        void log(BlockPos p, Direction.Axis a) {
            logs.put(p.immutable(), logS.hasProperty(RotatedPillarBlock.AXIS) ? logS.setValue(RotatedPillarBlock.AXIS, a) : logS);
        }

        void trunk(int h) {
            for (int y = 0; y < h; y++) log(base.above(y));
        }

        void leaf(BlockPos p) {
            leaves.add(p.immutable());
        }

        /** horizontal branch of logs */
        void spoke(BlockPos from, Direction d, int len) {
            for (int i = 1; i <= len; i++) log(from.relative(d, i), d.getAxis());
        }

        /** branches in `count` different directions */
        void spokes(BlockPos from, int len, int count) {
            int start = r.nextInt(4);
            for (int i = 0; i < count && i < 4; i++) spoke(from, HZ[(start + i) % 4], len);
        }

        /** ellipsoid of leaves; `hole` > 0 leaves the inside empty (lacy crowns) */
        void blob(BlockPos c, double rx, double ry, double rz, int pct, double hole) {
            int ix = (int) Math.ceil(rx), iy = (int) Math.ceil(ry), iz = (int) Math.ceil(rz);
            for (int dx = -ix; dx <= ix; dx++)
                for (int dy = -iy; dy <= iy; dy++)
                    for (int dz = -iz; dz <= iz; dz++) {
                        double d = (dx * dx) / (rx * rx) + (dy * dy) / (ry * ry) + (dz * dz) / (rz * rz);
                        d += (r.nextDouble() - 0.5) * 0.4;
                        if (d > 1.0 || d < hole) continue;
                        if (pct < 100 && r.nextInt(100) >= pct) continue;
                        leaf(c.offset(dx, dy, dz));
                    }
        }

        /** round flat layer: square with trimmed corners */
        void disc(BlockPos c, int rad, int pct) {
            int lim = rad + (rad + 1) / 2;
            for (int dx = -rad; dx <= rad; dx++)
                for (int dz = -rad; dz <= rad; dz++) {
                    if (Math.abs(dx) + Math.abs(dz) > lim) continue;
                    if (pct < 100 && r.nextInt(100) >= pct) continue;
                    leaf(c.offset(dx, 0, dz));
                }
        }

        /** plus shaped layer */
        void cross(BlockPos c, int len) {
            leaf(c);
            for (Direction d : HZ) for (int i = 1; i <= len; i++) leaf(c.relative(d, i));
        }

        boolean onTrunk(BlockPos p) {
            return p.getX() == base.getX() && p.getZ() == base.getZ();
        }

        /** the trunk column has to be free, side logs are only placed where there is room */
        boolean placeLogs() {
            for (BlockPos p : logs.keySet()) {
                if (onTrunk(p) && !p.equals(base) && !free(lv.getBlockState(p))) return false;
            }
            for (Map.Entry<BlockPos, BlockState> e : logs.entrySet()) {
                BlockPos p = e.getKey();
                if (p.equals(base) || free(lv.getBlockState(p))) lv.setBlock(p, e.getValue(), 3);
            }
            return true;
        }

        void placeLeaves(boolean persistent) {
            BlockState ls = leafS;
            if (ls.hasProperty(LeavesBlock.PERSISTENT)) ls = ls.setValue(LeavesBlock.PERSISTENT, persistent);
            List<BlockPos> lg = new ArrayList<>(logs.keySet());
            for (BlockPos p : leaves) {
                if (logs.containsKey(p)) continue;
                if (!free(lv.getBlockState(p))) continue;
                if (!persistent) {
                    int best = 99;
                    for (BlockPos l : lg) {
                        int d = Math.abs(l.getX() - p.getX()) + Math.abs(l.getY() - p.getY()) + Math.abs(l.getZ() - p.getZ());
                        if (d < best) best = d;
                    }
                    if (best > 6) continue;
                }
                lv.setBlock(p, ls, 3);
                lv.scheduleTick(p, ls.getBlock(), 1);
            }
        }
    }

    // ------------------------------------------------------------------ building blocks

    /** layered conifer: a plate every `period` blocks, filler layers in between, radius shrinks to the top */
    private static void tiers(B b, int h, int bottom, int maxRad, int period, boolean fill) {
        int span = h - bottom + 2;
        for (int y = bottom; y <= h; y++) {
            int idx = y - bottom;
            int rad = Math.max(1, (int) Math.round(maxRad * (1.0 - (double) idx / span)));
            BlockPos c = b.at(0, y, 0);
            if (idx % period == 0) b.disc(c, rad, 96);
            else if (fill) b.disc(c, Math.max(1, rad - 1), 90);
            else b.cross(c, 1);
        }
        b.leaf(b.at(0, h + 1, 0));
        b.leaf(b.at(0, h + 2, 0));
    }

    /** tall thin trunk with tufts of leaves every few blocks (english oak, white birch) */
    private static void tufts(B b, int h, int gap, int arm) {
        b.blob(b.at(0, h, 0), 1.8, 1.6, 1.8, 96, 0);
        for (int y = h - 3; y >= 3; y -= gap + b.r.nextInt(2)) {
            BlockPos c = b.at(0, y, 0);
            for (Direction d : HZ) {
                if (!b.chance(78)) continue;
                for (int i = 1; i <= arm; i++) b.leaf(c.relative(d, i));
                if (b.chance(50)) b.leaf(c.relative(d, 1).above());
                if (b.chance(40)) b.leaf(c.relative(d, 1).relative(d.getClockWise(), 1));
            }
            for (Direction d : HZ) if (b.chance(45)) b.leaf(c.above().relative(d, 1));
        }
    }

    /** wide flat canopy on a bare trunk (umbrella look) */
    private static void umbrella(B b, int h, int rad, int layers, int pct) {
        for (int i = 0; i < layers; i++) {
            int rr = i == layers - 1 ? Math.max(1, rad - 3) : i == layers - 2 ? Math.max(2, rad - 1) : rad;
            b.disc(b.at(0, h - 1 + i, 0), rr, pct);
        }
        b.spokes(b.at(0, h - 1, 0), Math.max(2, rad - 2), 4);
    }

    // ------------------------------------------------------------------ the shapes

    static boolean grow(ServerLevel lv, BlockPos pos, Block log, Block leaf, String key, RandomSource r, Runnable hang) {
        B b = new B(lv, pos, log, leaf, r);
        int h;
        boolean persistent = false;
        if (key.startsWith("leave_birch_wht")) {
            h = b.rnd(13, 17);
            b.trunk(h);
            tufts(b, h, 3, 1 + b.r.nextInt(2));
        } else {
            switch (key) {
                // ---------------------------------------------------------------- oaks
                case "leave_oak_blue": {
                    h = b.rnd(10, 13);
                    b.trunk(h);
                    double rx = 3.3 + r.nextDouble() * 0.9;
                    b.blob(b.at(0, h - 3, 0), rx, 4.3, rx, 94, 0);
                    b.blob(b.at(0, h, 0), rx - 1.4, 1.8, rx - 1.4, 100, 0);
                    b.spokes(b.at(0, h - 3, 0), 2, 3);
                    break;
                }
                case "leave_oak_engli": {
                    h = b.rnd(12, 16);
                    b.trunk(h);
                    tufts(b, h, 3, 2);
                    break;
                }
                case "leave_oak_gray": {
                    h = b.rnd(7, 9);
                    b.trunk(h);
                    double rx = 3.1 + r.nextDouble() * 1.0;
                    b.blob(b.at(0, h - 2, 0), rx, 2.6, rx, 88, 0);
                    b.blob(b.at(b.rnd(-1, 1), h - 4, b.rnd(-1, 1)), rx - 0.8, 2.0, rx - 0.8, 82, 0);
                    b.blob(b.at(0, h + 1, 0), 2.0, 1.3, 2.0, 100, 0);
                    b.spokes(b.at(0, h - 3, 0), 2, 4);
                    break;
                }
                case "leave_oak_japem": {
                    h = b.rnd(7, 9);
                    b.trunk(h);
                    double rx = 4.6 + r.nextDouble() * 1.0;
                    b.blob(b.at(0, h - 1, 0), rx, 3.0, rx, 96, 0);
                    b.blob(b.at(0, h + 2, 0), rx - 2.2, 1.6, rx - 2.2, 100, 0);
                    b.spokes(b.at(0, h - 2, 0), 3, 4);
                    for (Direction d : HZ) b.log(b.at(0, h - 1, 0).relative(d, 1).relative(d.getClockWise(), 1));
                    break;
                }
                // ---------------------------------------------------------------- spruces
                case "leave_spruc_black": {
                    h = b.rnd(14, 18);
                    b.trunk(h);
                    for (int y = h - 2; y >= 4; y -= 3) {
                        b.disc(b.at(0, y, 0), 2, 88);
                        b.cross(b.at(0, y + 1, 0), 1);
                    }
                    b.cross(b.at(0, h, 0), 1);
                    b.leaf(b.at(0, h + 1, 0));
                    b.leaf(b.at(0, h + 2, 0));
                    break;
                }
                case "leave_spruc_marti": {
                    h = b.rnd(13, 16);
                    b.trunk(h);
                    tiers(b, h, 3, 4, 2, true);
                    break;
                }
                case "leave_spruc_norwa": {
                    h = b.rnd(20, 26);
                    b.trunk(h);
                    tiers(b, h, 4, 4, 3, true);
                    break;
                }
                case "leave_spruc_red": {
                    h = b.rnd(12, 15);
                    b.trunk(h);
                    tiers(b, h, 3, 5, 3, true);
                    break;
                }
                // ---------------------------------------------------------------- birches
                case "leave_birch_chdwa": {
                    h = b.rnd(6, 8);
                    b.trunk(h);
                    b.blob(b.at(0, h - 2, 0), 1.7, 3.3, 1.7, 92, 0);
                    break;
                }
                case "leave_birch_silve": {
                    h = b.rnd(9, 12);
                    b.trunk(h);
                    double rx = 3.0 + r.nextDouble() * 0.8;
                    b.blob(b.at(0, h - 3, 0), rx, 3.8, rx, 90, 0);
                    b.blob(b.at(0, h, 0), rx - 1.4, 1.6, rx - 1.4, 100, 0);
                    b.spokes(b.at(0, h - 4, 0), 2, 2);
                    break;
                }
                case "leave_birch_water": {
                    h = b.rnd(6, 8);
                    b.trunk(h);
                    double rx = 3.5 + r.nextDouble() * 0.7;
                    b.blob(b.at(0, h - 2, 0), rx, 2.5, rx, 92, 0);
                    b.blob(b.at(b.rnd(-1, 1), h - 4, b.rnd(-1, 1)), rx - 0.9, 1.7, rx - 0.9, 80, 0);
                    b.spokes(b.at(0, h - 3, 0), 2, 3);
                    break;
                }
                // ---------------------------------------------------------------- dark oak group
                case "leave_dkoak_bur": {
                    h = b.rnd(8, 11);
                    b.trunk(h);
                    for (int i = 0; i < 3; i++) {
                        int y = h - 6 + i * 2;
                        int ox = b.rnd(-2, 2), oz = b.rnd(-2, 2);
                        b.disc(b.at(ox, y, oz), 3 + (i == 1 ? 1 : 0), 90);
                        b.disc(b.at(ox, y + 1, oz), 2, 85);
                        b.spoke(b.at(0, y, 0), Math.abs(ox) >= Math.abs(oz) ? (ox >= 0 ? Direction.EAST : Direction.WEST) : (oz >= 0 ? Direction.SOUTH : Direction.NORTH), 2);
                    }
                    b.disc(b.at(0, h, 0), 3, 95);
                    b.disc(b.at(0, h + 1, 0), 2, 100);
                    break;
                }
                case "leave_dkoak_everg": {
                    h = b.rnd(9, 12);
                    b.trunk(h);
                    for (Direction d : HZ) b.log(b.at(0, h - 2, 0).relative(d, 1));
                    for (Direction d : HZ) if (b.chance(50)) b.log(b.at(0, h - 3, 0).relative(d, 1));
                    umbrella(b, h, 4, 4, 95);
                    break;
                }
                case "leave_dkoak_itali": {
                    h = b.rnd(6, 8);
                    b.trunk(h);
                    for (Direction d : HZ) b.log(b.at(0, h - 1, 0).relative(d, 1));
                    umbrella(b, h + 1, 5, 3, 94);
                    break;
                }
                case "leave_dkoak_sessi": {
                    h = b.rnd(8, 10);
                    b.trunk(h);
                    double rx = 3.2 + r.nextDouble() * 0.6;
                    b.blob(b.at(0, h - 2, 0), rx, 3.6, rx, 95, 0);
                    b.blob(b.at(0, h + 1, 0), rx - 1.5, 1.4, rx - 1.5, 100, 0);
                    b.spokes(b.at(0, h - 3, 0), 2, 3);
                    break;
                }
                // ---------------------------------------------------------------- nut trees
                case "leave_nut_maya": {
                    h = b.rnd(8, 10);
                    b.trunk(h);
                    tiers(b, h, 3, 4, 2, true);
                    break;
                }
                case "leave_nut_pecan": {
                    h = b.rnd(8, 10);
                    b.trunk(h);
                    umbrella(b, h - 1, 6, 5, 90);
                    break;
                }
                case "leave_nut_pista": {
                    h = b.rnd(6, 8);
                    b.trunk(h);
                    int ox = b.rnd(-1, 1), oz = b.rnd(-1, 1);
                    b.blob(b.at(ox, h - 1, oz), 3.0, 2.3, 3.0, 92, 0);
                    b.blob(b.at(-ox, h + 1, -oz), 2.0, 1.4, 2.0, 100, 0);
                    b.spokes(b.at(0, h - 2, 0), 2, 3);
                    break;
                }
                case "leave_nut_walnu": {
                    h = b.rnd(8, 10);
                    b.trunk(h);
                    b.blob(b.at(0, h - 2, 0), 4.2, 3.5, 4.2, 70, 0.22);
                    b.blob(b.at(0, h + 1, 0), 2.2, 1.4, 2.2, 90, 0);
                    b.spokes(b.at(0, h - 3, 0), 3, 4);
                    break;
                }
                case "leave_nut_almon": {
                    h = b.rnd(8, 10);
                    b.trunk(h);
                    b.blob(b.at(0, h, 0), 5.0 + r.nextDouble() * 0.6, 2.8, 5.0 + r.nextDouble() * 0.6, 92, 0);
                    b.spokes(b.at(0, h - 1, 0), 3, 4);
                    break;
                }
                case "leave_nut_brazi": {
                    h = b.rnd(13, 17);
                    b.trunk(h);
                    umbrella(b, h, 6, 4, 88);
                    break;
                }
                case "leave_nut_butte": {
                    h = b.rnd(7, 9);
                    b.trunk(h);
                    b.blob(b.at(0, h - 1, 0), 3.8, 3.0, 3.8, 88, 0);
                    b.blob(b.at(b.rnd(-2, 2), h - 3, b.rnd(-2, 2)), 2.6, 2.0, 2.6, 80, 0);
                    b.spokes(b.at(0, h - 2, 0), 2, 4);
                    break;
                }
                case "leave_nut_candl": {
                    h = b.rnd(6, 8);
                    b.trunk(h);
                    double rx = 3.8 + r.nextDouble() * 0.5;
                    b.blob(b.at(0, h - 1, 0), rx, 3.3, rx, 98, 0);
                    b.blob(b.at(0, h - 4, 0), rx - 1.0, 1.8, rx - 1.0, 75, 0);
                    b.spokes(b.at(0, h - 2, 0), 2, 4);
                    break;
                }
                case "leave_nut_cashe": {
                    h = b.rnd(5, 7);
                    b.trunk(h);
                    b.blob(b.at(0, h - 1, 0), 4.3, 2.5, 4.3, 92, 0);
                    b.blob(b.at(b.rnd(-2, 2), h + 1, b.rnd(-2, 2)), 2.4, 1.5, 2.4, 95, 0);
                    b.spokes(b.at(0, h - 2, 0), 3, 4);
                    break;
                }
                case "leave_nut_gabon": {
                    h = b.rnd(11, 14);
                    b.trunk(h);
                    b.blob(b.at(0, h - 2, 0), 3.2, 3.2, 3.2, 92, 0);
                    b.blob(b.at(0, h + 1, 0), 2.4, 1.6, 2.4, 100, 0);
                    b.spokes(b.at(0, h - 3, 0), 2, 3);
                    break;
                }
                case "leave_nut_hazel": {
                    h = b.rnd(4, 6);
                    b.trunk(h);
                    Direction d = HZ[r.nextInt(4)];
                    for (int y = 1; y < h - 1; y++) b.log(b.at(0, y, 0).relative(d, 1));
                    b.blob(b.at(0, h - 1, 0), 2.8, 2.4, 2.8, 94, 0);
                    b.blob(b.at(d.getStepX(), h - 2, d.getStepZ()), 2.4, 2.0, 2.4, 88, 0);
                    break;
                }
                case "leave_nut_macad": {
                    h = b.rnd(6, 8);
                    b.trunk(h);
                    b.blob(b.at(0, h - 2, 0), 3.0, 3.2, 3.0, 96, 0);
                    b.blob(b.at(0, h + 1, 0), 1.8, 1.2, 1.8, 100, 0);
                    b.spokes(b.at(0, h - 3, 0), 2, 2);
                    break;
                }
                // ---------------------------------------------------------------- acacias
                case "leave_acaci_baobo": {
                    h = b.rnd(7, 9);
                    for (int y = 0; y < h; y++) {
                        b.log(b.at(0, y, 0));
                        b.log(b.at(1, y, 0));
                        b.log(b.at(0, y, 1));
                        b.log(b.at(1, y, 1));
                    }
                    for (int y = h; y < h + 2; y++) {
                        b.log(b.at(0, y, 0));
                        b.log(b.at(1, y, 1));
                    }
                    BlockPos c = b.at(0, h, 0);
                    b.spoke(c.offset(1, 0, 0), Direction.EAST, 3);
                    b.spoke(c.offset(0, 0, 1), Direction.SOUTH, 3);
                    b.spoke(c.offset(0, 0, 0), Direction.WEST, 3);
                    b.spoke(c.offset(0, 0, 0), Direction.NORTH, 3);
                    BlockPos mid = b.at(0, h + 2, 0);
                    b.disc(mid.offset(0, 0, 0), 6, 92);
                    b.disc(mid.offset(0, 1, 0), 6, 92);
                    b.disc(mid.offset(0, 2, 0), 4, 90);
                    b.disc(mid.offset(1, -1, 1), 5, 80);
                    break;
                }
                case "leave_acaci_cucum": {
                    h = b.rnd(5, 7);
                    b.trunk(h);
                    Direction d = HZ[r.nextInt(4)];
                    BlockPos p = b.at(0, h - 3, 0);
                    for (int i = 1; i <= 2; i++) {
                        p = p.relative(d, 1).above();
                        b.log(p);
                    }
                    b.blob(b.at(0, h + 1, 0), 3.2, 1.8, 3.2, 92, 0);
                    b.blob(p.above(), 2.6, 1.6, 2.6, 90, 0);
                    b.blob(b.at(-d.getStepX() * 2, h - 1, -d.getStepZ() * 2), 2.2, 1.4, 2.2, 80, 0);
                    break;
                }
                case "leave_acaci_rivbu": {
                    h = b.rnd(6, 8);
                    b.trunk(h);
                    for (Direction d : HZ) b.log(b.at(0, h - 3, 0).relative(d, 1));
                    b.blob(b.at(0, h - 1, 0), 3.4, 3.0, 3.4, 92, 0);
                    b.blob(b.at(0, h - 4, 0), 2.6, 1.5, 2.6, 80, 0);
                    break;
                }
                case "leave_acaci_whist": {
                    h = b.rnd(6, 8);
                    b.trunk(h);
                    int k = 0;
                    for (int y = 3; y < h; y += 2) {
                        Direction d = HZ[(k++ + r.nextInt(2)) % 4];
                        b.spoke(b.at(0, y, 0), d, 2);
                        b.blob(b.at(0, y, 0).relative(d, 3).above(), 1.6, 1.3, 1.6, 88, 0);
                    }
                    b.blob(b.at(0, h, 0), 2.0, 1.5, 2.0, 92, 0);
                    break;
                }
                default:
                    return false;
            }
        }
        if (!b.placeLogs()) return false;
        if (hang != null) hang.run();
        b.placeLeaves(persistent);
        return true;
    }

    /** big palm: slightly leaning tall trunk, 8 broad arching fronds. Returns the top log position or null. */
    static BlockPos palm(ServerLevel lv, BlockPos pos, Block log, Block leaf, int h, int len, RandomSource r) {
        B b = new B(lv, pos, log, leaf, r);
        Direction lean = HZ[r.nextInt(4)];
        int sx = 0, sz = 0;
        for (int y = 0; y < h; y++) {
            if (y > 3 && y % 4 == 0 && r.nextInt(3) > 0 && Math.abs(sx) + Math.abs(sz) < 2) { sx += lean.getStepX(); sz += lean.getStepZ(); }
            b.log(pos.offset(sx, y, sz));
        }
        BlockPos top = pos.offset(sx, h - 1, sz);
        for (int y = 1; y <= h; y++) {
            BlockPos q = pos.above(y);
            if (!free(lv.getBlockState(q))) return null;
        }
        int[][] dirs = {{1,0},{-1,0},{0,1},{0,-1},{1,1},{1,-1},{-1,1},{-1,-1}};
        BlockPos c = top.above();
        b.log(c);
        for (int[] d : dirs) {
            boolean diag = d[0] != 0 && d[1] != 0;
            int L = diag ? len - 1 : len;
            int px = -d[1], pz = d[0];
            for (int i = 1; i <= L; i++) {
                int rise = i <= 2 ? 1 : (i <= L - 2 ? 0 : -(i - (L - 2)));
                if (i == 1) rise = 1;
                BlockPos f = c.offset(d[0] * i, rise, d[1] * i);
                b.leaf(f);
                if (i >= 2 && i < L) {
                    b.leaf(f.offset(diag ? -d[0] : px, 0, diag ? 0 : pz));
                    b.leaf(f.offset(diag ? 0 : -px, 0, diag ? -d[1] : -pz));
                }
                if (i >= L - 2) b.leaf(f.below());
            }
        }
        b.leaf(c.above());
        b.leaf(c.above(2));
        for (Direction d : HZ) b.leaf(c.above().relative(d));
        if (!b.placeLogs()) return null;
        b.placeLeaves(false);
        return top;
    }
}

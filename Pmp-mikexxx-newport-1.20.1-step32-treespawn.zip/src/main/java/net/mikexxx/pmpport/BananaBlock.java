package net.mikexxx.pmpport;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;

/**
 * Banana bunch. When another banana hangs directly above or below, every block of the stack switches to the
 * full-height bunch model (property "chain") so the bunches connect without a gap, one long hanging bunch.
 */
public class BananaBlock extends TreeFruitBlock {
    public static final BooleanProperty CHAIN = BooleanProperty.create("chain");

    public BananaBlock(Properties p, String key) {
        super(p, key);
        registerDefaultState(defaultBlockState().setValue(CHAIN, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
        super.createBlockStateDefinition(b);
        b.add(CHAIN);
    }

    private static boolean chained(BlockGetter l, BlockPos p) {
        return l.getBlockState(p.above()).getBlock() instanceof BananaBlock || l.getBlockState(p.below()).getBlock() instanceof BananaBlock;
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext c) {
        return defaultBlockState().setValue(CHAIN, chained(c.getLevel(), c.getClickedPos()));
    }

    @Override
    public BlockState updateShape(BlockState s, Direction d, BlockState n, LevelAccessor l, BlockPos p, BlockPos np) {
        if (d == Direction.UP || d == Direction.DOWN) return s.setValue(CHAIN, chained(l, p));
        return s;
    }
}

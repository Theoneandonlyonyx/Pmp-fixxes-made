package net.mikexxx.pmpport;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.registries.ForgeRegistries;

/** Very small generic tree builder: straight trunk + round or conical crown. */
public final class TreeGen {
    private TreeGen() {}

    private static boolean free(BlockState s) {
        return s.isAir() || s.canBeReplaced() || s.is(BlockTags.LEAVES);
    }

    public static boolean grow(ServerLevel lv, BlockPos pos, Block log, Block leaf, boolean conifer, int baseH, RandomSource r) {
        ResourceLocation leafKey = ForgeRegistries.BLOCKS.getKey(leaf);
        if (leafKey != null && TreeShapes.has(leafKey.getPath())) return TreeShapes.grow(lv, pos, log, leaf, leafKey.getPath(), r, null);
        if (!conifer && leafKey != null && leafKey.getPath().startsWith("leave_fruit_")) return growFruitTree(lv, pos, log, leaf, leafKey, r);
        if (!conifer && leafKey != null) {
            switch (leafKey.getPath()) {
                case "leave_jungl_acai": return growPalm(lv, pos, log, leaf, leafKey, "acai", r);
                case "leave_jungl_banan": return growPalm(lv, pos, log, leaf, leafKey, "banan", r);
                case "leave_jungl_bombo": return growPalm(lv, pos, log, leaf, leafKey, "bombo", r);
                case "leave_jungl_cocon": return growPalm(lv, pos, log, leaf, leafKey, "cocon", r);
                default: break;
            }
        }
        int h = baseH + r.nextInt(3);
        for (int y = 1; y <= h + 1; y++) if (!free(lv.getBlockState(pos.above(y)))) return false;
        BlockState logS = log.defaultBlockState();
        BlockState leafS = leaf.defaultBlockState();
        // naturally grown leaves are NOT persistent: they decay when no log is near (distance is corrected by a scheduled tick)
        if (leafS.hasProperty(LeavesBlock.PERSISTENT)) leafS = leafS.setValue(LeavesBlock.PERSISTENT, false);
        if (leafS.hasProperty(LeavesBlock.DISTANCE)) leafS = leafS.setValue(LeavesBlock.DISTANCE, 6);
        for (int y = 0; y < h; y++) lv.setBlock(pos.above(y), logS, 3);
        if (conifer) {
            for (int y = h; y >= 2; y--) {
                int rad = Math.min(3, (h - y + 1) / 2);
                put(lv, pos.above(y), rad, leafS, r, rad > 1);
            }
            lv.setBlock(pos.above(h), leafS, 3);
            lv.setBlock(pos.above(h + 1), leafS, 3);
            lv.scheduleTick(pos.above(h), leafS.getBlock(), 1);
            lv.scheduleTick(pos.above(h + 1), leafS.getBlock(), 1);
        } else {
            for (int y = h - 3; y <= h + 1; y++) {
                int rad = y >= h ? 1 : 2;
                put(lv, pos.above(y), rad, leafS, r, rad == 2);
            }
            fruit(lv, pos, h, log, leaf);
        }
        return true;
    }

    /** fruit / nut trees: 4 branch logs under the crown, a ripe fruit block hangs below each one (like 1.12.2) */
    private static void fruit(ServerLevel lv, BlockPos pos, int h, Block log, Block leaf) {
        ResourceLocation k = ForgeRegistries.BLOCKS.getKey(leaf);
        if (k == null || !k.getPath().startsWith("leave_") || h < 4) return;
        Block fb = ForgeRegistries.BLOCKS.getValue(new ResourceLocation(k.getNamespace(), "trfrt_" + k.getPath().substring(6)));
        if (!(fb instanceof TreeFruitBlock)) return;
        BlockState fs = fb.defaultBlockState().setValue(TreeFruitBlock.AGE, 0);   // starts at the first look and ripens through each distinct stage
        for (Direction d : Direction.Plane.HORIZONTAL) {
            BlockPos bp = pos.above(h - 3).relative(d);
            BlockPos fp = bp.below();
            BlockState cur = lv.getBlockState(fp);
            if (!(cur.isAir() || cur.canBeReplaced())) continue;
            BlockState ls = log.defaultBlockState();
            if (ls.hasProperty(RotatedPillarBlock.AXIS)) ls = ls.setValue(RotatedPillarBlock.AXIS, d.getAxis());
            lv.setBlock(bp, ls, 3);
            lv.setBlock(fp, fs, 3);
            stack(lv, fp, fs, ((TreeFruitBlock) fb).isStackable());
        }
    }

    /** bananas hang as one short connected bunch of 2-3 blocks (the first one is already placed) */
    private static void stack(ServerLevel lv, BlockPos first, BlockState fs, boolean stackable) {
        if (!stackable) return;
        BlockState cs = fs.hasProperty(BananaBlock.CHAIN) ? fs.setValue(BananaBlock.CHAIN, true) : fs;
        int n = 2 + lv.random.nextInt(2);
        int placed = 1;
        for (int k = 1; k < n; k++) {
            BlockPos q = first.below(k);
            if (!lv.getBlockState(q).isAir()) break;
            lv.setBlock(q, cs, 3);
            placed++;
        }
        if (placed > 1) lv.setBlock(first, cs, 3);
    }

    private static void put(ServerLevel lv, BlockPos c, int rad, BlockState leafS, RandomSource r, boolean trimCorners) {
        for (int dx = -rad; dx <= rad; dx++)
            for (int dz = -rad; dz <= rad; dz++) {
                if (trimCorners && Math.abs(dx) == rad && Math.abs(dz) == rad && r.nextBoolean()) continue;
                BlockPos p = c.offset(dx, 0, dz);
                BlockState cur = lv.getBlockState(p);
                if (cur.isAir() || cur.canBeReplaced() || cur.is(BlockTags.LEAVES)) {
                    lv.setBlock(p, leafS, 3);
                    lv.scheduleTick(p, leafS.getBlock(), 1);
                }
            }
    }

    // ---------------------------------------------------------------------------------------------------------
    // Fruit trees, ported from the 1.12.2 jar (GenTreeBaseFruit.generateFruitTree + GenTreeBase.generateRandomLeafLayer):
    //   trunk = 5 fruitwood logs, at the top (y = 4) one log on each side (N/S/E/W) with a fruit block hanging below it,
    //   leaves: 5x5 layer without corners (92 % of the blocks) at y = 4 and y = 5, then a 3x3 layer without corners at y = 6.
    //   Leaves only replace air. Fruit starts at age 0 (first look) and ripens by itself.
    // ---------------------------------------------------------------------------------------------------------
    private static boolean growFruitTree(ServerLevel lv, BlockPos pos, Block log, Block leaf, ResourceLocation leafKey, RandomSource r) {
        final int height = 5;
        if (lv.getBlockState(pos.below()).is(Blocks.FARMLAND)) return false;
        for (int y = 1; y < height; y++) if (!free(lv.getBlockState(pos.above(y)))) return false;
        BlockState logS = log.defaultBlockState();
        BlockState leafS = leaf.defaultBlockState();
        if (leafS.hasProperty(LeavesBlock.PERSISTENT)) leafS = leafS.setValue(LeavesBlock.PERSISTENT, false);
        if (leafS.hasProperty(LeavesBlock.DISTANCE)) leafS = leafS.setValue(LeavesBlock.DISTANCE, 6);
        Block fb = ForgeRegistries.BLOCKS.getValue(new ResourceLocation(leafKey.getNamespace(), "trfrt_" + leafKey.getPath().substring(6)));
        BlockState fruitS = fb instanceof TreeFruitBlock ? fb.defaultBlockState().setValue(TreeFruitBlock.AGE, 0) : null;
        for (int y = 0; y < height; y++) lv.setBlock(pos.above(y), logS, 3);
        BlockPos top = pos.above(height - 1);
        for (Direction d : Direction.Plane.HORIZONTAL) {
            BlockPos bp = top.relative(d);
            lv.setBlock(bp, logS, 3);
            BlockPos fp = bp.below();
            if (fruitS != null && lv.getBlockState(fp).isAir()) {
                lv.setBlock(fp, fruitS, 3);
                stack(lv, fp, fruitS, ((TreeFruitBlock) fb).isStackable());
            }
        }
        leafLayer(lv, r, top, 2, 1, 0, 92, leafS);
        leafLayer(lv, r, top.above(1), 2, 1, 0, 92, leafS);
        leafLayer(lv, r, top.above(2), 1, 1, 0, 100, leafS);
        return true;
    }

    /** GenTreeBase.generateLeafLayer / generateRandomLeafLayer: square of radius rad, the k outermost blocks of every edge end
     *  (the corners) only stay with chance cc %, every block is placed with chance pct %, leaves only replace air */
    private static void leafLayer(ServerLevel lv, RandomSource r, BlockPos c, int rad, int k, int cc, int pct, BlockState leafS) {
        for (int dx = -rad; dx <= rad; dx++)
            for (int dz = -rad; dz <= rad; dz++) {
                boolean place = true;
                if ((dz == -rad || dz == rad) && (dx < -rad + k || dx > rad - k) && 1 + r.nextInt(99) > cc) place = false;
                if ((dx == -rad || dx == rad) && (dz < -rad + k || dz > rad - k) && 1 + r.nextInt(99) > cc) place = false;
                if (!place) continue;
                if (pct < 100 && r.nextInt(100) >= pct) continue;
                BlockPos p = c.offset(dx, 0, dz);
                if (lv.getBlockState(p).isAir()) {
                    lv.setBlock(p, leafS, 3);
                    lv.scheduleTick(p, leafS.getBlock(), 1);
                }
            }
    }

    // ---------------------------------------------------------------------------------------------------------
    // Palms, ported 1:1 from the 1.12.2 jar (GenJunglAcai / GenJunglBanan / GenJunglBombo / GenJunglCocon):
    //   Bombona  : trunk 10-14 logs, 4 side logs under the top, 4 upright leaf arms, 2 leaves on top.
    //   Banana   : trunk 4-5 logs, same crown, a stack of bananas hangs under each of the 4 side logs.
    //   Acai     : trunk 8-13 logs, 4 side logs (+ fruit) 4 below the top, drooping leaf arms, 4 diagonal logs and leaf blobs.
    //   Coconut  : trunk 5-9 logs, 2-3 straight, then shifted one block to a random side, then back one block; side logs with nuts, drooping arms.
    // Leaves only replace air. Fruit starts at the first look (age 0) and ripens by itself.
    // ---------------------------------------------------------------------------------------------------------
    private static void palmLeaf(ServerLevel lv, BlockPos p, BlockState leafS) {
        if (lv.getBlockState(p).isAir()) {
            lv.setBlock(p, leafS, 3);
            lv.scheduleTick(p, leafS.getBlock(), 1);
        }
    }

    /** drooping arm: p, p+d, then one lower p+d, p+2d */
    private static void drooping(ServerLevel lv, BlockPos p, Direction d, BlockState leafS) {
        palmLeaf(lv, p, leafS);
        palmLeaf(lv, p.relative(d, 1), leafS);
        palmLeaf(lv, p.relative(d, 1).below(), leafS);
        palmLeaf(lv, p.relative(d, 2).below(), leafS);
    }

    /** upright arm: p, p+d, then one higher p+d, p+2d */
    private static void upright(ServerLevel lv, BlockPos p, Direction d, BlockState leafS) {
        palmLeaf(lv, p, leafS);
        palmLeaf(lv, p.relative(d, 1), leafS);
        palmLeaf(lv, p.relative(d, 1).above(), leafS);
        palmLeaf(lv, p.relative(d, 2).above(), leafS);
    }

    private static void palmLog(ServerLevel lv, BlockPos p, BlockState logS) {
        if (free(lv.getBlockState(p))) lv.setBlock(p, logS, 3);
    }

    /** a side log with a bunch of fruit hanging below it (only where there is room) */
    private static void palmSideLog(ServerLevel lv, BlockPos bp, BlockState logS, BlockState fruitS, boolean stackable) {
        palmLog(lv, bp, logS);
        if (fruitS == null) return;
        BlockPos fp = bp.below();
        if (!lv.getBlockState(fp).isAir()) return;
        lv.setBlock(fp, fruitS, 3);
        stack(lv, fp, fruitS, stackable);
    }

    private static BlockState withAxis(BlockState s, Direction.Axis a) {
        return s.hasProperty(RotatedPillarBlock.AXIS) ? s.setValue(RotatedPillarBlock.AXIS, a) : s;
    }

    private static boolean growPalm(ServerLevel lv, BlockPos pos, Block log, Block leaf, ResourceLocation leafKey, String kind, RandomSource r) {
        BlockState logS = log.defaultBlockState();
        BlockState leafS = leaf.defaultBlockState();
        if (leafS.hasProperty(LeavesBlock.PERSISTENT)) leafS = leafS.setValue(LeavesBlock.PERSISTENT, false);
        if (leafS.hasProperty(LeavesBlock.DISTANCE)) leafS = leafS.setValue(LeavesBlock.DISTANCE, 6);
        Block fb = ForgeRegistries.BLOCKS.getValue(new ResourceLocation(leafKey.getNamespace(), "trfrt_" + leafKey.getPath().substring(6)));
        BlockState fruitS = fb instanceof TreeFruitBlock ? fb.defaultBlockState().setValue(TreeFruitBlock.AGE, 0) : null;
        boolean stackable = fb instanceof TreeFruitBlock tfb && tfb.isStackable();
        if (lv.getBlockState(pos.below()).is(Blocks.FARMLAND)) return false;
        Direction[] hz = {Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST};

        if (kind.equals("cocon")) {
            int height = 5 + r.nextInt(5);
            int n = 2 + r.nextInt(2);
            int q0 = 1 + r.nextInt(100);   // the original picks N / E / S / W with 25 % each
            Direction d = q0 < 25 ? Direction.NORTH : q0 < 50 ? Direction.EAST : q0 < 75 ? Direction.SOUTH : Direction.WEST;
            // collect every log position first so nothing is placed when the palm does not fit
            java.util.List<BlockPos> logs = new java.util.ArrayList<>();
            BlockPos p = pos.below();
            for (int i = 0; i < n; i++) { p = p.above(); logs.add(p); }
            p = p.relative(d, 1);
            int rest = height - n - 1;
            for (int i = 0; i < rest; i++) { p = p.above(); logs.add(p); }
            p = p.relative(d.getOpposite(), 1);
            for (int i = 0; i < 2; i++) { p = p.above(); logs.add(p); }
            for (BlockPos q : logs) if (!free(lv.getBlockState(q))) return false;
            for (BlockPos q : logs) lv.setBlock(q, logS, 3);
            palmSideLog(lv, p.north(), withAxis(logS, Direction.Axis.Z), fruitS, stackable);
            palmSideLog(lv, p.south(), withAxis(logS, Direction.Axis.Z), fruitS, stackable);
            palmSideLog(lv, p.east(), withAxis(logS, Direction.Axis.X), fruitS, stackable);
            palmSideLog(lv, p.west(), withAxis(logS, Direction.Axis.X), fruitS, stackable);
            palmLeaf(lv, p.above(), leafS);
            for (Direction dd : hz) drooping(lv, p.relative(dd, 2), dd, leafS);
            return true;
        }

        int height = switch (kind) {
            case "acai" -> 8 + r.nextInt(6);
            case "banan" -> 4 + r.nextInt(2);
            default -> 10 + r.nextInt(5);   // bombona
        };
        for (int y = 1; y <= height + 1; y++) if (!free(lv.getBlockState(pos.above(y)))) return false;
        for (int y = 0; y < height; y++) lv.setBlock(pos.above(y), logS, 3);

        if (kind.equals("acai") || kind.equals("bombo")) {
            int hh = kind.equals("acai") ? 11 + r.nextInt(6) : 14 + r.nextInt(6);
            BlockPos top = TreeShapes.palm(lv, pos, log, leaf, hh, kind.equals("acai") ? 5 + r.nextInt(2) : 6 + r.nextInt(2), r);
            if (top == null) return false;
            for (Direction d : hz) palmSideLog(lv, top.below().relative(d), logS, fruitS, stackable);
            return true;
        }
        if (kind.equals("acai")) {
            BlockPos p = pos.above(height - 4);
            for (Direction d : hz) palmSideLog(lv, p.relative(d), logS, fruitS, stackable);
            for (Direction d : hz) drooping(lv, p.relative(d, 2), d, leafS);
            p = pos.above(height - 2);
            palmLog(lv, p.north().east(), logS);
            palmLog(lv, p.north().west(), logS);
            palmLog(lv, p.south().east(), logS);
            palmLog(lv, p.south().west(), logS);
            leafLayer(lv, r, p.north(1).east(1), 1, 1, 0, 100, leafS);
            leafLayer(lv, r, p.north(1).west(1), 1, 1, 0, 100, leafS);
            leafLayer(lv, r, p.south(1).east(1), 1, 1, 0, 100, leafS);
            leafLayer(lv, r, p.south(1).west(1), 1, 1, 0, 100, leafS);
            palmLeaf(lv, pos.above(height), leafS);
            p = pos.above(height - 1);
            palmLeaf(lv, p.north().east(), leafS);
            palmLeaf(lv, p.north().west(), leafS);
            palmLeaf(lv, p.south().east(), leafS);
            palmLeaf(lv, p.south().west(), leafS);
            return true;
        }

        // bombona and banana: ring of 4 side logs, 4 upright arms, 2 leaves on top
        BlockPos p = pos.above(height - 2);
        for (Direction d : hz) palmSideLog(lv, p.relative(d), logS, fruitS, stackable);
        p = p.above();
        for (Direction d : hz) upright(lv, p.relative(d), d, leafS);
        palmLeaf(lv, p.above(), leafS);
        palmLeaf(lv, p.above(2), leafS);
        return true;
    }
}

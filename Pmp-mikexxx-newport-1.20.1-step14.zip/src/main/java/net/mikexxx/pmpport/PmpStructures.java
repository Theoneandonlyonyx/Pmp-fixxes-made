package net.mikexxx.pmpport;

import it.unimi.dsi.fastutil.longs.LongIterator;
import it.unimi.dsi.fastutil.longs.LongSet;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.StructureTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.PoolElementStructurePiece;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructurePiece;
import net.minecraft.world.level.levelgen.structure.StructureStart;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Structure-aware replacement for the old block scans.
 *
 * <p>Village plants used to sample a 9×9×6 grid (486 block reads) around every candidate looking for
 * dirt paths plus planks / hay / composters / farmland. That grid is an 8-block horizontal radius and a
 * vertical window of y-2..y+3, and it only existed to answer "is this spot next to a village street and
 * a village building?". Desert villages do not use dirt paths, so the block test also missed them.
 *
 * <p>This class reads structure starts that are already stored on the chunks being generated
 * ({@code STRUCTURE_STARTS} / {@code STRUCTURE_REFERENCES} both finish before features) and tests piece
 * bounding boxes against that same window. No chunk outside the current {@code WorldGenLevel} is loaded:
 * a missing start chunk is skipped rather than generated. There is no static cache.
 *
 * <p>Profiling counters stay at zero unless {@code -Dpmp.profile=true}.
 */
final class PmpStructures {
    /** Matches {@code looksLikeVillage}: dx/dz from -8 to 8. */
    static final int VILLAGE_RADIUS = 8;
    static final int VILLAGE_Y_BELOW = 2;
    static final int VILLAGE_Y_ABOVE = 3;

    private static final byte PATH = 1;
    private static final byte BUILDING = 2;

    static final boolean PROFILE = Boolean.getBoolean("pmp.profile");
    static long collects;
    static long emptyCollects;
    static long startsSeen;
    static long startsOutsideRegion;
    static long piecesTested;
    static long nearTests;
    static long nearPasses;
    static long columnTests;
    static long columnPasses;

    private enum Kind { VILLAGE, WOOD_SURFACE, WOOD_CAVE }

    /** One structure piece whose box already intersects the queried horizontal area. */
    record Hit(BoundingBox box, byte kind) {}

    private record StartKey(ResourceLocation id, long packed) {}

    private PmpStructures() {}

    static List<Hit> villageHits(WorldGenLevel level, BlockPos origin, int horizontalRadius) {
        return collect(level, origin, horizontalRadius, Kind.VILLAGE);
    }

    static List<Hit> woodHits(WorldGenLevel level, BlockPos origin, int horizontalRadius, boolean underground) {
        return collect(level, origin, horizontalRadius, underground ? Kind.WOOD_CAVE : Kind.WOOD_SURFACE);
    }

    /** Both a street piece and a building piece must meet the original 8-block / y-2..y+3 window. */
    static boolean nearVillage(List<Hit> hits, BlockPos pos) {
        if (PROFILE) nearTests++;
        if (hits.isEmpty()) return false;
        int x0 = pos.getX() - VILLAGE_RADIUS;
        int x1 = pos.getX() + VILLAGE_RADIUS;
        int y0 = pos.getY() - VILLAGE_Y_BELOW;
        int y1 = pos.getY() + VILLAGE_Y_ABOVE;
        int z0 = pos.getZ() - VILLAGE_RADIUS;
        int z1 = pos.getZ() + VILLAGE_RADIUS;
        boolean path = false;
        boolean building = false;
        for (int i = 0, n = hits.size(); i < n; i++) {
            Hit hit = hits.get(i);
            if (PROFILE) piecesTested++;
            BoundingBox bb = hit.box;
            if (bb.maxX() < x0 || bb.minX() > x1 || bb.maxY() < y0 || bb.minY() > y1 || bb.maxZ() < z0 || bb.minZ() > z1) continue;
            byte kind = hit.kind;
            if ((kind & PATH) != 0) path = true;
            if ((kind & BUILDING) != 0) building = true;
            if (path && building) {
                if (PROFILE) nearPasses++;
                return true;
            }
        }
        return false;
    }

    /** True when the wide collection already contains both a path piece and a building piece. */
    static boolean hasVillageParts(List<Hit> hits) {
        boolean path = false;
        boolean building = false;
        for (int i = 0, n = hits.size(); i < n; i++) {
            byte kind = hits.get(i).kind;
            if ((kind & PATH) != 0) path = true;
            if ((kind & BUILDING) != 0) building = true;
            if (path && building) return true;
        }
        return false;
    }

    /** The vertical plank search only has to run where a wooden structure piece actually overlaps the column. */
    static boolean columnOverlaps(List<Hit> hits, int x, int z, int yMin, int yMax) {
        if (PROFILE) columnTests++;
        if (yMin > yMax) {
            int s = yMin;
            yMin = yMax;
            yMax = s;
        }
        for (int i = 0, n = hits.size(); i < n; i++) {
            BoundingBox bb = hits.get(i).box;
            if (bb.minX() <= x && x <= bb.maxX() && bb.minZ() <= z && z <= bb.maxZ() && bb.maxY() >= yMin && bb.minY() <= yMax) {
                if (PROFILE) columnPasses++;
                return true;
            }
        }
        return false;
    }

    /**
     * Y range to scan for planks: the original window clipped to overlapping piece boxes.
     * Returns {@code null} when no piece covers this column inside the window.
     */
    static int[] columnSpan(List<Hit> hits, int x, int z, int yMin, int yMax) {
        if (yMin > yMax) {
            int s = yMin;
            yMin = yMax;
            yMax = s;
        }
        int lo = Integer.MAX_VALUE;
        int hi = Integer.MIN_VALUE;
        for (int i = 0, n = hits.size(); i < n; i++) {
            BoundingBox bb = hits.get(i).box;
            if (bb.minX() > x || x > bb.maxX() || bb.minZ() > z || z > bb.maxZ()) continue;
            int a = Math.max(yMin, bb.minY());
            int b = Math.min(yMax, bb.maxY());
            if (a > b) continue;
            if (a < lo) lo = a;
            if (b > hi) hi = b;
        }
        if (hi < lo) return null;
        if (PROFILE) {
            columnTests++;
            columnPasses++;
        }
        return new int[]{lo, hi};
    }

    private static List<Hit> collect(WorldGenLevel level, BlockPos origin, int horizontalRadius, Kind kind) {
        if (PROFILE) collects++;
        int minCx = (origin.getX() - horizontalRadius) >> 4;
        int maxCx = (origin.getX() + horizontalRadius) >> 4;
        int minCz = (origin.getZ() - horizontalRadius) >> 4;
        int maxCz = (origin.getZ() + horizontalRadius) >> 4;
        Registry<Structure> reg = level.registryAccess().registryOrThrow(Registries.STRUCTURE);
        int x0 = origin.getX() - horizontalRadius;
        int x1 = origin.getX() + horizontalRadius;
        int z0 = origin.getZ() - horizontalRadius;
        int z1 = origin.getZ() + horizontalRadius;
        List<Hit> hits = new ArrayList<>();
        Set<StartKey> seen = new HashSet<>();
        for (int cx = minCx; cx <= maxCx; cx++) {
            for (int cz = minCz; cz <= maxCz; cz++) {
                if (!level.hasChunk(cx, cz)) continue;
                ChunkAccess chunk = level.getChunk(cx, cz);
                Map<Structure, LongSet> refs = chunk.getAllReferences();
                if (refs.isEmpty()) continue;
                for (Map.Entry<Structure, LongSet> entry : refs.entrySet()) {
                    Structure structure = entry.getKey();
                    if (!wanted(reg, structure, kind)) continue;
                    LongSet starts = entry.getValue();
                    if (starts == null || starts.isEmpty()) continue;
                    ResourceLocation id = reg.getKey(structure);
                    if (id == null) continue;
                    LongIterator it = starts.iterator();
                    while (it.hasNext()) {
                        long packed = it.nextLong();
                        if (!seen.add(new StartKey(id, packed))) continue;
                        if (PROFILE) startsSeen++;
                        int sx = ChunkPos.getX(packed);
                        int sz = ChunkPos.getZ(packed);
                        // Never ask the region (or the server) to generate a chunk. Feature regions are
                        // 8 chunks wide; starts beyond that are simply not visible yet.
                        if (!level.hasChunk(sx, sz)) {
                            if (PROFILE) startsOutsideRegion++;
                            continue;
                        }
                        StructureStart start = level.getChunk(sx, sz).getStartForStructure(structure);
                        if (start == null || !start.isValid()) continue;
                        List<StructurePiece> pieces = start.getPieces();
                        for (int i = 0, n = pieces.size(); i < n; i++) {
                            StructurePiece piece = pieces.get(i);
                            BoundingBox bb = piece.getBoundingBox();
                            if (bb.maxX() < x0 || bb.minX() > x1 || bb.maxZ() < z0 || bb.minZ() > z1) continue;
                            byte pieceKind = kind == Kind.VILLAGE ? villageKind(piece) : BUILDING;
                            if (pieceKind == 0) continue;
                            hits.add(new Hit(bb, pieceKind));
                        }
                    }
                }
            }
        }
        if (PROFILE && hits.isEmpty()) emptyCollects++;
        return hits;
    }

    private static boolean wanted(Registry<Structure> reg, Structure structure, Kind kind) {
        return switch (kind) {
            case VILLAGE -> tagged(reg, structure, StructureTags.VILLAGE);
            case WOOD_CAVE -> tagged(reg, structure, StructureTags.MINESHAFT);
            case WOOD_SURFACE -> tagged(reg, structure, StructureTags.VILLAGE) || woodenSurface(reg.getKey(structure));
        };
    }

    /** Mansions, outposts and swamp huts are the other wooden buildings the surface climber feature was scanning for. */
    private static boolean woodenSurface(ResourceLocation id) {
        if (id == null || !"minecraft".equals(id.getNamespace())) return false;
        String path = id.getPath();
        return path.equals("mansion") || path.equals("pillager_outpost") || path.equals("swamp_hut");
    }

    private static boolean tagged(Registry<Structure> reg, Structure structure, TagKey<Structure> tag) {
        ResourceLocation rl = reg.getKey(structure);
        if (rl == null) return false;
        return reg.getHolder(ResourceKey.create(Registries.STRUCTURE, rl)).map(holder -> holder.is(tag)).orElse(false);
    }

    /**
     * Village jigsaw pieces are named {@code village/<biome>/streets|houses|town_centers|...}
     * (zombie villages use the same folders). Streets satisfy the old "dirt path" signal,
     * houses the old "planks / hay / farmland" signal, town centers satisfy both.
     * Template id comes from the element's public {@code toString} ({@code Single[Left[minecraft:...]]}),
     * which is stable for 1.20.1 and does not need access transformers.
     */
    private static byte villageKind(StructurePiece piece) {
        if (!(piece instanceof PoolElementStructurePiece pool)) return 0;
        String name = pool.getElement().toString();
        if (name.contains("/villagers/") || name.contains("/animals/") || name.contains("/decays/")
                || name.contains("camel") || name.contains("iron_golem")) {
            return 0;
        }
        boolean path = name.contains("/streets/") || name.contains("/terminators/") || name.contains("lamp") || name.contains("decoration");
        boolean building = name.contains("/houses/");
        if (name.contains("/town_centers/") || name.contains("well")) {
            path = true;
            building = true;
        }
        byte kind = 0;
        if (path) kind |= PATH;
        if (building) kind |= BUILDING;
        return kind;
    }

    static String profileLine() {
        return "collects=" + collects
                + " empty=" + emptyCollects
                + " starts=" + startsSeen
                + " startsOutsideRegion=" + startsOutsideRegion
                + " nearTests=" + nearTests
                + " nearPasses=" + nearPasses
                + " columnTests=" + columnTests
                + " columnPasses=" + columnPasses
                + " pieceTests=" + piecesTested;
    }
}

package net.mikexxx.pmpport;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.properties.BlockSetType;
import net.minecraft.world.level.block.state.properties.WoodType;
import net.minecraft.world.level.material.PushReaction;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.io.InputStreamReader;
import java.util.*;
import java.util.function.Supplier;

@Mod(PmpMod.MODID)
public class PmpMod {
    public static final String MODID = "pmp_mikexxx";
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, MODID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);
    static final Map<String, List<RegistryObject<Item>>> BY_TAB = new LinkedHashMap<>();
    static final Map<String, String> TAB_ICON = new HashMap<>();
    /** fixed foliage tint per leaf block id (the original mod used fixed colours, not biome colours) */
    public static final Map<String, Integer> LEAF_TINT = new LinkedHashMap<>();
    /** plants whose overlay layer (tintindex 0) is tinted with the biome grass colour (classic ferns) */
    public static final Set<String> BIOME_TINT = new LinkedHashSet<>();

    public PmpMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        JsonArray arr;
        try (var in = new InputStreamReader(PmpMod.class.getResourceAsStream("/pmp_entries.json"))) {
            arr = JsonParser.parseReader(in).getAsJsonArray();
        } catch (Exception e) {
            throw new RuntimeException("PMP: cannot read pmp_entries.json", e);
        }
        for (String t : List.of("flowers", "plants", "crops", "aquatic", "trees", "food", "build")) BY_TAB.put(t, new ArrayList<>());
        for (JsonElement je : arr) register(je.getAsJsonObject());
        bus.addListener(PmpMod::commonSetup);
        // the colour-filter tab comes FIRST of the PMP tabs (so it sits in the upper row), the other PMP tabs follow it
        final String allPath = "all_plants";
        TABS.register(allPath, () -> CreativeModeTab.builder()
                .title(Component.translatable("itemGroup." + MODID + ".all_plants"))
                .icon(() -> {
                    Item it = ForgeRegistries.ITEMS.getValue(new ResourceLocation(MODID, "flower_red"));
                    return new ItemStack(it == null || it == Items.AIR ? Items.POPPY : it);
                })
                .displayItems((params, out) -> {
                    for (ResourceLocation rl : ColorConfig.all()) {
                        Item it = ForgeRegistries.ITEMS.getValue(rl);
                        if (it != null && it != Items.AIR) out.accept(it);
                    }
                })
                .build());
        ResourceKey<CreativeModeTab> prev = ResourceKey.create(Registries.CREATIVE_MODE_TAB, new ResourceLocation(MODID, allPath));
        int tabIndex = 0;
        for (String t : BY_TAB.keySet()) {
            final String tab = t;
            // numeric prefix keeps all PMP tabs sorted together (before other mods' tabs)
            final String tabPath = (tabIndex++) + "_" + t;
            final ResourceKey<CreativeModeTab> before = prev;
            TABS.register(tabPath, () -> {
                CreativeModeTab.Builder b = CreativeModeTab.builder()
                        .title(Component.translatable("itemGroup." + MODID + "." + tabPath))
                        .icon(() -> {
                            List<RegistryObject<Item>> l = BY_TAB.get(tab);
                            return l.isEmpty() ? new ItemStack(Items.POPPY) : new ItemStack(l.get(0).get());
                        })
                        .displayItems((params, out) -> { for (RegistryObject<Item> r : BY_TAB.get(tab)) out.accept(r.get()); });
                if (before != null) b.withTabsBefore(before);
                return b.build();
            });
            prev = ResourceKey.create(Registries.CREATIVE_MODE_TAB, new ResourceLocation(MODID, tabPath));
        }
        BLOCKS.register(bus);
        ITEMS.register(bus);
        TABS.register(bus);
        PmpWorldgen.FEATURES.register(bus);
        PmpWorldgen.LOOT.register(bus);
    }

    private static PlantBlock flattened(PlantBlock b, boolean f) { return f ? b.flat() : b; }

    private static PlantBlock harvested(PlantBlock b, String h) { return h == null ? b : b.withHarvest(h); }

    private static BlockBehaviour.Properties plantProps() {
        return plantProps(true);
    }

    /** Hanging plants and fully-grown (single stage) plants do not implement growth and must not be random-ticked. */
    private static BlockBehaviour.Properties plantProps(boolean randomTick) {
        BlockBehaviour.Properties props = BlockBehaviour.Properties.of().noCollission().instabreak()
                .sound(SoundType.GRASS).pushReaction(PushReaction.DESTROY);
        return randomTick ? props.randomTicks() : props;
    }

    private static BlockBehaviour.Properties woodProps() {
        return BlockBehaviour.Properties.of().strength(2.0F, 3.0F).sound(SoundType.BAMBOO_WOOD);
    }

    private static BlockBehaviour.Properties solidProps(String id) {
        String n = id;
        if (n.contains("bamboo") || n.contains("oak") || n.contains("birch") || n.contains("spruce") || n.contains("jungle")
                || n.contains("acacia") || n.contains("fruitwood") || n.contains("frtwd")) return woodProps();
        if (n.startsWith("gold") || n.startsWith("iron") || n.startsWith("diamond") || n.startsWith("lapis"))
            return BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL);
        if (n.startsWith("ice")) return BlockBehaviour.Properties.of().strength(0.5F).sound(SoundType.GLASS);
        return BlockBehaviour.Properties.of().strength(1.5F, 6.0F).sound(SoundType.STONE);
    }

    /** item id -> composter chance, filled while the entries are registered */
    private static final java.util.Map<String, Float> COMPOST = new java.util.HashMap<>();

    /** vanilla-like chances: saplings / leaves / seeds 30 %, cacti and vines 50 %, everything else that grows 65 %. Hanging plants and building blocks are not compostable. */
    private static float compostChance(String id, String kind) {
        switch (kind) {
            case "item": {
                if (id.startsWith("seed") || id.startsWith("item_seed")) return 0.3F;
                if (id.startsWith("nut_")) return 0.5F;
                if (id.startsWith("fruit_") || id.startsWith("veget_") || id.startsWith("leaff_") || id.startsWith("item_leaf_") || id.startsWith("root_") || id.startsWith("item_flower_")
                        || id.startsWith("berry_") || id.startsWith("item_berries_") || id.startsWith("stem_")) return 0.65F;
                if (RAW_FOOD.contains(id)) return 0.65F;
                if (id.startsWith("flower_")) return 0.5F;      // flower petals
                return 0F;
            }
            case "plant": case "aqua": case "floating": case "epiphyte": {
                if (id.startsWith("sapling_") || id.startsWith("bamboo_")) return 0.3F;
                if (id.startsWith("cactus_") || id.startsWith("epiphyte_") && id.endsWith("cactus")) return 0.5F;
                return 0.65F;
            }
            case "climbing": case "vine": return 0.5F;
            case "leaves": return 0.3F;
            default: return 0F;
        }
    }

    private static final java.util.Set<String> RAW_FOOD = java.util.Set.of("item_food_beet", "item_food_bell_pepper_green", "item_food_bell_pepper_orange",
            "item_food_bell_pepper_red", "item_food_bell_pepper_yellow", "item_food_celery", "item_food_centella_leaves", "item_food_corn", "item_food_cucumber",
            "item_food_laksa_leaves", "item_food_lettuce", "item_food_mozuku_seaweed", "item_food_onion", "item_food_prickly_pear_fruit", "item_food_sacred_lotus_root",
            "item_food_spinach", "item_food_taro_root", "item_food_tomato", "item_food_wasabi_stem", "item_food_water_chestnut", "item_food_watercress", "item_food_wild_rice");

    private static void commonSetup(net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent e) {
        e.enqueueWork(() -> COMPOST.forEach((id, chance) -> {
            Item it = ForgeRegistries.ITEMS.getValue(new ResourceLocation(MODID, id));
            if (it != null && it != Items.AIR) net.minecraft.world.level.block.ComposterBlock.COMPOSTABLES.put(it, chance.floatValue());
        }));
    }

    private static void register(JsonObject o) {
        final String id = o.get("id").getAsString();
        final String kind = o.get("kind").getAsString();
        final int color = o.get("color").getAsInt();
        final String latin = o.has("latin") && !o.get("latin").isJsonNull() ? o.get("latin").getAsString() : null;
        final int stages = o.get("stages").getAsInt();
        final String tab = o.get("tab").getAsString();
        float compost = compostChance(id, kind);
        if (compost > 0F) COMPOST.put(id, compost);
        if (kind.equals("item")) {
            Item.Properties p = new Item.Properties();
            if (o.has("food") && !o.get("food").isJsonNull()) {
                JsonArray f = o.getAsJsonArray("food");
                p.food(new FoodProperties.Builder().nutrition(f.get(0).getAsInt()).saturationMod(f.get(1).getAsFloat()).build());
            }
            RegistryObject<Item> r;
            if (o.has("plant") && !o.get("plant").isJsonNull()) {
                // food item that also plants a crop (right-click block = plant, right-click air = eat)
                final String plantId = o.get("plant").getAsString();
                if (plantId.startsWith("floating_")) {
                    r = ITEMS.register(id, () -> new PmpFloatingSeedItem(
                            ForgeRegistries.BLOCKS.getValue(new ResourceLocation(MODID, plantId)), p, color, latin));
                } else {
                    r = ITEMS.register(id, () -> new PmpSeedFoodItem(
                            ForgeRegistries.BLOCKS.getValue(new ResourceLocation(MODID, plantId)), p, color, latin));
                }
            } else {
                r = ITEMS.register(id, () -> new PmpItem(p, color, latin));
            }
            BY_TAB.get(tab).add(r);
            return;
        }
        if (kind.equals("leaves") && o.has("tint")) LEAF_TINT.put(id, o.get("tint").getAsInt());
        if (o.has("biome") && o.get("biome").getAsBoolean()) BIOME_TINT.add(id);
        final boolean dwarfFlag = o.has("dwarf") && o.get("dwarf").getAsBoolean();
        final boolean directional = o.has("directional") && o.get("directional").getAsBoolean();
        final String effectName = o.has("effect") && !o.get("effect").isJsonNull() ? o.get("effect").getAsString() : null;
        final boolean flat = o.has("flat") && o.get("flat").getAsBoolean();
        final String hv = o.has("harvest") && !o.get("harvest").isJsonNull() ? o.get("harvest").getAsString() : null;
        // crops (crop tab, quinoa) may stand on farmland; wild plants only on soil
        final boolean cropPlant = tab.equals("crops") || id.equals("flower_quinoa");
        final boolean logs = o.has("logs") && o.get("logs").getAsBoolean();
        final boolean grows = stages > 1;
        Supplier<Block> sup;
        if (o.has("water")) {
            final JsonObject w = o.getAsJsonObject("water");
            final WaterPlantBlock.Mode wm = WaterPlantBlock.Mode.valueOf(w.get("mode").getAsString().toUpperCase());
            final int wh = w.has("h") ? w.get("h").getAsInt() : 1;
            sup = () -> new WaterPlantBlock(plantProps(grows).noOcclusion(), wm, stages, wh);
            RegistryObject<Block> wb = BLOCKS.register(id, sup);
            BY_TAB.get(tab).add(ITEMS.register(id, () -> new PmpBlockItem(wb.get(), new Item.Properties(), color, latin, stages)));
            return;
        }
        switch (kind) {
            case "plant" -> {
                if (o.has("tree")) {
                    JsonObject t = o.getAsJsonObject("tree");
                    final String tl = t.get("log").getAsString(), tf = t.get("leaf").getAsString();
                    final boolean con = t.get("conifer").getAsBoolean();
                    final int th = t.get("h").getAsInt();
                    sup = () -> new SaplingTreeBlock(plantProps(), tl, tf, con, th);
                } else if (o.has("bamboo")) {
                    final int bm = o.get("bamboo").getAsInt();
                    // bamboo is a solid pole you cannot walk through (collision = the stalk shape), hardness like vanilla bamboo
                    sup = () -> new BambooStalkBlock(BlockBehaviour.Properties.of().strength(1.0F).sound(SoundType.BAMBOO)
                            .noOcclusion().randomTicks().pushReaction(PushReaction.DESTROY), bm);
                } else if (o.has("tall")) {
                    final int tf = o.getAsJsonObject("tall").get("from").getAsInt(), th = o.getAsJsonObject("tall").get("h").getAsInt();
                    sup = () -> new TallPlantBlock(plantProps(grows), stages - 1, tf, th, false).crop(cropPlant).onLogs(logs).nether(id.startsWith("spooky_"));
                } else if (directional) {
                    sup = () -> new PalmettoBlock(plantProps(grows), stages - 1);
                } else sup = () -> flattened(harvested(new PlantBlock(plantProps(grows), stages - 1, PlantBlock.Type.GROUND).dwarf(dwarfFlag).withEffect(effectName).crop(cropPlant).onLogs(logs).nether(id.startsWith("spooky_")), hv), flat);
            }
            case "hanging" -> {
                final int hh = o.has("h") ? o.get("h").getAsInt() : 2;
                sup = () -> new HangingPlantBlock(plantProps(false).noOcclusion(), hh);
            }
            case "vine" -> sup = () -> new PmpVineBlock(BlockBehaviour.Properties.of().replaceable().noCollission().randomTicks()
                    .strength(0.2F).sound(SoundType.VINE).pushReaction(PushReaction.DESTROY));
            case "climbing" -> sup = () -> new ClimbingPlantBlock(plantProps(true).noOcclusion()).withHarvest(hv);
            case "floating" -> sup = () -> flattened(new PlantBlock(plantProps(grows), stages - 1, PlantBlock.Type.FLOATING), flat);
            case "aqua" -> {
                if (o.has("tall")) {
                    final int tf = o.getAsJsonObject("tall").get("from").getAsInt(), th = o.getAsJsonObject("tall").get("h").getAsInt();
                    sup = () -> new TallPlantBlock(plantProps(grows), stages - 1, tf, th, true);
                } else sup = () -> new AquaPlantBlock(plantProps(grows), stages - 1);
            }
            case "leaves" -> sup = () -> new PmpLeavesBlock(BlockBehaviour.Properties.of().strength(0.2F).randomTicks()
                    .sound(SoundType.GRASS).noOcclusion().isValidSpawn((s, g, p, t) -> false)
                    .isSuffocating((s, g, p) -> false).isViewBlocking((s, g, p) -> false));
            case "pillar" -> sup = () -> new RotatedPillarBlock(woodProps());
            case "block", "plank" -> sup = () -> new Block(woodProps());
            case "slab" -> sup = () -> new SlabBlock(woodProps());
            case "stairs" -> sup = () -> new StairBlock(() -> Blocks.OAK_PLANKS.defaultBlockState(), woodProps());
            case "fence" -> sup = () -> new FenceBlock(woodProps());
            case "gate" -> sup = () -> new FenceGateBlock(woodProps(), WoodType.BAMBOO);
            case "door" -> sup = () -> new DoorBlock(woodProps().noOcclusion(), BlockSetType.BAMBOO);
            case "ladder" -> sup = () -> new LadderBlock(BlockBehaviour.Properties.of().strength(0.4F).sound(SoundType.LADDER).noOcclusion());
            case "epiphyte" -> {
                if (o.has("floor") && o.get("floor").getAsBoolean())
                    sup = () -> new EpiphyteFloorBlock(BlockBehaviour.Properties.of().noCollission().instabreak().sound(SoundType.GRASS));
                else sup = () -> new EpiphyteBlock(BlockBehaviour.Properties.of().noCollission().instabreak().sound(SoundType.GRASS));
            }
            case "treefruit" -> sup = () -> new TreeFruitBlock(BlockBehaviour.Properties.of().noCollission().instabreak().randomTicks()
                    .noOcclusion().sound(SoundType.GRASS).pushReaction(PushReaction.DESTROY), id.startsWith("trfrt_") ? id.substring(6) : id);
            case "planter" -> sup = () -> new PlanterBlock(solidProps(id).noOcclusion());
            case "flowerpot" -> sup = () -> new ShapedBlock(solidProps(id).noOcclusion(), Block.box(4.5, 0, 4.5, 11.5, 6, 11.5));
            case "wallbracket" -> sup = () -> new WallBracketBlock(solidProps(id).noOcclusion());
            case "workbench" -> sup = () -> new PottingTableBlock(woodProps().noOcclusion());
            case "pole" -> sup = () -> new PoleBlock(woodProps().noOcclusion());
            case "wall" -> sup = () -> new WallBlock(woodProps().noOcclusion());
            default -> { return; }
        }
        RegistryObject<Block> b = BLOCKS.register(id, sup);
        // the hanging tree fruit has no item of its own: the food item (entry field "plant" of the fruit) places it
        if (kind.equals("treefruit")) return;
        RegistryObject<Item> r;
        if (kind.equals("floating")) r = ITEMS.register(id, () -> new PmpFloatingItem(b.get(), new Item.Properties(), color, latin, stages));
        else if (kind.equals("door")) r = ITEMS.register(id, () -> new net.minecraft.world.item.DoubleHighBlockItem(b.get(), new Item.Properties()) {
            @Override public Component getName(ItemStack s) { return PmpItem.colored(Component.translatable(getDescriptionId()), color); }
        });
        else r = ITEMS.register(id, () -> new PmpBlockItem(b.get(), new Item.Properties(), color, latin, stages));
        BY_TAB.get(tab).add(r);
    }
}

# Pmp mikexxx newport (Forge 1.20.1)
Upload this folder (or the zip) to a GitHub repo -> Actions tab -> "build-jar" -> download the jar artifact.
Honeycomb on a plant = waxed (stops growing). Axe removes wax. Bone meal = +1 growth stage.

Added in this revision:
- Planters (59), flower pots (32), wall brackets (26 incl. 1.7.10 stone/gem ones), bamboo poles (9), bamboo walls (9),
  fruitwood bark, potting table (opens a 3x3 crafting grid).
- 241 crafting recipes converted from the 1.12.2 version (+ item tags food_vegetable/fruit/berry/nut/rice/bread/mushroom).
- Latin names for all species/cultivar plants (shown as grey italic tooltip).

Not ported: world generation, advancements, trellis / trellis tower (no assets in the 1.12.2 jar), curled brackets, cactus spike items.

Rev 3:
- Removed duplicate plants (same texture, different name): kept the specific 1.7.10 cultivar names, kept 1.12.2 colours only where 1.7.10 has none.
  Flowers are sorted by plant, then rainbow order (dark red -> red -> coral -> orange -> yellow -> green -> cyan -> blue -> royal -> purple -> magenta -> pink -> white).
- Tall plants are separate blocks: 1.12.2 3-segment plants = Bottom / Middle / Top blocks, 2-block plants = Bottom / Top blocks,
  1.7.10 plants with 6/8/10 stage textures = one block per stage (Stage 1..n). Plants with 2-5 stages still grow with bone meal.
- Epiphytes (18) are wall-mounted blocks that attach to the side of logs/blocks.

Rev 4:
- Medium / large plants are ONE block + ONE item again. 1.7.10 'DOUBLE' plants (taken from the jar's plant table): 2 single-block stages, then
  bottom/top pairs from stage 3 on (growing via bone meal / random ticks, the top is placed when it reaches a 2-block stage). 1.12.2 large plants
  (3 segments, 2 wide) and 2-segment plants use the jar's own models. Honeycomb waxes all segments, axe removes the wax.
- Stage-split entries removed: every single-block growth plant is one inventory item.
- Berry bushes: right-click when fully grown -> berries drop, the bush goes back to an earlier stage.
- Flowers tab: rainbow-order colour flowers first, then flowers with colour families kept together in rainbow order.
- All mod tabs are chained so they sit next to each other.

Rev 5:
- Medium plants (Burning Bush, Cinnamon Fern, Dwarf Pine, Japanese Pieris, Prairie Junegrass, Sheep Laurel, Slender Firethorn, Woolly Bush,
  Yellow Jasmine) are now the real 2-tall/2-wide 1.12.2 plants (one block, bottom/top).
- Tillandsia Ionantha is its own epiphyte again (separate from Sky Plant).
- Creative tabs follow the original mods: Flowers, Overworld Plants, Crops, Aquatic Plants, Trees, Food, Crafting. Their registry names start with
  0_..6_ and are chained, so they stay together and in this order.
- Colour families are sorted by number of colours (most first, rainbow order inside), the rest follows.
- Ground covers and floating plants (water lilies etc.) are flat on the ground/water with random rotation instead of crosses.
- Hanging plants are whole pieces now (1.12.2 ones use top+bottom textures, 1.7.10 ones their complete single-block texture).

## 1.3.0 changes
- Single mod again: your original source + fixes merged in (no pre-compiled `base/`, no extension mod). Build output is ONE jar.
- Hanging plants: new `HangingPlantBlock` (2 blocks; 1.12.2 vines and sweet peas 3 blocks). Attach to ceilings, leaves, chains (vanilla + modded), wall brackets, hooks.
- Water plants: new `WaterPlantBlock`
  - aquatic crops (rice, wild rice, centella, laksa leaf, watercress, water spinach): only in 1-block-deep water on soil
  - lotus / wasabi / taro: in 1-deep water OR on soil/mud next to water OR on mud
  - immersed plants: bottom block in 1-deep water, upper 1-2 blocks above the surface (grow after the last stage)
  - all grow (random tick + bone meal), honeycomb waxes, axe removes wax
- Tall crops (brussels sprout, burdock, cassava, land cress, orache, skirret, corn): stage -> frame mapping fixed.
- Creative tab "PMP: All Plants (colour filter)" + `config/pmp_mikexxx/plant_colors.json`.
- Duplicate Tillandsia ionantha removed (kept "Sky Plant").
- German translation completed (de_de.json): every key translated, swapped cultivar names fixed, "(Stufe n)" suffixes removed.

## 1.4.0 changes
- Leaves: all 55 leaf blocks are tinted again. The leaf textures are grey on purpose; the original mod tints every tree with a FIXED colour
  (not the biome colour). Those colours were read from the original 1.12.2 jar (`DefTree`) and are applied to the block and the item
  (`ClientColors`). Leaf item names use the same colour.
- Water crops (Wasabi, Watercress, Water Spinach, Wild Rice, Asian Rice, Centella, Laksa Leaf, Sacred Lotus, Taro) are real two-block plants with
  5 growth stages: lower block in the water (even 1.7.10 texture 0/2/4/6/8), upper block above the water (odd texture 1/3/5/7/9). Both blocks
  change with every stage. Placing needs free space above; breaking either half drops the plant once. Bone meal / random ticks / honeycomb work on both halves.
- Colour tab: Cephalanthera rubra -> purple, Pachystachys lutea -> yellow, Mertensia ciliata -> purple, Liatris punctata -> purple,
  Dodecatheon meadia -> pink, Cordyline fruticosa -> red, Porcelain Berry -> purple, Kiwi -> yellow, and 23 green hanging plants (bamboos, foliage,
  philodendrons, ivies, creepers, ...) -> green.
- Config `config/pmp_mikexxx/plant_colors.json`: every line is now `"id   # Name (Latin)"` (only the id before the `#` counts). When the mod ships new
  defaults (`_version`), the old file is kept as `plant_colors.old-vN.json` and a new one is written.
- Vines: the 9 `vine_*` plants + 13 wisteria vines are real vines (`PmpVineBlock`, vanilla vine behaviour: cling to blocks, spread, climbable,
  tapered end texture at the bottom). The 9 sweet peas + 9 other `climbing_*` plants (grape, kiwi, hop, ...) are wall-climbing plants
  (`ClimbingPlantBlock`): attach to the side of a block, climbable, 4 growth stages, grow upwards when fully grown (max 6 blocks), honeycomb/axe.

## 1.5.0 changes (ported from the real 1.6.4 mod, PlantMegaPack 2.20)
- New plants: the spooky row (Bat Orchid, Burnt Rose, Devils Claw, Octopus Stinkhorn, Porcupine Tomato, Claw Shrub, Thorn Bush, White Baneberry, 3-block Dead Tree),
  Trained Cedar, Crown Imperial, Sun Bromeliad, Erechtites hieracifolia. Checked against the port by id, name, latin name and texture first - the cylinder/globe/pyramid
  cedars, prickly lettuce, golden spined cactus (= Golden Cereus) and the dandelion sizes (= growth stages) were already in the port.
- Spooky effects (`effect` field in pmp_entries.json): "thorns" (Devils Claw, Porcupine Tomato, Claw Shrub, Thorn Bush) slows and hurts like a sweet berry bush,
  "poison" (White Baneberry, Octopus Stinkhorn) gives short poison. The assignment is a guess from the plant names, change it in pmp_entries.json.
- Classic ferns (2.20 art, 6 small + 3 tall): the grey `...C` textures of the old mod are a second layer tinted with the biome grass colour (`biome: true`, tintindex 0;
  inventory icon uses layer1 tint). Tall classic ferns: top block is biome tinted.
- Dwarf berry bushes replace the "1.7.10" berry row: `berrybush_dwarf_*`, named "Dwarf <Berry> Bush". Beauty/Black(Bramble)/Blue/Orange/Straw use the 2.20 textures
  (bare bush -> berries), elder/goose/huckle/snow keep their 1.7.10 art because 2.20 has no texture for them. Dwarf bushes drop 1-2 berries (mostly 1), big bushes 1-3.
  The real "<Berry> Bush" row (8 stages) is untouched.
- Dwarf Palmetto: new `PalmettoBlock`, a single double-sided plane (the original FLAT render type) that turns to face the player when placed (8 angles, `rot` property).
- Colour tab: Hanging Lavender -> purple, Brittlebush (both) -> yellow, new dark/spooky plants -> other. `ColorConfig.CONFIG_VERSION` is 3, so existing
  config/pmp_mikexxx/plant_colors.json files are regenerated (old one is kept as backup).

## 1.6.0 changes
- Berry bushes: normal bushes (1.7.10 / 1.12.2 art, 8 stages) are the only "<Berry> Bush" row; their inventory icon is the late (berry) stage like the 1.12.2 item model.
  Dwarf bushes are now ONLY the five real 1.6.4 / 2.20 ones (Beauty, Blue, Bramble, Orange, Straw), 2 stages (bare -> berries).
  Removed the four fake dwarf bushes (Elder, Gooseberry, Huckleberry, Snowberry) that used the big 1.7.10 art.
- Crops: item icons now show the grown plant (last growth stage; the more filled half for 2-block crops) instead of the empty seedling.
- Water crops (rice, wild rice, centella, laksa leaf, watercress, water spinach, lotus, wasabi, taro): first growth stage is now a small seedling in the lower block
  (upper block empty); full stalk + leaves only from stage 2 on.
- Taro Root: `item_food_taro_root` + `root_taro` merged into ONE item (`item_food_taro_root`): right-click a block = plant taro, right-click air = eat. `crop_taro` (the plant) stays.
- Trained Cedar stays a single block (in 1.6.4 only Cylinder and Pyramid cedar are double blocks).
- Colour config version 4 (old plant_colors.json is backed up and regenerated, removed bushes dropped).

## 1.7.0 (work in steps)
### Step 1 - duplicates merged, seeds and roots plant their crops
- Same name + identical texture = one item: Quinoa Seeds, Rice (seed + food), Prickly Pear Fruit, Quinoa Cereal, Water Chestnut (root + food), Seaweed Wrap.
  References in recipes / tags were redirected to the kept item.
- Every seed, root and stem now plants its crop (`plant` field in pmp_entries.json): right-click a block = plant, right-click air = eat (if it is food).
  Water chestnut plants the floating water chestnut (`PmpFloatingSeedItem`: right-click water).
- Not merged although they look alike (different art or different name): Sacred Lotus Root, Wasabi Stem, the veget_* / item_food_* vegetable pairs, Healing/Health Salve, the wrap and fruit drink pairs.

### Step 2 - dwarf bushes complete, plants tab order
- New dwarf bushes Elder (yellow), Gooseberry (pale green), Huckleberry (dark blue-violet), Snowberry (white): the 2.20 bush texture with the berry pixels recoloured
  (same 2-stage bare -> berries logic as the other dwarf bushes, same harvest items). Now 9 big + 9 dwarf bushes.
- Overworld plants tab: berry row (normal) first, the dwarf row directly below it, the Angel's Trumpets moved down behind them.

### Step 3 - ferns and the dead tree (no 3-block plants below 1.12.2)
- Removed my wrong "Classic" ferns (single + the three 3-block tall ones). There is only ONE variety of each fern now.
- The 6 ferns that had grey tint overlays in 1.6.4 (Hay Scented, Maidenhair Spleenwort, Ostrich, Scaly Tree, Sword, Woodsia) are biome tinted: every stage texture
  (incl. the bottom/top halves of the 2-block stages) has a grey `*_biome` twin that is tinted with the biome grass colour (block + inventory item).
  Scaly Tree Fern keeps its 5 growth stages: 1 block -> 2 blocks, never 3.
- Dead Tree (2.20) is now 2 stages: young tree (1 block, texture A) -> grown tree (bottom B + top T = 2 blocks). The only 3-block plants left are the 1.12.2 `large_*` ones.

### Step 4 - colour tab
- Config file renamed: `config/pmp_mikexxx_colortab.json` (was `config/pmp_mikexxx/plant_colors.json`; the built-in defaults are `pmp_mikexxx_colortab.json` in the jar). Config version 5:
  an older colour-tab file is backed up as `pmp_mikexxx_colortab.old-vN.json` and regenerated. The old `plant_colors.json` is simply no longer used.
- Every colour group is sorted by shade from the plant textures (pink: bubblegum -> lighter -> more orange pinks; same hue-walk for red, orange, yellow, green, blue, cyan, purple, burgundy;
  whites by brightness). The "all" filter shows the groups one after another in that order.

## 1.7.1 (merge of the safe port and the step-4 port)
- Base: step-4 port (dwarf bushes Elder/Gooseberry/Huckleberry/Snowberry recoloured, seeds/roots plant their crops, duplicates merged, colour tab). Nothing from the safe port was dropped except the merged duplicates.
- Ferns: Hay Scented, Maidenhair Spleenwort, Ostrich, Scaly Tree, Sword and Woodsia are the plain 1.7.10 ferns with their growth stages again (no biome tint, no grey twin textures).
  Ostrich / Scaly Tree / Sword: 2 single-block stages, then 2-block stages.
- Dead Tree: pure 2-block plant (bottom + top), 1.6.4 art; the young one-block stage is gone.
- Re-added: Orange Angel's Trumpet (1.12.2 `large_angtr_ora`; the 1.12.2 lang file defines `large_angtr_red` twice, so the orange name was lost) and Spearleaf Stonecrop (1.12.2 `forec_stosp`).
- Grey (`*C`) 2.20 textures are NOT used for anything now.

## 1.8.0 (work in steps, built on 1.7.1)
### Step 1 - crops
- Crop-tab item icons: every double-block crop shows its UPPER, fully grown block (water crops `_9`, tall crops the `_t` / top texture).
- Crop blocks no longer drop themselves. A crop gives back its seed/root when young (1), and when fully grown seeds (1-2) + produce (1-3).
  If seed and produce are the same item (rice, wild rice, lentils, peanuts, soybeans, taro, lotus, wasabi) you get one evened-out amount (2-4).
  Centella, Laksa Leaf, Watercress and Water Spinach have no seed: they give their leaves, and those leaves (Spinach for Water Spinach) plant the crop again.
- Planting soil: wild plants only stand on soil (dirt tag: dirt, grass, podzol, coarse dirt, mycelium, rooted dirt, moss, mud) or sand. Crops (crop tab, quinoa) stand on
  farmland and the dirt tag, never on stone. Underwater plants (corals, seaweed ...) and water crops keep their own rules. Planters/pots still work.
### Step 2 - leaves, fruiting vines, seeds
- Leaves (`PmpLeavesBlock`): the DEFAULT state is persistent, so leaves placed by hand, from the creative inventory, harvested with shears and placed again, or by WorldEdit/commands
  never decay. Leaves created by a grown tree (sapling, bone meal, `TreeGen`) are NOT persistent: without a log within 6 blocks they decay like in vanilla.
  The fruit tree logs (`log_frtwd`, `logst_frtwd`) are now in `minecraft:logs`, so they hold leaves.
- Leaf drops: shears / silk touch give the leaf. Otherwise a decaying or broken leaf drops the tree's sapling (5 %, fortune improves it) and, for the 29 trees that have a fruit or nut, sometimes that fruit/nut.
- Fruiting vines: Kiwifruit, Common Grape Vine, Golden Hop, Hyacinth Bean and Porcelain Berry give Kiwi / Purple Grapes / Hops / Hyacinth Beans / Porcelain Berries on right-click once a block is fully grown
  (1-2 items, the block goes back to stage 1 and ripens again; honeycomb still waxes).
- Seeds: the planting fix is the farmland rule from step 1 (before, nothing could be planted on farmland). Every seed / root / stem item already planted its crop.
### Step 3 - epiphytes and bamboo
- Epiphytes (orchids, cacti, ferns, mistletoes ...): the 1.12.2 model had the flower plant only on a plane that runs away from the trunk, so from the front you saw just foliage.
  The shared model `_epipv` now has a second plane of the same flower texture parallel to the trunk (visible straight from the front), the original side plane and the two 45 degree foliage planes.
  The shelf fungi (artist's conk, sulphur shelf, turkey tail) are unchanged.
- Bamboo (`BambooStalkBlock`, the 9 `bamboo_*` plants): real stalks like the 1.12.2 original. They can be stacked block on block (also different species), planted on soil/sand/planters,
  and grow upwards by themselves (random tick on the lowest block, bone meal grows 1-2 blocks, honeycomb stops growth of the whole stand, axe removes the wax).
  Segment textures come from the 1.12.2 jar (bare stalk at the ground, leafier higher, leafy top). Breaking a piece breaks everything above it (drops the bamboo).
  Height per species from the 1.7.10 data: Asper 20, Giant Timber 16, Moso 16, Golden 14, Timor Black 14, Wet Forest 12, Tropical Blue 10, Short Tassled 8, Fargesia 6.
  Every stand gets its own limit between about 65 % and 100 % of that, derived from where it stands, so a grove is not all one height.

## 1.9.0 (built on your step3 zip, again in steps)
### Step 1 - bamboo
- Bamboo stalks (`BambooStalkBlock`, the 9 `bamboo_*` plants) are SOLID now: you can no longer walk through them. Collision = the 6x6 px stalk (same as the outline),
  so a stand behaves like a row of fence posts. They got the properties of vanilla bamboo: hardness 1.0, bamboo sound, and they are in `minecraft:mineable/axe`.
  Growth, stacking block on block, bone meal, honeycomb and the "breaking a piece breaks everything above" rule are unchanged.
- Textures and the stalk model were checked against the originals and NOT touched: all 45 stalk textures are pixel-identical in 1.7.10 (`bamboo<Species>0-4`), 1.12.2 (`bamb_*_0-4`)
  and the port, and the shared model `_bampl` is identical to the 1.12.2 one (full-height stalk, 0-16, so stacked pieces join without gaps).
### Step 2 - epiphytes
- Shared epiphyte model `_epipv` (15 epiphytes: orchids, cacti, ferns, mistletoes ...) back to the 1.12.2 layout and then widened: the extra plane that stood parallel to the trunk is GONE again.
  What you see now: the two 45 degree foliage ("leaf") planes exactly like the original, the middle flower plane running away from the trunk, plus two more flower planes of the same flower texture
  fanned 22.5 degrees to each side of the middle one. All three flower planes start at the trunk side (same pivot as the foliage planes), so from the front you see two flower faces
  in front of the foliage, and from the sides you still see the middle one. (Minecraft only allows element rotations of 0 / 22.5 / 45 degrees, so 22.5 is the "slightly diagonal" step.)
- Shelf fungi (artist's conk, sulphur shelf, turkey tail) use their own model `_epiph` and are untouched. Block, hitbox, placement and textures are untouched.

## 1.10.0 (work in steps, built on your s2-epiphytes zip)
### Step 1 - colour tab, duplicates, fig cactus
- The "PMP: All Plants (colour filter)" tab is now the FIRST of the PMP tabs (so it moves up in the tab bar). The filter buttons stay on the left.
- Removed the duplicates Hedera colchica (`hanging_variegated_persian_ivy`, kept the real vine `vine_variegated_persian_ivy`) and Juniperus sabina (`cold_forest_juniper_savin`, kept `shrub_juniper_savin` with its growth stages). Nothing else.
- The "all" filter button is gone (click the active filter again to see everything). New filter "Cream" after Yellow, icon = Yellow Toadflax Flower. Cream holds off-white and tan plants with a yellow/brown undertone.
- Config `config/pmp_mikexxx_colortab.json` (version 6, old file is backed up): the order of the lines IS the order in the tab, and every category list is read exactly as written.
  Ids keep their namespace, so you can add ANY item or block: `"minecraft:dandelion"`, `"othermod:some_flower"` (no namespace = this mod). Unknown ids are skipped. Missing PMP plants go to "other".
- Plants moved to a fitting colour (checked against the real texture pixels): Campanula barbata (Bearded Bellflower) -> blue, Coral Weed (the pink worm coral) and the salmon "coral" flowers -> pink, Feathered Hydroid Coral -> white,
  rushes / horsetail / water chestnut -> green, brown coral / Tangle -> other, off-white and tan plants -> cream, dusty bluish leaf plants (Blue Wheatgrass, Savin Juniper, Prairie Sage, White Sage, Dusty Miller, Mottlecah) -> cyan, and a few more.
- Every list is sorted by a plausible base colour of its category: dark shades at the top, light ones at the bottom (lightness in 5-step bands); inside a band by hue relative to the base colour, then saturation.
- Name colours: 543 plant names that had a generic or clearly wrong colour (e.g. Wildfire, Crown Imperial, Dandelion, the white flowers) now use the colour measured from the plant's own texture.
- Prickly Pear (fig cactus, Opuntia aciculata): item icon = the stage with the most fruit, and it can be harvested by right-click when fully grown (gives Prickly Pear Fruit, goes back to stage 3).

## 1.11.0 (built on your v1100-A zip, in steps)
### Step 1 - bamboo
- The stalk was an open tube (4 side planes, no top), so you looked into it from above. Every stalk piece now has a closed top: a cut-end cap (the 4x4 end texture of that species' pole, 1 px ring around it).
- Leaves: two extra 45 degree leaf planes per piece (same leaf texture as before) so the foliage is visible from all 8 directions instead of 4.
- The leafy top piece (segment 4) got a flat leaf crown (new texture `bamboo_<species>_crown.png`, built from that species' own leaf colours), so the very top is no longer bare when seen from above.
- Nothing else changed (solid collision, growth, drops).

## 1.12.0 (built on your v1110-step1-bamboo zip, in steps)
### Step 1 - cream flowers
- New cream varieties (recoloured from the white / yellow texture, leaves and stems untouched, all petal detail kept): Hydrangea 'Vanille Fraise', Lily 'Butter Pixie', Carnation 'Chantilly',
  Rose 'Pearl', Tulip 'Ivory Floradale', Water Lily 'Lemon Chiffon', Gladiolus 'Cream Spire'. Placed after the yellow one of their family; all are in the Cream filter of the colour tab.
- Colour config version 7 (an older `pmp_mikexxx_colortab.json` is backed up and regenerated so the new plants show up in Cream).

## 1.13.0 (built on your v1120-step1-cream zip, in steps)
### Step 1 - oriental lilies, scillas, flower tab order
- 13 oriental lilies (your 16x16 textures): Black Beauty (burgundy), Red Velvet, Sunset Glow (orange), Yelloween (yellow), Salmon Star (coral), Vanilla Cloud (cream), Green Dragon, Arctic Mist (cyan),
  Midnight Sky (blue), Royal Dusk (royal), Violet Eclipse (purple), Stargazer (pink), Muscadet (white, freckled). ids `flower_oriental_lily_<colour>`.
- 10 Scilla peruviana (your 128x128 textures): classic blue = `Scilla peruviana`, alba, rosea, lutea (cream), rubrum, 'Cerulean Mist' (cyan), 'Lagoon' (teal), 'Malachite' (jade),
  'Amethyst Dream' (purple) and Glacier Scilla 'Snowglobe'. ids `flower_scilla_<name>`.
- Both are in the PMP Flowers tab, the All Plants tab and the colour filters (rubrum = red, jade = green, teal/cyan = cyan, snowglobe = white).
- PMP Flowers tab: everything that has colour varieties first, all single flowers at the very bottom.
- Colour config version 8 (old file is backed up and regenerated so the new plants land in their colour).

## 1.14.0 (built on your v1130-step1-lilies-scillas zip, in steps)
### Step 1 - bamboo
- Removed the leafy "crown" on top of the top bamboo piece: model `_bampl_top`, the 9 `bamboo_<species>_crown.png` textures and their use in the `bamboo_*_s4` models are gone (they were not in any original mod). The top piece now uses the plain stalk model `_bampl` like all other pieces.
- Kept: the closed top of every stalk piece (cap = the original `bambooXPole1` end texture), so the stalk is filled and you do not look into a tube. Everything else is untouched.
### Step 2 - latin names
- Every plant block now has a latin name (tooltip + colour-config source). Added 55: Bat Orchid = Tacca chantrieri, Burnt Rose = Rosa 'Black Baccara', Devils Claw = Proboscidea louisianica,
  Octopus Stinkhorn = Clathrus archeri, Porcupine Tomato = Solanum pyracanthum, Claw Shrub = Senegalia greggii (cat-claw acacia), Thorn Bush = Crataegus monogyna, White Baneberry = Actaea pachypoda,
  Sun Bromeliad = Neoregelia carolinae, Hanging Foliage (5) = Plectranthus scutellarioides (coleus), Hanging Sweet Peas (9) = Lathyrus odoratus, Hanging Flowers (14) = Petunia x atkinsiana.
- Things that are not one species got the next honest level: groundcover flowers (10) = Phlox sp., groundcover grass (2) = Poaceae sp., leaf litter (5) = Folia caduca, Twig = Ramulus, Dead Tree = Arbor mortua.
  Change any of them in `pmp_entries.json` (field `latin`). Seeds, food and building items are not plants and were left as they are.

## 1.15.0 (built on your v1140-step2-latin zip, in steps)
### Step 1 - bamboo back to 1.12.2, latin names that should not exist
- Bamboo: all stalk textures `bamboo_<species>_s0..s4` are byte-identical to the 1.12.2 `bamb_<species>_0..4` (checked for all 9 species), nothing else is used for the stalk and its leaves.
  The model `_bampl` is now exactly the 1.12.2 model (its 16 elements with the original UVs). Removed what was NOT in 1.12.2: the two extra 45 degree leaf planes and the `pole_end` cap texture (an older-version texture).
  The top is still closed so you do not look into a tube: the 5 top faces are painted with a plain 4x4 patch of that species' own 1.12.2 stalk texture (`bamboo_<species>_s0`). That is the only thing that is not in the original model;
  delete the elements with `"up"` faces in `_bampl.json` if you want the exact open original. The leafy crown from before is gone (model and textures) in this zip already.
- Removed the latin name from everything that is not one identifiable plant: groundcover flowers (10, were "Phlox sp."), groundcover leaves (leaf litter, 4), groundcover grass (2),
  Twig / branches, Dead Tree and the Taro Root food item. Kept: Clover, Moss, Ivy (real species), the hanging petunias / coleus and everything else.

## 1.16.0 (built on your v1150-step1-bamboo-latin zip, in steps)
### Step 1 - orchids / bromeliads that are already epiphytes can stand upwards
- New `EpiphyteFloorBlock` (extends `EpiphyteBlock`, new block state `floor`). Used by the 8 orchid / bromeliad epiphytes: Crimson Cattleya, Cuthbert's Dendrobium, King Orchid, Large Foot Dendrobium, Tampa Orchid,
  Lantern Forest, Wildfire, Sky Plant (`"floor": true` in pmp_entries.json). Nothing else about them changed: same model `_epipv` (fanned planes), same textures, same item.
- `floor=true` is the same model rotated `x=90` in the blockstate, so the planes run upwards instead of away from a wall; `facing` is only the spin around the vertical axis. Click the top of a block = upright, click the side of a block = wall placement as before.
- They stand on: dirt tag (dirt, grass, podzol, coarse dirt, moss, mud, mycelium, rooted dirt), sand, logs, leaves, planters, flower pots. Mistletoes, fungi, cacti and the fern stay wall-only.
- Checked, nothing to change: ground plants already stand on the dirt tag (grass, podzol, moss ...), sand, planters/pots and (crops) farmland. Leaf litter, twigs, dead tree, groundcovers, taro root and food have no latin name.
### Step 2 - ground bromeliads / orchids (and the pineapple) can stand on logs
- Logs (`minecraft:logs`, incl. the fruit tree logs) are now a valid block to stand on for the 12 ground plants that are bromeliads or orchids: Cone-headed Guzmania, Jungle Lantern, Portea alatisepala,
  Racinaea fraseri, Silver Vase, Bromelia hemisphaerica, Bromelia laciniosa, Sun Bromeliad, Red Helleborine, Long-bracted Orchid, Yellow Lady Slipper and the Pineapple (`"logs": true` in pmp_entries.json, `PlantBlock.onLogs`).
- Nothing else changed: same cross models, textures, growth stages, bone meal and wax. They still stand on soil / sand as before; the pineapple still takes farmland.
### Step 3 - fruit / nut blocks on the trees (ported from the 1.12.2 jar, `BlockTreeFruit`)
- 31 new blocks `trfrt_<tree>` (16 fruit trees, 12 nut trees, Acai, Banana, Coconut), each with its own item in the Trees tab (named "<Food> (hanging)"), so they can be placed in creative. Textures, the 20 shared `_tfruit_*` models and the 4 stage models per fruit are copied from the jar (8 ages: 0 / 1-3 / 4-6 / 7 show the 4 models).
- Behaviour as in 1.12.2: hangs below a block (the jar requires a log = `isWood`; I also allow leaves so you can place it in creative on a crown), 1/7 chance per random tick to age, bone meal = +1 age, breaking drops the food (1 item, a ripe fruit at age 7 drops 2-5), falls off when the block above is gone. Hitbox 0.2-0.8 / 0.5-1.0 / 0.2-0.8.
- Grown trees (sapling / bone meal, `TreeGen`): fruit and nut trees get 4 branch logs under the crown with a ripe fruit hanging below each, like the 1.12.2 generator. Conifer shaped trees get none.

## 1.16.1 (built on your v1160-step3-tree-fruit-blocks zip)
### Fruit / nut blocks and fruit trees
- The 31 `trfrt_*` blockstates pointed at `pmp_mikexxx:trfrt_..._N` (the 1.12.2 way, models were found in `models/block` automatically). In 1.20.1 the folder has to be written out, so all 248 references now read `pmp_mikexxx:block/trfrt_..._N`. That was why the fruit models were missing.
- Fruit trees (the 16 `leave_fruit_*` trees, saplings with fruitwood) are now grown exactly like `GenTreeBaseFruit` of the 1.12.2 jar: 5 fruitwood logs, one log on each side of the top log with a fruit block hanging below it (age 0 like the jar, it ripens by itself),
  leaves = 5x5 layer without corners (92 % of the blocks) at the top and one above it, then a 3x3 layer without corners on top; leaves only replace air. Nut and jungle trees keep the generic tree from 1.16.0.
### Dead tree and the other 2-high plants
- `spooky_dead_tree` has no growth stages (and never had any). The log was full of "missing model for variant ... segment=middle,stage=N,waxed=...,waterlogged=..." because the 2-high plants own a `middle` segment in their block state
  but their blockstate file only knew `bottom` and `top`. All 28 two-high plants (dead tree, canna, foxglove, goldenrod, burning bush ...) now have a `segment=middle` variant (never shown, a 2-high plant has no middle). No block state or behaviour changed.

## 1.16.2 (built on your v1161-fruit-deadtree zip)
### Bamboo filling
- The closed top of every bamboo piece is back to the first version: the 4x4 pole end texture of the species (`bamboo_<species>_pole_end.png`) as centre with a 1 px ring (instead of the 4x4 patch of the stalk texture).
- No extra leaves: no 45 degree leaf planes, no crown. `_bampl` = the 16 original elements + 5 top faces. The `bamboo_*_sN` models point their `e` texture at the pole end again. Nothing else changed.

## 1.17.0 (built on your v1162-bamboo-filling zip, in steps)
### Step 1 - scillas out, new mod name, bamboo top
- All 10 scilla entries (blocks, items, textures, models, loot, names, colour-filter lines) are removed again. The oriental lilies stay.
- The mod is now called "Pmp mikexxx newport" (mods.toml display name, pack description, README title, jar name `Pmp-mikexxx-newport-1.20.1-<version>.jar`). The mod id `pmp_mikexxx` is unchanged, so worlds and the config file name stay valid.
- Bamboo: the stem in the leafy top texture (`bamboo_<species>_s4`) does not reach the top of the block, the leaves cover it. The closing cap used to sit at the top of the block (y=16), floating above the leaves. In the 9 `bamboo_<species>_s4` models the stem walls and the cap now end exactly where the stem of that species' texture ends (y = 11 / 12 / 13 / 14 depending on the species, measured from the texture), the wall UVs are cut to match so nothing is stretched. The other segments are unchanged.
### Step 2 - fruits and the colour config
- Fruits / nuts are one entry now: the 31 separate "(hanging)" items are gone from the Trees tab. The normal fruit, berry or nut item (Food tab) is placed hanging under a log or leaves (click the underside) and is eaten when it cannot be placed or when you use it in the air, like the Taro Root. The hanging block itself (`trfrt_*`) still exists for the tree generator and drops the item.
- Colour config: `config/pmp_mikexxx_colortab.toml` replaces the huge json. It only contains a short explanation and the empty colour lists (burgundy, red, orange, yellow, cream, green, blue, cyan, purple, pink, white, other). The default sorting is inside the jar. Whatever you write into a list moves there (taken out of its old list) and is shown at the top of that list in the order you typed it; ids of this mod need no namespace, other items need it (`minecraft:dandelion`). The old `.json` file is not read any more and can be deleted.
### Step 3 - names
- Flowers that only had a plain "[colour] [flower]" name (Celosia, Columbine, Dahlia, Delphinium, Geranium, Hawkweed, Hydrangea, Marigold, White Nemesia, the 9 Angel's Trumpets, the 13 flowering vines, the 13 oriental lilies and the 9 hanging sweet peas) got a real or - where no such colour exists - an invented cultivar / species name, English and German each in their own language, with the variety also in the latin name. Names that already came from 1.7.10 are unchanged in English.
- Invented names (no such colour exists in real life): Lime Plume / Lagoon Plume / Cobalt Crest Celosia, Emerald Dream / Lagoon Pompon Dahlia, Amber Glow / Sunbeam / Lime Cascade / Azure Wave Geranium, Emerald Hawkweed, Autumn Ember / Lemon Zest Hydrangea, the "Gem" marigolds, Verdigris / Lagoon Bell / Cerulean Night / Amethyst Dusk Angel's Trumpet, Crimson / Copper / Coral / Honey / Jade / Lagoon Cascade Wisteria, Sunset Blaze / Coral Sunrise / Vanilla Dream / Chartreuse Star / Glacier Mist / Blue Velvet / Royal Sapphire / Amethyst Star Oriental Lily, Hanging Verdant Sweet Pea. Change them in `lang/*.json` and `pmp_entries.json` if you want others.
- Hawkweed without a hawkweed in that colour: green stays Hieracium, the others are related plants that are not in the game yet: Alpine Blue Sow-Thistle (cyan), Cupid's Dart (blue), Purple Salsify (purple), Pink Hawksbeard (pink). All hawkweed latin names now use Hieracium (was Pilosella).
- German: the genus word now varies like Azalee / Alpenrose / Rhododendron in all families (Schafgarbe, Begonien, Nelken, Akeleien, Dahlien, Margeriten, Hortensien, Lupinen, Rosen, Tulpen, Glockenblumen ...). Gladiolus is "Gladiole" (Italienische, Abessinische, Sumpfgladiole ...), never "Schwertblume". Fixed wrong German names (Margerite instead of "Gänseblümchen", Studentenblume instead of "Ringelblume" for Tagetes, the lupine names that were shifted by one colour, Campanula 'Insulinde' that was called "Fuchsie").
- Hanging Flowers have no latin name any more (they are not petunias, the recipe takes any coloured flower). Burnt Rose is Rosa 'Hallows Ember' instead of a real variety.

## 1.17.1 (built on your v1170-step3 zip)
### Tree fruit and nuts
- Every fruit / nut block now starts at age 0 and ripens through all 8 ages on its own (1/7 chance per random tick like the 1.12.2 `BlockTreeFruit`, bone meal = +1 age).
  Before, the fruits on the nut / jungle trees were generated fully ripe (age 7) and a fruit placed from the item was ripe at once, so no stage was ever visible. The generated fruit of the fruit trees already started at 0.
- Waxing: right-click a fruit with honeycomb and it stops ageing (and ignores bone meal); an axe scrapes the wax off. New block state `waxed` (the blockstates match both values, models unchanged).
- A fruit only hangs on ITS OWN tree: under the leaves of its tree (`leave_<tree>`) or under a branch log that has those leaves within 3 blocks. Placing it elsewhere is refused and it falls off when the tree is gone.
  The trees generate them the same way as before (4 branch logs under the crown, a fruit below each).

## 1.17.2 (built on your v1171-tree-fruit zip, in steps)
### Step 1 - fruit growth, harvest, any foliage
- Every hanging fruit / nut has 4 different looks and now 4 ages (0, 1, 2, 3). Ages no longer repeat a look (before: 0 / 1-3 / 4-6 / 7 shared 4 models, so bone meal often changed nothing). One bone meal = the next look. Age 3 is ripe, so a fruit placed at the first look is finished after 3 bone meal.
- Ripe fruit, right-click: drops 3-5 of that fruit and goes back to the first look so it grows again. Honeycomb still waxes it (no growth, no bone meal); an axe scrapes the wax.
- Breaking it in survival: ripe drops 3-5 fruit. Unripe is destroyed and drops nothing. Shears, or a tool with Silk Touch (the tools that properly drop grass), also drop the fruit when it is unripe (1).
- A fruit hangs under any leaves (this mod and anything in the leaves tag) or under any log. It no longer has to be on its own tree. It still falls off when the block above is gone.

## 1.18.1 (built on your v1172-step1-fruit zip, in steps)
### Step 1 - tooltips
- The long wax line is replaced by "Wax 'n Axe!" (en and de). Bromeliads / orchids that can also stand on logs but are not epiphytes get a light gray "Mountable" line under the name.

## 1.18.2 (built on step 1, in steps)
### Step 2 - world generation (land)
- New feature `pmp_mikexxx:patch` (`PmpPatchFeature`): picks ONE plant of a weighted list per placement and puts a few copies of it around, in a random growth stage (so fresh chunks never show only grown plants). Modes: ground, water, floating, trunk (side of a log), hang (under leaves), nether, tree (sapling that is grown a moment later by `PmpWorldgen`), village, vcrop (little village crop garden: water hole + farmland + crops, only where village paths / buildings are).
- 49 groups (`data/pmp_mikexxx/worldgen/...` + `forge/biome_modifier`) written by a script from the plant list: colourful flowers by genus (latin name) and colour, per climate (jungle, swamp, forest, flower forest, plains/meadow, taiga/snow, mountains, savanna, desert, badlands, beach). Warm delphiniums go to savanna/badlands, cold ones to taiga/mountains. Tulips, roses, dahlias, hydrangeas and pelargoniums only grow in villages; colours that do not exist in real life (cyan, unreal blue/green) are only in chests and rare in villages.
- Other plants by their prefix (desert_, jungle_, mountain_ ...), Brugmansia in jungle/swamp, cacti in desert/badlands, climbing cactus and orchids/bromeliads/mistletoes/shelf fungi on tree trunks (and the floor ones also on jungle ground), vines and wisteria on trunks, hanging plants under leaves, pineapple in jungles (a bit in savanna), `spooky_*` in nether clusters (they may now stand on netherrack, nylium, basalt, soul sand/soil), saplings turn into real trees (fruit and nut trees by climate).
- Crop seeds are in chests (`PmpLootModifier`, `data/pmp_mikexxx/loot_modifiers`): each seed in three different chests, 1-2 per find in village / small chests, 2-3 in temples, dungeons, mansions. Unreal-colour flowers can also be found in chests. The crops themselves only grow in the little village gardens, additionally to the normal village crops.
- Missing blockstate variants (segment=middle and stages up to 9) added for the 9 water crops (centella, laksa leaf, rice, sacred lotus, taro, wasabi, water spinach, watercress, wild rice).
- Every JSON of the mod was parsed and every worldgen file cross-checked (configured feature -> placed feature -> biome modifier, all blocks and items exist).

## 1.18.3 (built on step 2, in steps)
### Step 3 - world generation reworked + water
- Flowers: the SPECIES decides the climate, not the colour (Delphinium nudicaule / cardinale = warm savanna + badlands, D. elatum = cold + mountains, Aquilegia in cold forests, Tagetes / Celosia savanna ...; table `SPECIES` in `gen9/worldgen2.py`-style data inside the generated groups). Cultivars follow their species / genus. Each flower only grows in part of its species' range, so not every colour is everywhere. No more "village only" flowers: all flowers grow wild; unusual colours (cyan, unreal green / blue) are rarer in the wild and more common in chests and village gardens. Villages get the flowers of their biome (plains, desert, savanna, taiga / snow). Tulips: mountains (+ flower forests), roses: forests / flower forests (where rose bushes grow). Pelargonium is gone: all geraniums are Geranium (Geranie).
- Hanging plants (they come with their bowl) no longer grow under leaves; they only appear in villages, hung under the eaves of buildings, by village biome.
- Orchids / bromeliads that are only "Mountable" grow on the ground of their biome and on top of logs (tree trunks, fallen logs). Epiphytes grow on the sides of trunks and fallen logs at any height; the floor ones also stand on the ground, but only close to a log.
- Cacti: deserts only. Mushrooms: forests (dark forest, birch, taiga a bit). Brugmansia: jungle and swamp.
- Seeds in chests: random, from the whole list. Village chests 1-2 different seeds, temples / dungeons / mansions / mineshafts 2-3, other chests 1-2, each with its own amount.
- Village gardens are now classic farms: a channel of 3 water blocks with 8 farmland blocks around it and a crop on each.
- Water: every non-coral water plant has a habitat (tropical lakes, temperate lakes, cold lakes, rivers, shallow water for reeds / rushes, warm / temperate / cold ocean). Corals: warm oceans (reefs), a few in deep temperate ocean. Kelp and eelgrass of vanilla are untouched.
- Water lilies: no more "[colour] Water Lily". Hardy ones (burgundy 'Black Princess', red 'Attraction', coral 'Colorado', orange 'Sioux', yellow 'Marliacea Chromatella', cream 'Lemon Chiffon', magenta 'Rose Arey', pink 'Marliacea Rosea', white 'Gladstoniana') grow in temperate / cold lakes, tropical ones (green 'Green Smoke', cyan 'Blue Beauty', blue 'Daubenyana', purple 'Director George T. Moore') in jungles and swamps, and the royal one is the "Egyptian Waterlily 'Isis'" (Nymphaea caerulea), only in deserts. Bone meal on the flowerless water lily leaf makes it flower in a random colour.

## 1.18.4 (built on your v1183-step3 zip)
### Fix - world generation crash "pmp_mikexxx:floorepi_jungle_ground"
- Cause: not a block. 6 old biome modifiers (`forge/biome_modifier`) were left over from earlier versions of the world generation and pointed at placed features that no longer exist:
  `floorepi_jungle_ground`, `garden_village_vcrop`, `hang_forest_hang`, `hang_jungle_hang`, `hang_swamp_hang`, `vflowers_village_village`. Minecraft cannot load a biome modifier whose placed feature is missing, so the world failed to load.
- Removed those 6 files. Nothing else was needed because each one has a current replacement that already exists with its own modifier:
  `floorepi_jungle_ground` -> `floorepi_jungle_groundlog` (floor epiphytes: orchids / bromeliads on the ground close to a log; they are the normal epiphyte blocks, no extra blocks needed),
  `garden_village_vcrop` -> `garden_v_{plains,desert,savanna,cold}_vcrop`, `hang_*_hang` -> `vhang_v_*_vhang` (hanging plants only in villages), `vflowers_village_village` -> `vflowers_v_*_village`.
- Re-checked the whole chain: 84 modifiers -> 84 placed features -> 84 configured features -> every block id exists in `pmp_entries.json`, no placed feature is unused, every `mode` is handled by `PmpPatchFeature`.

## 1.18.5 (built on your v1184-worldgen-fix zip, in steps)
### Step 1 - biome tags (modded biomes), wide spawning, higher density
- No more hard lists of vanilla biomes: every land modifier now points at a mod biome tag (`data/pmp_mikexxx/tags/worldgen/biome/bm_<climate>.json`: jungle, tropical (jungle + swamp), swamp, forest, flowerforest,
  temperate, plains, cold, mountain, savanna, desert, badlands, beach, river, nether). Each tag has the vanilla ids AND the matching vanilla / Forge biome tags (`#minecraft:is_jungle`, `#forge:is_swamp`, `#forge:is_plains`,
  `#forge:is_snowy`, `#minecraft:is_mountain` ...), so biomes from other mods that carry these tags get the plants too. Every tag reference is `"required": false`, so a tag that does not exist can never break loading.
  Underwater groups (ocean / kelp / coral) are untouched.
- "Wide" spawning, not hard locked: each ground / floating / tree group has a second copy (`*_wide`, tag `bm_wide_<climate>` = the neighbouring climates, e.g. forest plants also in plains, taiga, swamp and hills)
  at about a third of the frequency. Desert and badlands only share with each other, so cacti stay in dry biomes.
- More of it: wild flower and plant patches 2-4 per chunk instead of 1 (patch size 7 tries, spread 5), floating lilies / plants 1-2 per chunk, trees 1 in 3 chunks (was 1 in 5), logs with orchids 1 in 2 (was 1 in 3),
  climbers / vines / wisteria on trunks 1-2 per chunk (was 1 in 2).

### Step 2 - water lilies by species / origin
- The yellow lily is now the species Nymphaea mexicana (latin name + name "Mexican Waterlily" / "Mexikanische Seerose"). It and the cream lily grow where Mexico fits: savanna, sparse jungle, mangrove swamp,
  wooded badlands, desert waters (tag `bm_mexico`, with modded biomes via `#minecraft:is_savanna`, `#minecraft:is_badlands`, `#forge:is_desert`), and in the neighbouring climates (jungle, swamp, plains, badlands) a bit less often.
- Tropical (jungle + swamp + mangrove): green, cyan, blue, purple, royal (a little of the Mexican yellow and cream as well). The hardy red / orange / coral / burgundy ones left the tropics.
- Deserts and oases (`lilies_desert_floating`, tag `bm_desert` = desert + `#forge:is_desert` + `#forge:is_sandy`): the Egyptian ones, royal and purple (and a little blue).
- Cold lakes (taiga, snowy, grove ...): pink and white only. Because of the wide copy (step 1) they also show up in forests, hills and plains at a lower rate. Temperate lakes: burgundy, red, coral, orange, magenta
  (+ a little pink and white).
- All lily groups: 1-2 patches per chunk of 6 tries (were 4), so they are visible.
- Floating plants checked: all 10 non-lily floating plants (duckweed, water shield, arrow-leaved lily, water chestnut, crested floatingheart, pond lily, red root floater, water hyacinth, water lettuce, plain water lily)
  and all 14 lily colours are placed by a feature.

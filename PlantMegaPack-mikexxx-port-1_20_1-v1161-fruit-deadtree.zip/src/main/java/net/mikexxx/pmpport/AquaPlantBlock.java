package net.mikexxx.pmpport;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SimpleWaterloggedBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluids;

/** Underwater plant: only placeable in water source blocks, stays waterlogged. */
public class AquaPlantBlock extends PlantBlock implements SimpleWaterloggedBlock {
    public static final BooleanProperty WATERLOGGED = BlockStateProperties.WATERLOGGED;

    public AquaPlantBlock(Properties props, int maxStage) {
        super(props, maxStage, Type.GROUND);
        this.registerDefaultState(this.defaultBlockState().setValue(WATERLOGGED, true));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
        super.createBlockStateDefinition(b);
        b.add(WATERLOGGED);
    }

    @Override
    protected boolean aquatic() { return true; }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        FluidState f = ctx.getLevel().getFluidState(ctx.getClickedPos());
        return f.is(FluidTags.WATER) && f.getAmount() == 8 ? this.defaultBlockState() : null;
    }

    @Override
    public FluidState getFluidState(BlockState s) {
        return s.getValue(WATERLOGGED) ? Fluids.WATER.getSource(false) : super.getFluidState(s);
    }

    @Override
    public boolean canSurvive(BlockState s, LevelReader level, BlockPos pos) {
        return super.canSurvive(s, level, pos);
    }

    @Override
    public BlockState updateShape(BlockState s, Direction d, BlockState n, LevelAccessor l, BlockPos p, BlockPos np) {
        if (!s.canSurvive(l, p)) return Blocks.AIR.defaultBlockState();
        if (s.getValue(WATERLOGGED)) l.scheduleTick(p, Fluids.WATER, Fluids.WATER.getTickDelay(l));
        return s;
    }
}

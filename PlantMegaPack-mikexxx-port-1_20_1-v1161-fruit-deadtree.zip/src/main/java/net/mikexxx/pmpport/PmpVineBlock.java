package net.mikexxx.pmpport;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.VineBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;

import javax.annotation.Nullable;

/**
 * A real vine: behaves exactly like the vanilla vine (clings to the sides / underside of blocks, spreads,
 * can be climbed - see data/minecraft/tags/blocks/climbable.json). The extra BOTTOM state is true while no
 * vine hangs below, so the tapered end texture of the original mod is shown at the lower end of a vine.
 */
public class PmpVineBlock extends VineBlock {
    public static final BooleanProperty BOTTOM = BooleanProperty.create("bottom");

    public PmpVineBlock(Properties props) {
        super(props);
        this.registerDefaultState(this.defaultBlockState().setValue(BOTTOM, true));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        super.createBlockStateDefinition(builder);
        builder.add(BOTTOM);
    }

    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        BlockState s = super.getStateForPlacement(ctx);
        if (s != null && s.is(this)) {
            s = s.setValue(BOTTOM, !ctx.getLevel().getBlockState(ctx.getClickedPos().below()).is(this));
        }
        return s;
    }

    @Override
    public BlockState updateShape(BlockState state, Direction dir, BlockState neighbor, LevelAccessor level,
                                  BlockPos pos, BlockPos neighborPos) {
        BlockState s = super.updateShape(state, dir, neighbor, level, pos, neighborPos);
        if (s.is(this)) {
            boolean below = dir == Direction.DOWN ? neighbor.is(this) : level.getBlockState(pos.below()).is(this);
            s = s.setValue(BOTTOM, !below);
        }
        return s;
    }

    @Override
    public void onPlace(BlockState state, Level level, BlockPos pos, BlockState old, boolean moving) {
        super.onPlace(state, level, pos, old, moving);
        if (level.isClientSide) return;
        BlockState fixed = state.setValue(BOTTOM, !level.getBlockState(pos.below()).is(this));
        if (fixed != state) level.setBlock(pos, fixed, 2);
        BlockPos up = pos.above();
        BlockState us = level.getBlockState(up);
        if (us.is(this) && us.getValue(BOTTOM)) level.setBlock(up, us.setValue(BOTTOM, false), 2);
    }
}

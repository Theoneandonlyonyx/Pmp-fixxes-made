package net.mikexxx.pmpport;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.BonemealableBlock;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Tree fruit / nut as its own block (1.12.2 BlockTreeFruit): hangs below a log (branch) or leaves, 8 ages (0-7),
 * grows on random ticks (1/7), bone meal = +1 age. Breaking it drops the food: 1 item, a ripe one (age 7) drops 2-5.
 * Falls off (drops) when the block above is gone.
 */
public class TreeFruitBlock extends Block implements BonemealableBlock {
    public static final IntegerProperty AGE = BlockStateProperties.AGE_7;
    private static final VoxelShape SHAPE = Block.box(3.2, 8, 3.2, 12.8, 16, 12.8);

    public TreeFruitBlock(Properties p) {
        super(p);
        registerDefaultState(stateDefinition.any().setValue(AGE, 7));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
        b.add(AGE);
    }

    @Override
    public VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
        return SHAPE;
    }

    @Override
    public boolean canSurvive(BlockState s, LevelReader l, BlockPos p) {
        BlockState above = l.getBlockState(p.above());
        return above.is(BlockTags.LOGS) || above.is(BlockTags.LEAVES) || above.getBlock() instanceof LeavesBlock;
    }

    @Override
    public void neighborChanged(BlockState s, Level l, BlockPos p, Block b, BlockPos from, boolean moved) {
        if (!l.isClientSide && !s.canSurvive(l, p)) l.destroyBlock(p, true);
    }

    @Override
    public void randomTick(BlockState s, ServerLevel l, BlockPos p, RandomSource r) {
        if (!s.canSurvive(l, p)) {
            l.destroyBlock(p, true);
            return;
        }
        int age = s.getValue(AGE);
        if (age < 7 && r.nextInt(7) == 0) l.setBlock(p, s.setValue(AGE, age + 1), 2);
    }

    @Override
    public boolean isValidBonemealTarget(LevelReader l, BlockPos p, BlockState s, boolean client) {
        return s.getValue(AGE) < 7;
    }

    @Override
    public boolean isBonemealSuccess(Level l, RandomSource r, BlockPos p, BlockState s) {
        return true;
    }

    @Override
    public void performBonemeal(ServerLevel l, RandomSource r, BlockPos p, BlockState s) {
        l.setBlock(p, s.setValue(AGE, Math.min(7, s.getValue(AGE) + 1)), 2);
    }
}

package net.mikexxx.pmpport;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Epiphyte (orchids / bromeliads) that can ALSO stand upwards. Same model as the wall version, the blockstate just
 * rotates it by x=90 so the planes run up instead of away from a wall. FACING is only the spin around the vertical axis
 * when FLOOR is true. Stands on soil (dirt tag: dirt, grass, podzol, coarse dirt, moss, mud, mycelium, rooted dirt),
 * sand, logs, leaves, planters and flower pots.
 */
public class EpiphyteFloorBlock extends EpiphyteBlock {
    public static final BooleanProperty FLOOR = BooleanProperty.create("floor");
    private static final VoxelShape FLOOR_SHAPE = Block.box(0, 0, 0, 16, 10, 16);

    public EpiphyteFloorBlock(Properties p) {
        super(p);
        registerDefaultState(defaultBlockState().setValue(FLOOR, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
        b.add(FACING, FLOOR);
    }

    @Override
    public VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
        return s.getValue(FLOOR) ? FLOOR_SHAPE : super.getShape(s, l, p, c);
    }

    private static boolean canStandOn(BlockState below) {
        return below.is(BlockTags.DIRT) || below.is(BlockTags.SAND) || below.is(BlockTags.LOGS)
                || below.is(BlockTags.LEAVES) || below.getBlock() instanceof LeavesBlock
                || below.getBlock() instanceof PlanterBlock || below.getBlock() instanceof ShapedBlock;
    }

    @Override
    public boolean canSurvive(BlockState s, LevelReader l, BlockPos p) {
        if (!s.getValue(FLOOR)) return super.canSurvive(s, l, p);
        return canStandOn(l.getBlockState(p.below()));
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext c) {
        BlockState floor = defaultBlockState().setValue(FLOOR, true).setValue(FACING, c.getHorizontalDirection().getOpposite());
        boolean floorOk = floor.canSurvive(c.getLevel(), c.getClickedPos());
        // clicking the top of a block: stand upwards
        if (c.getClickedFace() == Direction.UP && floorOk) return floor;
        // otherwise the normal wall placement, and the upward one as fallback
        BlockState wall = super.getStateForPlacement(c);
        if (wall != null) return wall;
        return floorOk ? floor : null;
    }
}

# PlantMegaPack mikexxx port (Forge 1.20.1)
Upload this folder (or the zip) to a GitHub repo -> Actions tab -> "build-jar" -> download the jar artifact.
Honeycomb on a plant = waxed (stops growing). Axe removes wax. Bone meal = +1 growth stage.

Added in this revision:
- Planters (59), flower pots (32), wall brackets (26 incl. 1.7.10 stone/gem ones), bamboo poles (9), bamboo walls (9),
  fruitwood bark, potting table (opens a 3x3 crafting grid).
- 241 crafting recipes converted from the 1.12.2 version (+ item tags food_vegetable/fruit/berry/nut/rice/bread/mushroom).
- Latin names for all species/cultivar plants (shown as grey italic tooltip).

Not ported: world generation, advancements, trellis / trellis tower (no assets in the 1.12.2 jar), curled brackets, cactus spike items.

Rev 3:
- Removed duplicate plants (same texture, different name): kept the specific 1.7.10 cultivar names, kept 1.12.2 colours only where 1.7.10 has none.
  Flowers are sorted by plant, then rainbow order (dark red -> red -> coral -> orange -> yellow -> green -> cyan -> blue -> royal -> purple -> magenta -> pink -> white).
- Tall plants are separate blocks: 1.12.2 3-segment plants = Bottom / Middle / Top blocks, 2-block plants = Bottom / Top blocks,
  1.7.10 plants with 6/8/10 stage textures = one block per stage (Stage 1..n). Plants with 2-5 stages still grow with bone meal.
- Epiphytes (18) are wall-mounted blocks that attach to the side of logs/blocks.

Rev 4:
- Medium / large plants are ONE block + ONE item again. 1.7.10 'DOUBLE' plants (taken from the jar's plant table): 2 single-block stages, then
  bottom/top pairs from stage 3 on (growing via bone meal / random ticks, the top is placed when it reaches a 2-block stage). 1.12.2 large plants
  (3 segments, 2 wide) and 2-segment plants use the jar's own models. Honeycomb waxes all segments, axe removes the wax.
- Stage-split entries removed: every single-block growth plant is one inventory item.
- Berry bushes: right-click when fully grown -> berries drop, the bush goes back to an earlier stage.
- Flowers tab: rainbow-order colour flowers first, then flowers with colour families kept together in rainbow order.
- All mod tabs are chained so they sit next to each other.

Rev 5:
- Medium plants (Burning Bush, Cinnamon Fern, Dwarf Pine, Japanese Pieris, Prairie Junegrass, Sheep Laurel, Slender Firethorn, Woolly Bush,
  Yellow Jasmine) are now the real 2-tall/2-wide 1.12.2 plants (one block, bottom/top).
- Tillandsia Ionantha is its own epiphyte again (separate from Sky Plant).
- Creative tabs follow the original mods: Flowers, Overworld Plants, Crops, Aquatic Plants, Trees, Food, Crafting. Their registry names start with
  0_..6_ and are chained, so they stay together and in this order.
- Colour families are sorted by number of colours (most first, rainbow order inside), the rest follows.
- Ground covers and floating plants (water lilies etc.) are flat on the ground/water with random rotation instead of crosses.
- Hanging plants are whole pieces now (1.12.2 ones use top+bottom textures, 1.7.10 ones their complete single-block texture).

## 1.3.0 changes
- Single mod again: your original source + fixes merged in (no pre-compiled `base/`, no extension mod). Build output is ONE jar.
- Hanging plants: new `HangingPlantBlock` (2 blocks; 1.12.2 vines and sweet peas 3 blocks). Attach to ceilings, leaves, chains (vanilla + modded), wall brackets, hooks.
- Water plants: new `WaterPlantBlock`
  - aquatic crops (rice, wild rice, centella, laksa leaf, watercress, water spinach): only in 1-block-deep water on soil
  - lotus / wasabi / taro: in 1-deep water OR on soil/mud next to water OR on mud
  - immersed plants: bottom block in 1-deep water, upper 1-2 blocks above the surface (grow after the last stage)
  - all grow (random tick + bone meal), honeycomb waxes, axe removes wax
- Tall crops (brussels sprout, burdock, cassava, land cress, orache, skirret, corn): stage -> frame mapping fixed.
- Creative tab "PMP: All Plants (colour filter)" + `config/pmp_mikexxx/plant_colors.json`.
- Duplicate Tillandsia ionantha removed (kept "Sky Plant").
- German translation completed (de_de.json): every key translated, swapped cultivar names fixed, "(Stufe n)" suffixes removed.

## 1.4.0 changes
- Leaves: all 55 leaf blocks are tinted again. The leaf textures are grey on purpose; the original mod tints every tree with a FIXED colour
  (not the biome colour). Those colours were read from the original 1.12.2 jar (`DefTree`) and are applied to the block and the item
  (`ClientColors`). Leaf item names use the same colour.
- Water crops (Wasabi, Watercress, Water Spinach, Wild Rice, Asian Rice, Centella, Laksa Leaf, Sacred Lotus, Taro) are real two-block plants with
  5 growth stages: lower block in the water (even 1.7.10 texture 0/2/4/6/8), upper block above the water (odd texture 1/3/5/7/9). Both blocks
  change with every stage. Placing needs free space above; breaking either half drops the plant once. Bone meal / random ticks / honeycomb work on both halves.
- Colour tab: Cephalanthera rubra -> purple, Pachystachys lutea -> yellow, Mertensia ciliata -> purple, Liatris punctata -> purple,
  Dodecatheon meadia -> pink, Cordyline fruticosa -> red, Porcelain Berry -> purple, Kiwi -> yellow, and 23 green hanging plants (bamboos, foliage,
  philodendrons, ivies, creepers, ...) -> green.
- Config `config/pmp_mikexxx/plant_colors.json`: every line is now `"id   # Name (Latin)"` (only the id before the `#` counts). When the mod ships new
  defaults (`_version`), the old file is kept as `plant_colors.old-vN.json` and a new one is written.
- Vines: the 9 `vine_*` plants + 13 wisteria vines are real vines (`PmpVineBlock`, vanilla vine behaviour: cling to blocks, spread, climbable,
  tapered end texture at the bottom). The 9 sweet peas + 9 other `climbing_*` plants (grape, kiwi, hop, ...) are wall-climbing plants
  (`ClimbingPlantBlock`): attach to the side of a block, climbable, 4 growth stages, grow upwards when fully grown (max 6 blocks), honeycomb/axe.

## 1.5.0 changes (ported from the real 1.6.4 mod, PlantMegaPack 2.20)
- New plants: the spooky row (Bat Orchid, Burnt Rose, Devils Claw, Octopus Stinkhorn, Porcupine Tomato, Claw Shrub, Thorn Bush, White Baneberry, 3-block Dead Tree),
  Trained Cedar, Crown Imperial, Sun Bromeliad, Erechtites hieracifolia. Checked against the port by id, name, latin name and texture first - the cylinder/globe/pyramid
  cedars, prickly lettuce, golden spined cactus (= Golden Cereus) and the dandelion sizes (= growth stages) were already in the port.
- Spooky effects (`effect` field in pmp_entries.json): "thorns" (Devils Claw, Porcupine Tomato, Claw Shrub, Thorn Bush) slows and hurts like a sweet berry bush,
  "poison" (White Baneberry, Octopus Stinkhorn) gives short poison. The assignment is a guess from the plant names, change it in pmp_entries.json.
- Classic ferns (2.20 art, 6 small + 3 tall): the grey `...C` textures of the old mod are a second layer tinted with the biome grass colour (`biome: true`, tintindex 0;
  inventory icon uses layer1 tint). Tall classic ferns: top block is biome tinted.
- Dwarf berry bushes replace the "1.7.10" berry row: `berrybush_dwarf_*`, named "Dwarf <Berry> Bush". Beauty/Black(Bramble)/Blue/Orange/Straw use the 2.20 textures
  (bare bush -> berries), elder/goose/huckle/snow keep their 1.7.10 art because 2.20 has no texture for them. Dwarf bushes drop 1-2 berries (mostly 1), big bushes 1-3.
  The real "<Berry> Bush" row (8 stages) is untouched.
- Dwarf Palmetto: new `PalmettoBlock`, a single double-sided plane (the original FLAT render type) that turns to face the player when placed (8 angles, `rot` property).
- Colour tab: Hanging Lavender -> purple, Brittlebush (both) -> yellow, new dark/spooky plants -> other. `ColorConfig.CONFIG_VERSION` is 3, so existing
  config/pmp_mikexxx/plant_colors.json files are regenerated (old one is kept as backup).

## 1.6.0 changes
- Berry bushes: normal bushes (1.7.10 / 1.12.2 art, 8 stages) are the only "<Berry> Bush" row; their inventory icon is the late (berry) stage like the 1.12.2 item model.
  Dwarf bushes are now ONLY the five real 1.6.4 / 2.20 ones (Beauty, Blue, Bramble, Orange, Straw), 2 stages (bare -> berries).
  Removed the four fake dwarf bushes (Elder, Gooseberry, Huckleberry, Snowberry) that used the big 1.7.10 art.
- Crops: item icons now show the grown plant (last growth stage; the more filled half for 2-block crops) instead of the empty seedling.
- Water crops (rice, wild rice, centella, laksa leaf, watercress, water spinach, lotus, wasabi, taro): first growth stage is now a small seedling in the lower block
  (upper block empty); full stalk + leaves only from stage 2 on.
- Taro Root: `item_food_taro_root` + `root_taro` merged into ONE item (`item_food_taro_root`): right-click a block = plant taro, right-click air = eat. `crop_taro` (the plant) stays.
- Trained Cedar stays a single block (in 1.6.4 only Cylinder and Pyramid cedar are double blocks).
- Colour config version 4 (old plant_colors.json is backed up and regenerated, removed bushes dropped).

## 1.7.0 (work in steps)
### Step 1 - duplicates merged, seeds and roots plant their crops
- Same name + identical texture = one item: Quinoa Seeds, Rice (seed + food), Prickly Pear Fruit, Quinoa Cereal, Water Chestnut (root + food), Seaweed Wrap.
  References in recipes / tags were redirected to the kept item.
- Every seed, root and stem now plants its crop (`plant` field in pmp_entries.json): right-click a block = plant, right-click air = eat (if it is food).
  Water chestnut plants the floating water chestnut (`PmpFloatingSeedItem`: right-click water).
- Not merged although they look alike (different art or different name): Sacred Lotus Root, Wasabi Stem, the veget_* / item_food_* vegetable pairs, Healing/Health Salve, the wrap and fruit drink pairs.

### Step 2 - dwarf bushes complete, plants tab order
- New dwarf bushes Elder (yellow), Gooseberry (pale green), Huckleberry (dark blue-violet), Snowberry (white): the 2.20 bush texture with the berry pixels recoloured
  (same 2-stage bare -> berries logic as the other dwarf bushes, same harvest items). Now 9 big + 9 dwarf bushes.
- Overworld plants tab: berry row (normal) first, the dwarf row directly below it, the Angel's Trumpets moved down behind them.

### Step 3 - ferns and the dead tree (no 3-block plants below 1.12.2)
- Removed my wrong "Classic" ferns (single + the three 3-block tall ones). There is only ONE variety of each fern now.
- The 6 ferns that had grey tint overlays in 1.6.4 (Hay Scented, Maidenhair Spleenwort, Ostrich, Scaly Tree, Sword, Woodsia) are biome tinted: every stage texture
  (incl. the bottom/top halves of the 2-block stages) has a grey `*_biome` twin that is tinted with the biome grass colour (block + inventory item).
  Scaly Tree Fern keeps its 5 growth stages: 1 block -> 2 blocks, never 3.
- Dead Tree (2.20) is now 2 stages: young tree (1 block, texture A) -> grown tree (bottom B + top T = 2 blocks). The only 3-block plants left are the 1.12.2 `large_*` ones.

### Step 4 - colour tab
- Config file renamed: `config/pmp_mikexxx_colortab.json` (was `config/pmp_mikexxx/plant_colors.json`; the built-in defaults are `pmp_mikexxx_colortab.json` in the jar). Config version 5:
  an older colour-tab file is backed up as `pmp_mikexxx_colortab.old-vN.json` and regenerated. The old `plant_colors.json` is simply no longer used.
- Every colour group is sorted by shade from the plant textures (pink: bubblegum -> lighter -> more orange pinks; same hue-walk for red, orange, yellow, green, blue, cyan, purple, burgundy;
  whites by brightness). The "all" filter shows the groups one after another in that order.

## 1.7.1 (merge of the safe port and the step-4 port)
- Base: step-4 port (dwarf bushes Elder/Gooseberry/Huckleberry/Snowberry recoloured, seeds/roots plant their crops, duplicates merged, colour tab). Nothing from the safe port was dropped except the merged duplicates.
- Ferns: Hay Scented, Maidenhair Spleenwort, Ostrich, Scaly Tree, Sword and Woodsia are the plain 1.7.10 ferns with their growth stages again (no biome tint, no grey twin textures).
  Ostrich / Scaly Tree / Sword: 2 single-block stages, then 2-block stages.
- Dead Tree: pure 2-block plant (bottom + top), 1.6.4 art; the young one-block stage is gone.
- Re-added: Orange Angel's Trumpet (1.12.2 `large_angtr_ora`; the 1.12.2 lang file defines `large_angtr_red` twice, so the orange name was lost) and Spearleaf Stonecrop (1.12.2 `forec_stosp`).
- Grey (`*C`) 2.20 textures are NOT used for anything now.

## 1.8.0 (work in steps, built on 1.7.1)
### Step 1 - crops
- Crop-tab item icons: every double-block crop shows its UPPER, fully grown block (water crops `_9`, tall crops the `_t` / top texture).
- Crop blocks no longer drop themselves. A crop gives back its seed/root when young (1), and when fully grown seeds (1-2) + produce (1-3).
  If seed and produce are the same item (rice, wild rice, lentils, peanuts, soybeans, taro, lotus, wasabi) you get one evened-out amount (2-4).
  Centella, Laksa Leaf, Watercress and Water Spinach have no seed: they give their leaves, and those leaves (Spinach for Water Spinach) plant the crop again.
- Planting soil: wild plants only stand on soil (dirt tag: dirt, grass, podzol, coarse dirt, mycelium, rooted dirt, moss, mud) or sand. Crops (crop tab, quinoa) stand on
  farmland and the dirt tag, never on stone. Underwater plants (corals, seaweed ...) and water crops keep their own rules. Planters/pots still work.
### Step 2 - leaves, fruiting vines, seeds
- Leaves (`PmpLeavesBlock`): the DEFAULT state is persistent, so leaves placed by hand, from the creative inventory, harvested with shears and placed again, or by WorldEdit/commands
  never decay. Leaves created by a grown tree (sapling, bone meal, `TreeGen`) are NOT persistent: without a log within 6 blocks they decay like in vanilla.
  The fruit tree logs (`log_frtwd`, `logst_frtwd`) are now in `minecraft:logs`, so they hold leaves.
- Leaf drops: shears / silk touch give the leaf. Otherwise a decaying or broken leaf drops the tree's sapling (5 %, fortune improves it) and, for the 29 trees that have a fruit or nut, sometimes that fruit/nut.
- Fruiting vines: Kiwifruit, Common Grape Vine, Golden Hop, Hyacinth Bean and Porcelain Berry give Kiwi / Purple Grapes / Hops / Hyacinth Beans / Porcelain Berries on right-click once a block is fully grown
  (1-2 items, the block goes back to stage 1 and ripens again; honeycomb still waxes).
- Seeds: the planting fix is the farmland rule from step 1 (before, nothing could be planted on farmland). Every seed / root / stem item already planted its crop.
### Step 3 - epiphytes and bamboo
- Epiphytes (orchids, cacti, ferns, mistletoes ...): the 1.12.2 model had the flower plant only on a plane that runs away from the trunk, so from the front you saw just foliage.
  The shared model `_epipv` now has a second plane of the same flower texture parallel to the trunk (visible straight from the front), the original side plane and the two 45 degree foliage planes.
  The shelf fungi (artist's conk, sulphur shelf, turkey tail) are unchanged.
- Bamboo (`BambooStalkBlock`, the 9 `bamboo_*` plants): real stalks like the 1.12.2 original. They can be stacked block on block (also different species), planted on soil/sand/planters,
  and grow upwards by themselves (random tick on the lowest block, bone meal grows 1-2 blocks, honeycomb stops growth of the whole stand, axe removes the wax).
  Segment textures come from the 1.12.2 jar (bare stalk at the ground, leafier higher, leafy top). Breaking a piece breaks everything above it (drops the bamboo).
  Height per species from the 1.7.10 data: Asper 20, Giant Timber 16, Moso 16, Golden 14, Timor Black 14, Wet Forest 12, Tropical Blue 10, Short Tassled 8, Fargesia 6.
  Every stand gets its own limit between about 65 % and 100 % of that, derived from where it stands, so a grove is not all one height.

## 1.9.0 (built on your step3 zip, again in steps)
### Step 1 - bamboo
- Bamboo stalks (`BambooStalkBlock`, the 9 `bamboo_*` plants) are SOLID now: you can no longer walk through them. Collision = the 6x6 px stalk (same as the outline),
  so a stand behaves like a row of fence posts. They got the properties of vanilla bamboo: hardness 1.0, bamboo sound, and they are in `minecraft:mineable/axe`.
  Growth, stacking block on block, bone meal, honeycomb and the "breaking a piece breaks everything above" rule are unchanged.
- Textures and the stalk model were checked against the originals and NOT touched: all 45 stalk textures are pixel-identical in 1.7.10 (`bamboo<Species>0-4`), 1.12.2 (`bamb_*_0-4`)
  and the port, and the shared model `_bampl` is identical to the 1.12.2 one (full-height stalk, 0-16, so stacked pieces join without gaps).
### Step 2 - epiphytes
- Shared epiphyte model `_epipv` (15 epiphytes: orchids, cacti, ferns, mistletoes ...) back to the 1.12.2 layout and then widened: the extra plane that stood parallel to the trunk is GONE again.
  What you see now: the two 45 degree foliage ("leaf") planes exactly like the original, the middle flower plane running away from the trunk, plus two more flower planes of the same flower texture
  fanned 22.5 degrees to each side of the middle one. All three flower planes start at the trunk side (same pivot as the foliage planes), so from the front you see two flower faces
  in front of the foliage, and from the sides you still see the middle one. (Minecraft only allows element rotations of 0 / 22.5 / 45 degrees, so 22.5 is the "slightly diagonal" step.)
- Shelf fungi (artist's conk, sulphur shelf, turkey tail) use their own model `_epiph` and are untouched. Block, hitbox, placement and textures are untouched.

## 1.10.0 (work in steps, built on your s2-epiphytes zip)
### Step 1 - colour tab, duplicates, fig cactus
- The "PMP: All Plants (colour filter)" tab is now the FIRST of the PMP tabs (so it moves up in the tab bar). The filter buttons stay on the left.
- Removed the duplicates Hedera colchica (`hanging_variegated_persian_ivy`, kept the real vine `vine_variegated_persian_ivy`) and Juniperus sabina (`cold_forest_juniper_savin`, kept `shrub_juniper_savin` with its growth stages). Nothing else.
- The "all" filter button is gone (click the active filter again to see everything). New filter "Cream" after Yellow, icon = Yellow Toadflax Flower. Cream holds off-white and tan plants with a yellow/brown undertone.
- Config `config/pmp_mikexxx_colortab.json` (version 6, old file is backed up): the order of the lines IS the order in the tab, and every category list is read exactly as written.
  Ids keep their namespace, so you can add ANY item or block: `"minecraft:dandelion"`, `"othermod:some_flower"` (no namespace = this mod). Unknown ids are skipped. Missing PMP plants go to "other".
- Plants moved to a fitting colour (checked against the real texture pixels): Campanula barbata (Bearded Bellflower) -> blue, Coral Weed (the pink worm coral) and the salmon "coral" flowers -> pink, Feathered Hydroid Coral -> white,
  rushes / horsetail / water chestnut -> green, brown coral / Tangle -> other, off-white and tan plants -> cream, dusty bluish leaf plants (Blue Wheatgrass, Savin Juniper, Prairie Sage, White Sage, Dusty Miller, Mottlecah) -> cyan, and a few more.
- Every list is sorted by a plausible base colour of its category: dark shades at the top, light ones at the bottom (lightness in 5-step bands); inside a band by hue relative to the base colour, then saturation.
- Name colours: 543 plant names that had a generic or clearly wrong colour (e.g. Wildfire, Crown Imperial, Dandelion, the white flowers) now use the colour measured from the plant's own texture.
- Prickly Pear (fig cactus, Opuntia aciculata): item icon = the stage with the most fruit, and it can be harvested by right-click when fully grown (gives Prickly Pear Fruit, goes back to stage 3).

## 1.11.0 (built on your v1100-A zip, in steps)
### Step 1 - bamboo
- The stalk was an open tube (4 side planes, no top), so you looked into it from above. Every stalk piece now has a closed top: a cut-end cap (the 4x4 end texture of that species' pole, 1 px ring around it).
- Leaves: two extra 45 degree leaf planes per piece (same leaf texture as before) so the foliage is visible from all 8 directions instead of 4.
- The leafy top piece (segment 4) got a flat leaf crown (new texture `bamboo_<species>_crown.png`, built from that species' own leaf colours), so the very top is no longer bare when seen from above.
- Nothing else changed (solid collision, growth, drops).

## 1.12.0 (built on your v1110-step1-bamboo zip, in steps)
### Step 1 - cream flowers
- New cream varieties (recoloured from the white / yellow texture, leaves and stems untouched, all petal detail kept): Hydrangea 'Vanille Fraise', Lily 'Butter Pixie', Carnation 'Chantilly',
  Rose 'Pearl', Tulip 'Ivory Floradale', Water Lily 'Lemon Chiffon', Gladiolus 'Cream Spire'. Placed after the yellow one of their family; all are in the Cream filter of the colour tab.
- Colour config version 7 (an older `pmp_mikexxx_colortab.json` is backed up and regenerated so the new plants show up in Cream).

## 1.13.0 (built on your v1120-step1-cream zip, in steps)
### Step 1 - oriental lilies, scillas, flower tab order
- 13 oriental lilies (your 16x16 textures): Black Beauty (burgundy), Red Velvet, Sunset Glow (orange), Yelloween (yellow), Salmon Star (coral), Vanilla Cloud (cream), Green Dragon, Arctic Mist (cyan),
  Midnight Sky (blue), Royal Dusk (royal), Violet Eclipse (purple), Stargazer (pink), Muscadet (white, freckled). ids `flower_oriental_lily_<colour>`.
- 10 Scilla peruviana (your 128x128 textures): classic blue = `Scilla peruviana`, alba, rosea, lutea (cream), rubrum, 'Cerulean Mist' (cyan), 'Lagoon' (teal), 'Malachite' (jade),
  'Amethyst Dream' (purple) and Glacier Scilla 'Snowglobe'. ids `flower_scilla_<name>`.
- Both are in the PMP Flowers tab, the All Plants tab and the colour filters (rubrum = red, jade = green, teal/cyan = cyan, snowglobe = white).
- PMP Flowers tab: everything that has colour varieties first, all single flowers at the very bottom.
- Colour config version 8 (old file is backed up and regenerated so the new plants land in their colour).

## 1.14.0 (built on your v1130-step1-lilies-scillas zip, in steps)
### Step 1 - bamboo
- Removed the leafy "crown" on top of the top bamboo piece: model `_bampl_top`, the 9 `bamboo_<species>_crown.png` textures and their use in the `bamboo_*_s4` models are gone (they were not in any original mod). The top piece now uses the plain stalk model `_bampl` like all other pieces.
- Kept: the closed top of every stalk piece (cap = the original `bambooXPole1` end texture), so the stalk is filled and you do not look into a tube. Everything else is untouched.
### Step 2 - latin names
- Every plant block now has a latin name (tooltip + colour-config source). Added 55: Bat Orchid = Tacca chantrieri, Burnt Rose = Rosa 'Black Baccara', Devils Claw = Proboscidea louisianica,
  Octopus Stinkhorn = Clathrus archeri, Porcupine Tomato = Solanum pyracanthum, Claw Shrub = Senegalia greggii (cat-claw acacia), Thorn Bush = Crataegus monogyna, White Baneberry = Actaea pachypoda,
  Sun Bromeliad = Neoregelia carolinae, Hanging Foliage (5) = Plectranthus scutellarioides (coleus), Hanging Sweet Peas (9) = Lathyrus odoratus, Hanging Flowers (14) = Petunia x atkinsiana.
- Things that are not one species got the next honest level: groundcover flowers (10) = Phlox sp., groundcover grass (2) = Poaceae sp., leaf litter (5) = Folia caduca, Twig = Ramulus, Dead Tree = Arbor mortua.
  Change any of them in `pmp_entries.json` (field `latin`). Seeds, food and building items are not plants and were left as they are.

## 1.15.0 (built on your v1140-step2-latin zip, in steps)
### Step 1 - bamboo back to 1.12.2, latin names that should not exist
- Bamboo: all stalk textures `bamboo_<species>_s0..s4` are byte-identical to the 1.12.2 `bamb_<species>_0..4` (checked for all 9 species), nothing else is used for the stalk and its leaves.
  The model `_bampl` is now exactly the 1.12.2 model (its 16 elements with the original UVs). Removed what was NOT in 1.12.2: the two extra 45 degree leaf planes and the `pole_end` cap texture (an older-version texture).
  The top is still closed so you do not look into a tube: the 5 top faces are painted with a plain 4x4 patch of that species' own 1.12.2 stalk texture (`bamboo_<species>_s0`). That is the only thing that is not in the original model;
  delete the elements with `"up"` faces in `_bampl.json` if you want the exact open original. The leafy crown from before is gone (model and textures) in this zip already.
- Removed the latin name from everything that is not one identifiable plant: groundcover flowers (10, were "Phlox sp."), groundcover leaves (leaf litter, 4), groundcover grass (2),
  Twig / branches, Dead Tree and the Taro Root food item. Kept: Clover, Moss, Ivy (real species), the hanging petunias / coleus and everything else.

## 1.16.0 (built on your v1150-step1-bamboo-latin zip, in steps)
### Step 1 - orchids / bromeliads that are already epiphytes can stand upwards
- New `EpiphyteFloorBlock` (extends `EpiphyteBlock`, new block state `floor`). Used by the 8 orchid / bromeliad epiphytes: Crimson Cattleya, Cuthbert's Dendrobium, King Orchid, Large Foot Dendrobium, Tampa Orchid,
  Lantern Forest, Wildfire, Sky Plant (`"floor": true` in pmp_entries.json). Nothing else about them changed: same model `_epipv` (fanned planes), same textures, same item.
- `floor=true` is the same model rotated `x=90` in the blockstate, so the planes run upwards instead of away from a wall; `facing` is only the spin around the vertical axis. Click the top of a block = upright, click the side of a block = wall placement as before.
- They stand on: dirt tag (dirt, grass, podzol, coarse dirt, moss, mud, mycelium, rooted dirt), sand, logs, leaves, planters, flower pots. Mistletoes, fungi, cacti and the fern stay wall-only.
- Checked, nothing to change: ground plants already stand on the dirt tag (grass, podzol, moss ...), sand, planters/pots and (crops) farmland. Leaf litter, twigs, dead tree, groundcovers, taro root and food have no latin name.
### Step 2 - ground bromeliads / orchids (and the pineapple) can stand on logs
- Logs (`minecraft:logs`, incl. the fruit tree logs) are now a valid block to stand on for the 12 ground plants that are bromeliads or orchids: Cone-headed Guzmania, Jungle Lantern, Portea alatisepala,
  Racinaea fraseri, Silver Vase, Bromelia hemisphaerica, Bromelia laciniosa, Sun Bromeliad, Red Helleborine, Long-bracted Orchid, Yellow Lady Slipper and the Pineapple (`"logs": true` in pmp_entries.json, `PlantBlock.onLogs`).
- Nothing else changed: same cross models, textures, growth stages, bone meal and wax. They still stand on soil / sand as before; the pineapple still takes farmland.
### Step 3 - fruit / nut blocks on the trees (ported from the 1.12.2 jar, `BlockTreeFruit`)
- 31 new blocks `trfrt_<tree>` (16 fruit trees, 12 nut trees, Acai, Banana, Coconut), each with its own item in the Trees tab (named "<Food> (hanging)"), so they can be placed in creative. Textures, the 20 shared `_tfruit_*` models and the 4 stage models per fruit are copied from the jar (8 ages: 0 / 1-3 / 4-6 / 7 show the 4 models).
- Behaviour as in 1.12.2: hangs below a block (the jar requires a log = `isWood`; I also allow leaves so you can place it in creative on a crown), 1/7 chance per random tick to age, bone meal = +1 age, breaking drops the food (1 item, a ripe fruit at age 7 drops 2-5), falls off when the block above is gone. Hitbox 0.2-0.8 / 0.5-1.0 / 0.2-0.8.
- Grown trees (sapling / bone meal, `TreeGen`): fruit and nut trees get 4 branch logs under the crown with a ripe fruit hanging below each, like the 1.12.2 generator. Conifer shaped trees get none.

## 1.16.1 (built on your v1160-step3-tree-fruit-blocks zip)
### Fruit / nut blocks and fruit trees
- The 31 `trfrt_*` blockstates pointed at `pmp_mikexxx:trfrt_..._N` (the 1.12.2 way, models were found in `models/block` automatically). In 1.20.1 the folder has to be written out, so all 248 references now read `pmp_mikexxx:block/trfrt_..._N`. That was why the fruit models were missing.
- Fruit trees (the 16 `leave_fruit_*` trees, saplings with fruitwood) are now grown exactly like `GenTreeBaseFruit` of the 1.12.2 jar: 5 fruitwood logs, one log on each side of the top log with a fruit block hanging below it (age 0 like the jar, it ripens by itself),
  leaves = 5x5 layer without corners (92 % of the blocks) at the top and one above it, then a 3x3 layer without corners on top; leaves only replace air. Nut and jungle trees keep the generic tree from 1.16.0.
### Dead tree and the other 2-high plants
- `spooky_dead_tree` has no growth stages (and never had any). The log was full of "missing model for variant ... segment=middle,stage=N,waxed=...,waterlogged=..." because the 2-high plants own a `middle` segment in their block state
  but their blockstate file only knew `bottom` and `top`. All 28 two-high plants (dead tree, canna, foxglove, goldenrod, burning bush ...) now have a `segment=middle` variant (never shown, a 2-high plant has no middle). No block state or behaviour changed.

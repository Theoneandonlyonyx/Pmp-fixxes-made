package net.mikexxx.pmpport;

import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.FarmBlock;
import net.minecraft.world.level.block.VineBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * World generation of the PMP plants. A placement picks ONE plant of its list and puts `tries` copies of it around the origin,
 * in a random growth stage (so a fresh chunk never shows only grown plants). Modes:
 * ground, water, floating, trunk (on the side of a log), wood / woodcave (on wooden structures), cave (lush caves), hang (under leaves), nether, tree (sapling that grows later),
 * village (like ground, but only next to village paths / buildings) and vcrop (tiny crop garden with water in a village).
 */
public class PmpPatchFeature extends Feature<PmpPatchConfig> {
    public PmpPatchFeature() {
        super(PmpPatchConfig.CODEC);
    }

    @Override
    public boolean place(FeaturePlaceContext<PmpPatchConfig> ctx) {
        WorldGenLevel level = ctx.level();
        RandomSource r = ctx.random();
        PmpPatchConfig cfg = ctx.config();
        BlockPos o = ctx.origin();
        List<PmpPatchConfig.Entry> list = cfg.entries();
        if (list.isEmpty()) return false;
        int total = 0;
        for (PmpPatchConfig.Entry e : list) total += Math.max(1, e.weight());
        int w = r.nextInt(total);
        PmpPatchConfig.Entry pick = list.get(0);
        for (PmpPatchConfig.Entry e : list) {
            w -= Math.max(1, e.weight());
            if (w < 0) {
                pick = e;
                break;
            }
        }
        Block b = ForgeRegistries.BLOCKS.getValue(pick.block());
        if (b == null || b == Blocks.AIR) return false;
        Block partner = pick.partner().map(rl -> ForgeRegistries.BLOCKS.getValue(rl)).orElse(null);
        if (partner == Blocks.AIR) partner = null;
        Block main = b;
        int sp = Math.max(1, cfg.spread());
        int tries = Math.max(1, cfg.tries());
        if (cfg.vary()) {
            // every patch looks different: small tight tufts, normal patches, loose wide-spread drifts and now and then a big meadow
            int roll = r.nextInt(100);
            if (roll < 22) {
                tries = Math.max(1, tries / 3 + r.nextInt(2));
                sp = Math.max(2, sp - 1);
            } else if (roll < 68) {
                tries = Math.max(2, tries - 1 + r.nextInt(3));
            } else if (roll < 90) {
                tries = tries + 1 + r.nextInt(tries + 1);
                sp = sp + 2 + r.nextInt(4);
            } else {
                tries = tries * 2 + r.nextInt(tries + 1);
                sp = sp * 2 + r.nextInt(4);
            }
            sp = Math.min(sp, 16);
        }
        boolean any = false;
        for (int t = 0; t < tries; t++) {
            // a cluster of a bush and its dwarf counterpart: about every second plant is the partner
            b = partner != null && r.nextInt(100) < 45 ? partner : main;
            int x = o.getX() + r.nextInt(sp * 2 + 1) - sp;
            int z = o.getZ() + r.nextInt(sp * 2 + 1) - sp;
            // patches may reach into the neighbouring chunks; only positions the generator can reach right now are used
            if (!level.hasChunk(x >> 4, z >> 4)) continue;
            boolean ok;
            switch (cfg.mode()) {
                case "water" -> ok = placeWater(level, r, b, x, z);
                case "floating" -> ok = placeFloating(level, r, b, x, z);
                case "trunk" -> ok = placeTrunk(level, r, b, x, z);
                case "vhang" -> ok = placeVillageHang(level, r, b, x, z);
                case "shallow" -> ok = placeShallow(level, r, b, x, z);
                case "logtop" -> ok = placeLogTop(level, r, b, x, z);
                case "groundlog" -> ok = placeGroundNearLog(level, r, b, x, z);
                case "wood" -> ok = placeWood(level, r, b, x, z, o.getY(), false);
                case "woodcave" -> ok = placeWood(level, r, b, x, z, o.getY(), true);
                case "cave" -> ok = placeCave(level, r, b, x, z, o.getY());
                case "nether" -> ok = placeScan(level, r, b, x, z, o.getY());
                case "tree" -> ok = placeTree(level, r, b, x, z);
                case "village" -> ok = placeGround(level, r, b, x, z, true);
                case "vcrop" -> ok = placeGarden(level, r, b, x, z);
                default -> ok = placeGround(level, r, b, x, z, false);
            }
            any |= ok;
        }
        return any;
    }

    // ------------------------------------------------------------------ helpers

    /** default state with a random growth stage (any stage, so about one plant in ten is grown) */
    private static BlockState prepared(Block b, RandomSource r) {
        BlockState s = b.defaultBlockState();
        Property<?> sp = b.getStateDefinition().getProperty("stage");
        if (sp instanceof IntegerProperty ip) {
            // the property allows 0..9, but every plant has its own last stage - never go past it
            int max = Collections.max(ip.getPossibleValues());
            if (b instanceof PlantBlock pb) max = Math.min(max, pb.maxStage());
            else if (b instanceof WaterPlantBlock wp) max = Math.min(max, wp.maxGrowth());
            else if (b instanceof ClimbingPlantBlock) max = Math.min(max, 3);
            s = s.setValue(ip, r.nextInt(max + 1));
        }
        Property<?> fp = b.getStateDefinition().getProperty("facing");
        if (fp instanceof DirectionProperty dp) {
            Direction d = Direction.Plane.HORIZONTAL.getRandomDirection(r);
            if (dp.getPossibleValues().contains(d)) s = s.setValue(dp, d);
        }
        return s;
    }

    private static BlockState withBool(BlockState s, String name, boolean v) {
        Property<?> p = s.getBlock().getStateDefinition().getProperty(name);
        if (p instanceof BooleanProperty bp) return s.setValue(bp, v);
        return s;
    }

    private static boolean put(WorldGenLevel level, Block b, BlockPos p, BlockState s) {
        if (!s.canSurvive(level, p)) return false;
        if (b instanceof HangingPlantBlock hp) return hp.placeGen(level, p, s);
        if (b instanceof PlantBlock pb) return pb.placeGen(level, p, s);
        if (b instanceof WaterPlantBlock wp) return wp.placeGen(level, p, s);
        level.setBlock(p, s, 2);
        return true;
    }

    // ------------------------------------------------------------------ modes

    private boolean placeGround(WorldGenLevel level, RandomSource r, Block b, int x, int z, boolean village) {
        int y = level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, x, z);
        BlockPos p = new BlockPos(x, y, z);
        if (!level.getBlockState(p).isAir() || !level.getFluidState(p).isEmpty()) return false;
        if (village && !looksLikeVillage(level, p)) return false;
        BlockState s = withBool(prepared(b, r), "floor", true);
        return put(level, b, p, s);
    }

    private boolean placeWater(WorldGenLevel level, RandomSource r, Block b, int x, int z) {
        int y = level.getHeight(Heightmap.Types.OCEAN_FLOOR_WG, x, z);
        BlockPos p = new BlockPos(x, y, z);
        if (!level.getFluidState(p).is(FluidTags.WATER)) return false;
        BlockState s = withBool(prepared(b, r), "waterlogged", true);
        return put(level, b, p, s);
    }

    private boolean placeFloating(WorldGenLevel level, RandomSource r, Block b, int x, int z) {
        int y = level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, x, z);
        BlockPos p = new BlockPos(x, y, z);
        if (!level.getBlockState(p).isAir()) return false;
        return put(level, b, p, prepared(b, r));
    }

    /** on the side of a tree trunk (epiphytes, climbers, vines) */
    private boolean placeTrunk(WorldGenLevel level, RandomSource r, Block b, int x, int z) {
        for (int k = 0; k < 10; k++) {
            int cx = x + r.nextInt(7) - 3;
            int cz = z + r.nextInt(7) - 3;
            int top = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, cx, cz) - 1;
            BlockPos topPos = new BlockPos(cx, top, cz);
            if (!level.getBlockState(topPos).is(BlockTags.LOGS)) continue;
            int run = 0;
            while (run < 9 && level.getBlockState(topPos.below(run)).is(BlockTags.LOGS)) run++;
            BlockPos log = topPos.below(r.nextInt(run));
            List<Direction> dirs = new ArrayList<>(Direction.Plane.HORIZONTAL.stream().toList());
            Collections.shuffle(dirs, new java.util.Random(r.nextLong()));
            for (Direction d : dirs) {
                BlockPos n = log.relative(d);
                if (!level.getBlockState(n).isAir()) continue;
                BlockState base = withBool(prepared(b, r), "floor", false);
                if (b instanceof VineBlock) {
                    BlockState vs = b.defaultBlockState().setValue(VineBlock.getPropertyForFace(d.getOpposite()), true);
                    if (vs.canSurvive(level, n)) {
                        level.setBlock(n, vs, 2);
                        return true;
                    }
                    continue;
                }
                for (Direction f : Direction.Plane.HORIZONTAL) {
                    Property<?> fp = b.getStateDefinition().getProperty("facing");
                    if (!(fp instanceof DirectionProperty dp)) break;
                    BlockState s = base.setValue(dp, f);
                    if (s.canSurvive(level, n)) {
                        level.setBlock(n, s, 2);
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /** hanging plants (they come with a wooden bowl) only in villages: under the eaves of a building */
    private boolean placeVillageHang(WorldGenLevel level, RandomSource r, Block b, int x, int z) {
        int top = level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);
        BlockPos start = new BlockPos(x, top, z);
        if (!looksLikeVillage(level, start)) return false;
        for (int y = top; y > top - 8; y--) {
            BlockPos p = new BlockPos(x, y, z);
            BlockState up = level.getBlockState(p.above());
            if (level.getBlockState(p).isAir() && (up.is(BlockTags.PLANKS) || up.is(BlockTags.LOGS) || up.is(BlockTags.WOODEN_FENCES))) {
                if (put(level, b, p, prepared(b, r))) return true;
            }
        }
        return false;
    }

    /** water plants of shallow water only (reeds, rushes, sedges) */
    private boolean placeShallow(WorldGenLevel level, RandomSource r, Block b, int x, int z) {
        int y = level.getHeight(Heightmap.Types.OCEAN_FLOOR_WG, x, z);
        BlockPos p = new BlockPos(x, y, z);
        if (!level.getFluidState(p).is(FluidTags.WATER) || level.getFluidState(p.above(2)).is(FluidTags.WATER)) return false;
        return put(level, b, p, withBool(prepared(b, r), "waterlogged", true));
    }

    /** bromeliads / orchids that may stand on logs: on top of a trunk or a fallen log */
    private boolean placeLogTop(WorldGenLevel level, RandomSource r, Block b, int x, int z) {
        for (int k = 0; k < 8; k++) {
            int cx = x + r.nextInt(7) - 3;
            int cz = z + r.nextInt(7) - 3;
            BlockPos log = new BlockPos(cx, level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, cx, cz) - 1, cz);
            if (!level.getBlockState(log).is(BlockTags.LOGS) || !level.getBlockState(log.above()).isAir()) continue;
            if (put(level, b, log.above(), prepared(b, r))) return true;
        }
        return false;
    }

    /** floor epiphytes on the ground, only close to a log */
    private boolean placeGroundNearLog(WorldGenLevel level, RandomSource r, Block b, int x, int z) {
        int y = level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, x, z);
        BlockPos p = new BlockPos(x, y, z);
        if (!level.getBlockState(p).isAir() || !level.getFluidState(p).isEmpty()) return false;
        boolean log = false;
        for (int dx = -3; dx <= 3 && !log; dx++)
            for (int dz = -3; dz <= 3 && !log; dz++)
                for (int dy = -1; dy <= 2; dy++)
                    if (level.getBlockState(p.offset(dx, dy, dz)).is(BlockTags.LOGS)) {
                        log = true;
                        break;
                    }
        if (!log) return false;
        return put(level, b, p, withBool(prepared(b, r), "floor", true));
    }

    /** nether: a floor near the height of the origin */
    private boolean placeScan(WorldGenLevel level, RandomSource r, Block b, int x, int z, int y0) {
        for (int y = y0 + 6; y > y0 - 10; y--) {
            BlockPos p = new BlockPos(x, y, z);
            if (!level.getBlockState(p).isAir()) continue;
            BlockPos below = p.below();
            if (level.getBlockState(below).isFaceSturdy(level, below, Direction.UP)) return put(level, b, p, prepared(b, r));
        }
        return false;
    }

    /**
     * climbers on the planks / slabs / stairs of generated wooden structures (villages, mansions, outposts, mineshafts).
     * `underground` = scan around the height of the origin (mineshafts), otherwise from the surface downwards.
     */
    private boolean placeWood(WorldGenLevel level, RandomSource r, Block b, int x, int z, int y0, boolean underground) {
        int top = level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, x, z);
        int from = underground ? y0 + 6 : top + 2;
        int to = underground ? y0 - 8 : top - 14;
        from = Math.min(from, level.getMaxBuildHeight() - 2);
        to = Math.max(to, level.getMinBuildHeight() + 1);
        for (int y = from; y >= to; y--) {
            BlockPos wall = new BlockPos(x, y, z);
            BlockState ws = level.getBlockState(wall);
            if (!(ws.is(BlockTags.PLANKS) || ws.is(BlockTags.WOODEN_SLABS) || ws.is(BlockTags.WOODEN_STAIRS))) continue;
            if (attachTo(level, r, b, wall)) return true;
        }
        return false;
    }

    /** a climber on the side of any solid block next to a free cave space (lush caves) */
    private boolean placeCave(WorldGenLevel level, RandomSource r, Block b, int x, int z, int y0) {
        Property<?> fp = b.getStateDefinition().getProperty("facing");
        if (!(fp instanceof DirectionProperty dp)) return false;
        int min = level.getMinBuildHeight() + 1;
        int max = level.getMaxBuildHeight() - 2;
        int off = r.nextInt(17);
        for (int k = 0; k < 17; k++) {
            int y = y0 - 8 + (off + k) % 17;
            if (y < min || y > max) continue;
            BlockPos p = new BlockPos(x, y, z);
            if (!level.getBlockState(p).isAir() || !level.getFluidState(p).isEmpty()) continue;
            BlockState base = withBool(prepared(b, r), "floor", false);
            for (Direction f : Direction.Plane.HORIZONTAL) {
                if (!dp.getPossibleValues().contains(f)) continue;
                BlockState s = base.setValue(dp, f);
                if (s.canSurvive(level, p)) {
                    level.setBlock(p, s, 2);
                    return true;
                }
            }
        }
        return false;
    }

    /** puts a climbing plant on a free side of the given wall block */
    private boolean attachTo(WorldGenLevel level, RandomSource r, Block b, BlockPos wall) {
        Property<?> fp = b.getStateDefinition().getProperty("facing");
        if (!(fp instanceof DirectionProperty dp)) return false;
        List<Direction> dirs = new ArrayList<>(Direction.Plane.HORIZONTAL.stream().toList());
        Collections.shuffle(dirs, new java.util.Random(r.nextLong()));
        for (Direction d : dirs) {
            BlockPos n = wall.relative(d);
            if (!level.getBlockState(n).isAir() || !level.getFluidState(n).isEmpty()) continue;
            BlockState base = withBool(prepared(b, r), "floor", false);
            for (Direction f : Direction.Plane.HORIZONTAL) {
                if (!dp.getPossibleValues().contains(f)) continue;
                BlockState s = base.setValue(dp, f);
                if (s.canSurvive(level, n)) {
                    level.setBlock(n, s, 2);
                    return true;
                }
            }
        }
        return false;
    }

    /** a sapling that is turned into a real tree a moment later (see PmpWorldgen) */
    private boolean placeTree(WorldGenLevel level, RandomSource r, Block b, int x, int z) {
        int y = level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, x, z);
        BlockPos p = new BlockPos(x, y, z);
        if (!level.getBlockState(p).isAir() || !level.getFluidState(p).isEmpty()) return false;
        if (!(b instanceof SaplingTreeBlock)) return false;
        BlockState s = b.defaultBlockState();
        if (!s.canSurvive(level, p)) return false;
        level.setBlock(p, s, 2);
        PmpWorldgen.queueTree(level.getLevel().dimension(), p);
        return true;
    }

    // ------------------------------------------------------------------ villages

    private static boolean looksLikeVillage(WorldGenLevel level, BlockPos p) {
        int paths = 0;
        boolean building = false;
        for (int dx = -8; dx <= 8; dx += 2) {
            for (int dz = -8; dz <= 8; dz += 2) {
                for (int dy = -2; dy <= 3; dy++) {
                    BlockState st = level.getBlockState(p.offset(dx, dy, dz));
                    if (st.is(Blocks.DIRT_PATH)) paths++;
                    else if (st.is(BlockTags.PLANKS) || st.is(Blocks.HAY_BLOCK) || st.is(Blocks.COMPOSTER) || st.is(Blocks.FARMLAND)) building = true;
                }
            }
        }
        return paths >= 2 && building;
    }

    /** a small classic farm: a water channel of three blocks with eight farmland blocks around it, a crop on each (village only) */
    private boolean placeGarden(WorldGenLevel level, RandomSource r, Block b, int x, int z) {
        int y = level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, x, z);
        BlockPos p = new BlockPos(x, y, z);
        BlockPos g = p.below();
        if (!level.getBlockState(p).isAir() || !level.getBlockState(g).is(Blocks.GRASS_BLOCK)) return false;
        if (!looksLikeVillage(level, p)) return false;
        Direction ax = r.nextBoolean() ? Direction.EAST : Direction.SOUTH;
        Direction sd = ax.getClockWise();
        List<BlockPos> water = new ArrayList<>();
        List<BlockPos> soil = new ArrayList<>();
        for (int i = 0; i < 3; i++) water.add(g.relative(ax, i));
        for (int i = 0; i < 3; i++) {
            soil.add(g.relative(ax, i).relative(sd));
            soil.add(g.relative(ax, i).relative(sd.getOpposite()));
        }
        soil.add(g.relative(ax.getOpposite()));
        soil.add(g.relative(ax, 3));
        for (BlockPos w : water) {
            BlockState ws = level.getBlockState(w);
            if (!ws.is(Blocks.GRASS_BLOCK) || !level.getBlockState(w.above()).isAir()) return false;
        }
        List<BlockPos> ok = new ArrayList<>();
        for (BlockPos n : soil) {
            BlockState ns = level.getBlockState(n);
            if (ns.isAir() || !level.getFluidState(n).isEmpty() || !ns.isSolid()) return false; // water must stay inside
            if ((ns.is(Blocks.GRASS_BLOCK) || ns.is(Blocks.DIRT)) && level.getBlockState(n.above()).isAir()) ok.add(n);
        }
        if (ok.size() < 5) return false;
        for (BlockPos w : water) level.setBlock(w, Blocks.WATER.defaultBlockState(), 2);
        int planted = 0;
        for (BlockPos n : ok) {
            level.setBlock(n, Blocks.FARMLAND.defaultBlockState().setValue(FarmBlock.MOISTURE, 7), 2);
            if (put(level, b, n.above(), prepared(b, r))) planted++;
        }
        return planted > 0;
    }
}

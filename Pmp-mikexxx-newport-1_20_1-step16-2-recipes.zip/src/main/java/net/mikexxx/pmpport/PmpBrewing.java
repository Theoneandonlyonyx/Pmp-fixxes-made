package net.mikexxx.pmpport;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.item.alchemy.PotionUtils;
import net.minecraft.world.item.alchemy.Potions;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraftforge.common.brewing.BrewingRecipe;
import net.minecraftforge.common.brewing.BrewingRecipeRegistry;
import net.minecraftforge.common.crafting.StrictNBTIngredient;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * Brewing stand recipes of the 1.12.2 jar (RecipeBrewing.initPlantRoot): awkward potion + medicinal root = the potion,
 * the potion + the same root again = the long (healing: strong) version. Splash / lingering come from gunpowder as usual.
 */
public final class PmpBrewing {
    private PmpBrewing() {}

    private static void mix(Potion from, String root, Potion to) {
        Item it = ForgeRegistries.ITEMS.getValue(new ResourceLocation(PmpMod.MODID, root));
        if (it == null || it == Items.AIR) return;
        ItemStack in = PotionUtils.setPotion(new ItemStack(Items.POTION), from);
        ItemStack out = PotionUtils.setPotion(new ItemStack(Items.POTION), to);
        BrewingRecipeRegistry.addRecipe(new BrewingRecipe(StrictNBTIngredient.of(in), Ingredient.of(it), out));
    }

    private static void root(String root, Potion normal, Potion longer) {
        mix(Potions.AWKWARD, root, normal);
        mix(normal, root, longer);
    }

    public static void register() {
        root("root_firer", Potions.FIRE_RESISTANCE, Potions.LONG_FIRE_RESISTANCE);
        root("root_healt", Potions.HEALING, Potions.STRONG_HEALING);
        root("root_invis", Potions.INVISIBILITY, Potions.LONG_INVISIBILITY);
        root("root_leapi", Potions.LEAPING, Potions.LONG_LEAPING);
        root("root_ntvis", Potions.NIGHT_VISION, Potions.LONG_NIGHT_VISION);
        root("root_poiso", Potions.POISON, Potions.LONG_POISON);
        root("root_stren", Potions.STRENGTH, Potions.LONG_STRENGTH);
        root("root_swift", Potions.SWIFTNESS, Potions.LONG_SWIFTNESS);
        root("root_watbr", Potions.WATER_BREATHING, Potions.LONG_WATER_BREATHING);
    }
}

package net.mikexxx.pmpport;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.BonemealableBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * Tree fruit / nut as its own block (1.12.2 BlockTreeFruit): hangs below a log (branch) or leaves of ITS OWN tree,
 * 8 ages (0-7), grows on random ticks (1/7), bone meal = +1 age. Breaking it drops the food: 1 item, a ripe one (age 7)
 * drops 2-5. Falls off (drops) when the block above is gone.
 * Honeycomb (WAXED) stops the ageing, an axe removes the wax again.
 */
public class TreeFruitBlock extends Block implements BonemealableBlock {
    public static final IntegerProperty AGE = BlockStateProperties.AGE_7;
    public static final BooleanProperty WAXED = BooleanProperty.create("waxed");
    private static final VoxelShape SHAPE = Block.box(3.2, 8, 3.2, 12.8, 16, 12.8);

    private final String treeKey;   // e.g. "fruit_apric": the tree that owns this fruit is made of leave_<treeKey>
    private Block leaf;

    public TreeFruitBlock(Properties p, String treeKey) {
        super(p);
        this.treeKey = treeKey;
        registerDefaultState(stateDefinition.any().setValue(AGE, 0).setValue(WAXED, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
        b.add(AGE, WAXED);
    }

    @Override
    public VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
        return SHAPE;
    }

    private Block ownLeaf() {
        if (leaf == null) leaf = ForgeRegistries.BLOCKS.getValue(new ResourceLocation(PmpMod.MODID, "leave_" + treeKey));
        return leaf;
    }

    /** the fruit may only hang under the leaves of its own tree, or under a branch log that has those leaves around it */
    private boolean ownTreeAbove(LevelReader l, BlockPos above) {
        Block lf = ownLeaf();
        BlockState a = l.getBlockState(above);
        if (lf == null || lf == net.minecraft.world.level.block.Blocks.AIR) return a.is(BlockTags.LOGS) || a.is(BlockTags.LEAVES);
        if (a.is(lf)) return true;
        if (!a.is(BlockTags.LOGS)) return false;
        for (int dx = -3; dx <= 3; dx++)
            for (int dy = -2; dy <= 3; dy++)
                for (int dz = -3; dz <= 3; dz++)
                    if (l.getBlockState(above.offset(dx, dy, dz)).is(lf)) return true;
        return false;
    }

    @Override
    public boolean canSurvive(BlockState s, LevelReader l, BlockPos p) {
        return ownTreeAbove(l, p.above());
    }

    @Override
    public void neighborChanged(BlockState s, Level l, BlockPos p, Block b, BlockPos from, boolean moved) {
        if (!l.isClientSide && !s.canSurvive(l, p)) l.destroyBlock(p, true);
    }

    @Override
    public void randomTick(BlockState s, ServerLevel l, BlockPos p, RandomSource r) {
        if (!s.canSurvive(l, p)) {
            l.destroyBlock(p, true);
            return;
        }
        if (s.getValue(WAXED)) return;
        int age = s.getValue(AGE);
        if (age < 7 && r.nextInt(7) == 0) l.setBlock(p, s.setValue(AGE, age + 1), 2);
    }

    @Override
    public boolean isValidBonemealTarget(LevelReader l, BlockPos p, BlockState s, boolean client) {
        return !s.getValue(WAXED) && s.getValue(AGE) < 7;
    }

    @Override
    public boolean isBonemealSuccess(Level l, RandomSource r, BlockPos p, BlockState s) {
        return true;
    }

    @Override
    public void performBonemeal(ServerLevel l, RandomSource r, BlockPos p, BlockState s) {
        l.setBlock(p, s.setValue(AGE, Math.min(7, s.getValue(AGE) + 1)), 2);
    }

    // ----- wax: honeycomb stops the ageing, an axe scrapes it off -----
    @Override
    public InteractionResult use(BlockState s, Level l, BlockPos p, Player pl, InteractionHand h, BlockHitResult hit) {
        ItemStack held = pl.getItemInHand(h);
        boolean waxed = s.getValue(WAXED);
        if (held.is(Items.HONEYCOMB) && !waxed) {
            if (!l.isClientSide) {
                l.setBlock(p, s.setValue(WAXED, true), 3);
                l.levelEvent(null, 3003, p, 0);
                if (!pl.getAbilities().instabuild) held.shrink(1);
            }
            return InteractionResult.sidedSuccess(l.isClientSide);
        }
        if (held.getItem() instanceof AxeItem && waxed) {
            if (!l.isClientSide) {
                l.setBlock(p, s.setValue(WAXED, false), 3);
                l.levelEvent(null, 3004, p, 0);
                held.hurtAndBreak(1, pl, e -> e.broadcastBreakEvent(h));
            }
            return InteractionResult.sidedSuccess(l.isClientSide);
        }
        return InteractionResult.PASS;
    }
}

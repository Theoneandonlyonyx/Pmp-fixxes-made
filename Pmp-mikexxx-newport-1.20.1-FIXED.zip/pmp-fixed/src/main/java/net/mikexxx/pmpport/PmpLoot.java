package net.mikexxx.pmpport;

import com.google.common.base.Suppliers;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraftforge.common.loot.IGlobalLootModifier;
import net.minecraftforge.common.loot.LootModifier;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.function.Supplier;

/**
 * Global loot modifier "pmp_mikexxx:add_table": rolls an extra loot table (field "table") on top of whatever the chest
 * (or other loot) already gives. Used to spread seeds / flowers / hanging plants through vanilla chests without replacing them.
 */
public class PmpLoot {
    public static final DeferredRegister<Codec<? extends IGlobalLootModifier>> SERIALIZERS =
            DeferredRegister.create(ForgeRegistries.Keys.GLOBAL_LOOT_MODIFIER_SERIALIZERS, PmpMod.MODID);

    public static class AddTable extends LootModifier {
        public static final Supplier<Codec<AddTable>> CODEC = Suppliers.memoize(() -> RecordCodecBuilder.create(inst ->
                codecStart(inst).and(ResourceLocation.CODEC.fieldOf("table").forGetter(m -> m.table)).apply(inst, AddTable::new)));

        private final ResourceLocation table;

        public AddTable(LootItemCondition[] conditions, ResourceLocation table) {
            super(conditions);
            this.table = table;
        }

        @Override
        protected ObjectArrayList<ItemStack> doApply(ObjectArrayList<ItemStack> loot, LootContext context) {
            context.getResolver().getLootTable(table).getRandomItemsRaw(context, loot::add);
            return loot;
        }

        @Override
        public Codec<? extends IGlobalLootModifier> codec() {
            return CODEC.get();
        }
    }

    static {
        SERIALIZERS.register("add_table", AddTable.CODEC);
    }
}

package net.mikexxx.pmpport;

import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraftforge.common.loot.IGlobalLootModifier;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.ArrayDeque;
import java.util.Iterator;

/** registries of the world generation (feature + loot modifier) and the delayed growth of generated trees */
@Mod.EventBusSubscriber(modid = PmpMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class PmpWorldgen {
    public static final DeferredRegister<Feature<?>> FEATURES = DeferredRegister.create(ForgeRegistries.FEATURES, PmpMod.MODID);
    public static final RegistryObject<Feature<PmpPatchConfig>> PATCH = FEATURES.register("patch", PmpPatchFeature::new);

    public static final DeferredRegister<Codec<? extends IGlobalLootModifier>> LOOT =
            DeferredRegister.create(ForgeRegistries.Keys.GLOBAL_LOOT_MODIFIER_SERIALIZERS, PmpMod.MODID);
    public static final RegistryObject<Codec<? extends IGlobalLootModifier>> ADD_ITEMS = LOOT.register("add_items", PmpLootModifier.CODEC);

    private record Pending(ResourceKey<Level> dim, BlockPos pos, int[] age) {}

    private static final ArrayDeque<Pending> PENDING = new ArrayDeque<>();

    private PmpWorldgen() {}

    public static synchronized void queueTree(ResourceKey<Level> dim, BlockPos pos) {
        if (PENDING.size() > 600) PENDING.pollFirst();
        PENDING.addLast(new Pending(dim, pos.immutable(), new int[]{0}));
    }

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.level instanceof ServerLevel level)) return;
        synchronized (PmpWorldgen.class) {
            if (PENDING.isEmpty()) return;
            int done = 0;
            Iterator<Pending> it = PENDING.iterator();
            while (it.hasNext() && done < 3) {
                Pending p = it.next();
                if (p.dim() != level.dimension()) continue;
                p.age()[0]++;
                BlockPos pos = p.pos();
                // wait until the chunks around are loaded, give up after about 5 minutes
                if (!level.hasChunkAt(pos) || !level.hasChunkAt(pos.offset(6, 0, 6)) || !level.hasChunkAt(pos.offset(-6, 0, -6))
                        || !level.hasChunkAt(pos.offset(6, 0, -6)) || !level.hasChunkAt(pos.offset(-6, 0, 6))) {
                    if (p.age()[0] > 6000) it.remove();
                    continue;
                }
                it.remove();
                done++;
                BlockState s = level.getBlockState(pos);
                if (s.getBlock() instanceof SaplingTreeBlock sap) sap.growNow(level, pos, level.getRandom());
            }
        }
    }
}

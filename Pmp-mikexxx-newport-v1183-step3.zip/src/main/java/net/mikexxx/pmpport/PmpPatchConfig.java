package net.mikexxx.pmpport;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.levelgen.feature.configurations.FeatureConfiguration;

import java.util.List;

/** One plant of the list is picked per placement (by weight) and `tries` copies of it are put around the origin. */
public record PmpPatchConfig(List<Entry> entries, int tries, int spread, String mode) implements FeatureConfiguration {
    public record Entry(ResourceLocation block, int weight) {
        public static final Codec<Entry> CODEC = RecordCodecBuilder.create(i -> i.group(
                ResourceLocation.CODEC.fieldOf("block").forGetter(Entry::block),
                Codec.INT.optionalFieldOf("weight", 1).forGetter(Entry::weight)
        ).apply(i, Entry::new));
    }

    public static final Codec<PmpPatchConfig> CODEC = RecordCodecBuilder.create(i -> i.group(
            Entry.CODEC.listOf().fieldOf("entries").forGetter(PmpPatchConfig::entries),
            Codec.INT.optionalFieldOf("tries", 4).forGetter(PmpPatchConfig::tries),
            Codec.INT.optionalFieldOf("spread", 5).forGetter(PmpPatchConfig::spread),
            Codec.STRING.optionalFieldOf("mode", "ground").forGetter(PmpPatchConfig::mode)
    ).apply(i, PmpPatchConfig::new));
}

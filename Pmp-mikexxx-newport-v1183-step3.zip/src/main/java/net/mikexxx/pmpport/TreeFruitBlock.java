package net.mikexxx.pmpport;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.BonemealableBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.List;

/**
 * Hanging tree fruit / nut. Each age is a different look (the 4 models 0..3, no repeated stage).
 * Bone meal and random ticks advance one look; the last look is ripe.
 * Ripe: right-click drops 3-5 fruit and the fruit starts over at the first look.
 * Breaking a ripe fruit drops 3-5. An unripe fruit is destroyed and drops nothing, unless the tool
 * is shears or has Silk Touch (the same tools that properly drop grass) — then it drops 1 fruit.
 * Hangs under any leaves or any log. Honeycomb stops growth, an axe scrapes the wax off.
 */
public class TreeFruitBlock extends Block implements BonemealableBlock {
    /** 4 distinct looks. Age 3 is ripe. */
    public static final int MAX_AGE = 3;
    public static final IntegerProperty AGE = IntegerProperty.create("age", 0, MAX_AGE);
    public static final BooleanProperty WAXED = BooleanProperty.create("waxed");
    private static final VoxelShape SHAPE = Block.box(3.2, 8, 3.2, 12.8, 16, 12.8);

    private Item drop;

    public TreeFruitBlock(Properties p, String treeKey) {
        super(p);
        registerDefaultState(stateDefinition.any().setValue(AGE, 0).setValue(WAXED, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
        b.add(AGE, WAXED);
    }

    @Override
    public VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
        return SHAPE;
    }

    /** the food item that places this block (set on the item entry as "plant") */
    private Item fruitItem() {
        if (drop == null || drop == Items.AIR) {
            for (Item it : ForgeRegistries.ITEMS) {
                if (it instanceof net.minecraft.world.item.ItemNameBlockItem seed && seed.getBlock() == this) {
                    drop = it;
                    break;
                }
            }
        }
        return drop == null ? Items.AIR : drop;
    }

    private static boolean foliageOrLog(BlockState a) {
        return a.is(BlockTags.LEAVES) || a.is(BlockTags.LOGS) || a.getBlock() instanceof LeavesBlock || a.getBlock() instanceof PmpLeavesBlock;
    }

    @Override
    public boolean canSurvive(BlockState s, LevelReader l, BlockPos p) {
        return foliageOrLog(l.getBlockState(p.above()));
    }

    @Override
    public void neighborChanged(BlockState s, Level l, BlockPos p, Block b, BlockPos from, boolean moved) {
        if (!l.isClientSide && !s.canSurvive(l, p)) l.destroyBlock(p, true);
    }

    @Override
    public void randomTick(BlockState s, ServerLevel l, BlockPos p, RandomSource r) {
        if (!s.canSurvive(l, p)) {
            l.destroyBlock(p, true);
            return;
        }
        if (s.getValue(WAXED)) return;
        int age = s.getValue(AGE);
        if (age < MAX_AGE && r.nextInt(7) == 0) l.setBlock(p, s.setValue(AGE, age + 1), 2);
    }

    @Override
    public boolean isValidBonemealTarget(LevelReader l, BlockPos p, BlockState s, boolean client) {
        return !s.getValue(WAXED) && s.getValue(AGE) < MAX_AGE;
    }

    @Override
    public boolean isBonemealSuccess(Level l, RandomSource r, BlockPos p, BlockState s) {
        return true;
    }

    @Override
    public void performBonemeal(ServerLevel l, RandomSource r, BlockPos p, BlockState s) {
        l.setBlock(p, s.setValue(AGE, Math.min(MAX_AGE, s.getValue(AGE) + 1)), 2);
    }

    private void harvest(Level l, BlockPos p, BlockState s, Player pl) {
        int n = 3 + l.random.nextInt(3);
        Block.popResource(l, p, new ItemStack(fruitItem(), n));
        l.playSound(null, p, SoundEvents.SWEET_BERRY_BUSH_PICK_BERRIES, SoundSource.BLOCKS, 1.0F, 0.8F + l.random.nextFloat() * 0.4F);
        // back to the first look so it has to grow again (not an infinite ripe fruit)
        l.setBlock(p, s.setValue(AGE, 0), 3);
    }

    @Override
    public InteractionResult use(BlockState s, Level l, BlockPos p, Player pl, InteractionHand h, BlockHitResult hit) {
        ItemStack held = pl.getItemInHand(h);
        boolean waxed = s.getValue(WAXED);
        if (held.is(Items.HONEYCOMB) && !waxed) {
            if (!l.isClientSide) {
                l.setBlock(p, s.setValue(WAXED, true), 3);
                l.levelEvent(null, 3003, p, 0);
                if (!pl.getAbilities().instabuild) held.shrink(1);
            }
            return InteractionResult.sidedSuccess(l.isClientSide);
        }
        if (held.getItem() instanceof AxeItem && waxed) {
            if (!l.isClientSide) {
                l.setBlock(p, s.setValue(WAXED, false), 3);
                l.levelEvent(null, 3004, p, 0);
                held.hurtAndBreak(1, pl, e -> e.broadcastBreakEvent(h));
            }
            return InteractionResult.sidedSuccess(l.isClientSide);
        }
        if (s.getValue(AGE) >= MAX_AGE && !held.is(Items.HONEYCOMB)) {
            if (!l.isClientSide) harvest(l, p, s, pl);
            return InteractionResult.sidedSuccess(l.isClientSide);
        }
        return InteractionResult.PASS;
    }

    /** ripe breaks drop 3-5; unripe drops nothing unless shears or Silk Touch (grass-dropping tools), then 1 */
    @Override
    public List<ItemStack> getDrops(BlockState state, LootParams.Builder builder) {
        LootParams params = builder.withParameter(LootContextParams.BLOCK_STATE, state).create(net.minecraft.world.level.storage.loot.parameters.LootContextParamSets.BLOCK);
        ItemStack tool = params.getParamOrNull(LootContextParams.TOOL);
        boolean ripe = state.getValue(AGE) >= MAX_AGE;
        boolean grassTool = tool != null && (tool.is(Items.SHEARS) || EnchantmentHelper.getItemEnchantmentLevel(Enchantments.SILK_TOUCH, tool) > 0);
        if (!ripe && !grassTool) return List.of();
        int n = ripe ? 3 + params.getLevel().getRandom().nextInt(3) : 1;
        Item item = fruitItem();
        if (item == Items.AIR) return List.of();
        return List.of(new ItemStack(item, n));
    }
}

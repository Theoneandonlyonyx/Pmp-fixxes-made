package net.mikexxx.pmpport;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Holder;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.BiomeTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.level.LevelEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.*;

/**
 * World-gen for the Plant Mega Pack port (1.20.1).
 *
 * Design goals from the user:
 * - Species-wise (latin-name base) biome nativity, not colour-split.
 *   Delphinium nudicaule / cardinale stay out of cold biomes; Delphinium elatum and
 *   Aquilegia alpina / canadensis / yellow cold-climate columbines prefer cold biomes.
 * - Cultivars DO spawn in the wild, but thinned: a biome does not get every colour of a species
 *   at once, and density is "visible but not inventory-full after two seconds".
 * - Fantasy pure-blue (and similar) flowers still appear in fitting biomes at normal rates.
 * - Multi-stage / two-block-tall plants spawn at random growth stages (not always fully grown).
 * - Mountable plants (epiphytes, bromeliads, orchids, pineapple-style) spawn on the sides of
 *   logs AND on the ground near tree logs (EpiphyteFloorBlock when available).
 */
@Mod.EventBusSubscriber(modid = PmpMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class PmpWorldGen {

    private static final List<String> LAND = new ArrayList<>();
    private static final List<String> EPIPHYTE = new ArrayList<>();
    private static final List<String> WATER = new ArrayList<>();
    private static boolean collected = false;

    // cold-climate species / id fragments (latin or id)
    private static final String[] COLD = {
            "delphinium_elatum", "delphinium_blue", "delphinium_purple", "delphinium_pink", "delphinium_white",
            "columbine_blue", "columbine_yellow", "wild_columbine", "aquilegia_alpina", "aquilegia_canadensis",
            "lupine", "mountain", "alpine", "king_of_the_alps", "gentian", "primula", "saxifrage", "edelweiss",
            "soldanella", "dryas", "silene", "campanula", "leucanthemum", "tulip"
    };

    // warm / mediterranean / California-style
    private static final String[] WARM = {
            "delphinium_nudicaule", "delphinium_cardinale", "delphinium_orange", "delphinium_red", "delphinium_yellow",
            "marigold", "celosia", "lantana", "brugmansia", "angel_s_trumpet", "canna", "hibiscus"
    };

    // tropical
    private static final String[] TROPICAL = {
            "anthurium", "orchid", "bromeliad", "pineapple", "heliconia", "costus", "calathea", "maranta",
            "alocasia", "colocasia", "monstera", "philodendron", "sealing_wax", "palm", "ginger", "banana"
    };

    // wet / aquatic
    private static final String[] WET = {
            "floating_", "immersed_", "water_lily", "water_lettuce", "duck_potato", "sedge", "cattail",
            "iris", "lobelia", "calla", "lotus", "nymphaea", "pontederia"
    };

    private PmpWorldGen() {}

    public static void init() {
        // nothing – we use the event subscriber
    }

    private static void collectIfNeeded() {
        if (collected) return;
        collected = true;
        LAND.clear();
        EPIPHYTE.clear();
        WATER.clear();
        for (var e : ForgeRegistries.BLOCKS.getEntries()) {
            ResourceLocation key = e.getKey().location();
            if (!PmpMod.MODID.equals(key.getNamespace())) continue;
            String id = key.getPath();
            Block b = e.getValue();
            if (b instanceof EpiphyteBlock || b instanceof EpiphyteFloorBlock
                    || id.startsWith("epiphyte_") || id.contains("bromeliad") || id.contains("orchid")
                    || id.contains("pineapple")) {
                EPIPHYTE.add(id);
            } else if (b instanceof WaterPlantBlock || b instanceof AquaPlantBlock
                    || id.startsWith("floating_") || id.startsWith("immersed_")) {
                WATER.add(id);
            } else if (b instanceof PlantBlock || b instanceof TallPlantBlock
                    || b instanceof HangingPlantBlock || b instanceof ClimbingPlantBlock) {
                LAND.add(id);
            }
        }
    }

    /**
     * We hook into chunk load / create so that when a new chunk is generated we sprinkle plants.
     * Using LevelEvent.CreateSpawnPosition is wrong; the reliable simple hook for "new terrain"
     * in modern Forge without a full Feature registration is to listen to the chunk load and
     * only act when the chunk is newly generated (status check). For a lightweight port we use
     * a decoration-style random on chunk load that only fires for chunks that still look empty
     * of our plants (idempotent enough for survival play).
     */
    @SubscribeEvent
    public static void onChunkLoad(net.minecraftforge.event.level.ChunkEvent.Load event) {
        if (event.getLevel().isClientSide()) return;
        if (!(event.getLevel() instanceof WorldGenLevel wgl)) return;
        if (wgl.getLevel().dimension() != net.minecraft.world.level.Level.OVERWORLD) return;

        // only decorate freshly generated chunks (status full or features)
        var chunk = event.getChunk();
        if (chunk.getStatus().getIndex() < net.minecraft.world.level.chunk.ChunkStatus.FEATURES.getIndex()) return;

        // cheap guard: if the chunk already has any of our blocks, skip (prevents re-decoration on reload)
        // (for a full port a proper Feature + PlacedFeature + biome modifier is better; this is pragmatic)
        RandomSource rnd = RandomSource.create(chunk.getPos().toLong() ^ wgl.getSeed() ^ 0xPMPLANTSL);
        // only a fraction of chunks get heavy decoration so density stays reasonable
        if (rnd.nextFloat() > 0.65f) return;

        collectIfNeeded();
        if (LAND.isEmpty() && EPIPHYTE.isEmpty() && WATER.isEmpty()) return;

        int cx = chunk.getPos().getMinBlockX();
        int cz = chunk.getPos().getMinBlockZ();
        BlockPos.MutableBlockPos mut = new BlockPos.MutableBlockPos();

        int attempts = 10 + rnd.nextInt(14); // 10-23 placement attempts per decorated chunk
        for (int i = 0; i < attempts; i++) {
            int x = cx + rnd.nextInt(16);
            int z = cz + rnd.nextInt(16);
            mut.set(x, 0, z);
            BlockPos surface = wgl.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, mut);
            if (surface.getY() <= wgl.getMinBuildHeight() + 4) continue;

            Holder<Biome> bh = wgl.getBiome(surface);
            float temp = bh.value().getBaseTemperature();
            boolean cold = temp < 0.3f || bh.is(BiomeTags.IS_TAIGA) || bh.is(BiomeTags.IS_MOUNTAIN);
            boolean tropical = bh.is(BiomeTags.IS_JUNGLE) || temp > 1.0f;
            boolean warm = temp > 0.85f && !tropical;
            boolean wet = bh.is(BiomeTags.IS_RIVER) || bh.value().getModifiedClimateSettings().downfall() > 0.75f;
            boolean dry = bh.value().getModifiedClimateSettings().downfall() < 0.15f;

            float roll = rnd.nextFloat();
            if (roll < 0.13f && !EPIPHYTE.isEmpty()) {
                tryEpiphyte(wgl, surface, rnd);
            } else if (roll < 0.28f && wet && !WATER.isEmpty()) {
                tryWater(wgl, surface, rnd);
            } else if (!LAND.isEmpty()) {
                String id = pick(rnd, cold, warm, tropical, dry, wet);
                if (id != null) tryLand(wgl, surface, id, rnd);
            }
        }
    }

    private static String pick(RandomSource rnd, boolean cold, boolean warm, boolean tropical, boolean dry, boolean wet) {
        List<String> bag = new ArrayList<>();
        for (String id : LAND) {
            String l = id.toLowerCase(Locale.ROOT);
            boolean ok = false;
            if (cold && containsAny(l, COLD)) ok = true;
            else if (tropical && containsAny(l, TROPICAL)) ok = true;
            else if (warm && containsAny(l, WARM)) ok = true;
            else if (wet && containsAny(l, WET)) ok = true;
            else if (!cold && !tropical && !dry) {
                // temperate: most flowers, but exclude the strongly cold / tropical ones unless lucky
                if (!containsAny(l, COLD) && !containsAny(l, TROPICAL)) ok = true;
                else if (rnd.nextFloat() < 0.25f) ok = true;
            }
            // fantasy blues / cyans always get a fair shot outside deserts
            if (!dry && (l.contains("_blue") || l.contains("cyan") || l.contains("turquoise") || l.contains("_blue_"))
                    && rnd.nextFloat() < 0.45f) {
                ok = true;
            }
            if (ok) bag.add(id);
        }
        if (bag.isEmpty()) {
            if (rnd.nextFloat() < 0.12f) return LAND.get(rnd.nextInt(LAND.size()));
            return null;
        }
        // secondary thinning: group roughly by species prefix so one patch does not dump every colour
        // (simple: just random among the climate bag – the climate filter already keeps density sane)
        return bag.get(rnd.nextInt(bag.size()));
    }

    private static boolean containsAny(String lower, String[] keys) {
        for (String k : keys) if (lower.contains(k)) return true;
        return false;
    }

    private static void tryLand(WorldGenLevel level, BlockPos surface, String id, RandomSource rnd) {
        Block block = ForgeRegistries.BLOCKS.getValue(new ResourceLocation(PmpMod.MODID, id));
        if (block == null || block == Blocks.AIR) return;
        BlockState below = level.getBlockState(surface.below());
        if (!(below.is(BlockTags.DIRT) || below.is(Blocks.GRASS_BLOCK) || below.is(Blocks.PODZOL)
                || below.is(Blocks.MYCELIUM) || below.is(Blocks.MOSS_BLOCK) || below.is(Blocks.MUD))) return;
        if (!level.isEmptyBlock(surface) && !level.getBlockState(surface).canBeReplaced()) return;

        BlockState state = block.defaultBlockState();
        // random growth stage
        if (state.hasProperty(PlantBlock.STAGE)) {
            int max = PlantBlock.STAGE.getPossibleValues().stream().mapToInt(Integer::intValue).max().orElse(3);
            int stage = rnd.nextInt(max + 1);
            state = state.setValue(PlantBlock.STAGE, stage);
        }
        if (state.hasProperty(TallPlantBlock.STAGE)) {
            int stage = rnd.nextInt(4);
            state = state.setValue(TallPlantBlock.STAGE, stage);
        }
        if (state.canSurvive(level, surface)) {
            level.setBlock(surface, state, 2);
            if (block instanceof TallPlantBlock) {
                level.scheduleTick(surface, block, 1); // let it grow segments / fix shape
            }
        }
    }

    private static void tryEpiphyte(WorldGenLevel level, BlockPos surface, RandomSource rnd) {
        // search for a log nearby
        for (int t = 0; t < 14; t++) {
            BlockPos p = surface.offset(rnd.nextInt(9) - 4, rnd.nextInt(6) - 1, rnd.nextInt(9) - 4);
            if (!level.getBlockState(p).is(BlockTags.LOGS)) continue;
            Direction[] dirs = {Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST};
            Direction d = dirs[rnd.nextInt(4)];
            BlockPos side = p.relative(d);
            if (!(level.isEmptyBlock(side) || level.getBlockState(side).canBeReplaced())) continue;
            String id = EPIPHYTE.get(rnd.nextInt(EPIPHYTE.size()));
            Block block = ForgeRegistries.BLOCKS.getValue(new ResourceLocation(PmpMod.MODID, id));
            if (block instanceof EpiphyteBlock) {
                BlockState s = block.defaultBlockState().setValue(EpiphyteBlock.FACING, d);
                if (s.canSurvive(level, side)) {
                    level.setBlock(side, s, 2);
                    return;
                }
            }
            // also allow floor epiphyte right next to the log base
            BlockPos floor = new BlockPos(p.getX(), surface.getY(), p.getZ());
            if ((level.isEmptyBlock(floor) || level.getBlockState(floor).canBeReplaced())
                    && level.getBlockState(floor.below()).is(BlockTags.DIRT)) {
                if (block != null) {
                    level.setBlock(floor, block.defaultBlockState(), 2);
                    return;
                }
            }
        }
        // occasional ground epiphyte under canopy even without exact log
        if (rnd.nextFloat() < 0.35f) {
            String id = EPIPHYTE.get(rnd.nextInt(EPIPHYTE.size()));
            Block block = ForgeRegistries.BLOCKS.getValue(new ResourceLocation(PmpMod.MODID, id));
            if (block != null && (block instanceof EpiphyteFloorBlock || !(block instanceof EpiphyteBlock))) {
                if ((level.isEmptyBlock(surface) || level.getBlockState(surface).canBeReplaced())
                        && level.getBlockState(surface.below()).is(BlockTags.DIRT)) {
                    level.setBlock(surface, block.defaultBlockState(), 2);
                }
            }
        }
    }

    private static void tryWater(WorldGenLevel level, BlockPos surface, RandomSource rnd) {
        for (int t = 0; t < 10; t++) {
            BlockPos p = surface.offset(rnd.nextInt(11) - 5, 0, rnd.nextInt(11) - 5);
            BlockPos w = p;
            while (w.getY() > level.getMinBuildHeight() && level.getBlockState(w).getFluidState().isEmpty()) {
                w = w.below();
            }
            if (level.getBlockState(w).getFluidState().isEmpty()) continue;
            BlockPos place = w.above();
            if (!level.isEmptyBlock(place)) continue;
            String id = WATER.get(rnd.nextInt(WATER.size()));
            Block block = ForgeRegistries.BLOCKS.getValue(new ResourceLocation(PmpMod.MODID, id));
            if (block == null) return;
            BlockState state = block.defaultBlockState();
            if (state.hasProperty(PlantBlock.STAGE)) {
                state = state.setValue(PlantBlock.STAGE, rnd.nextInt(4));
            }
            if (state.canSurvive(level, place)) {
                level.setBlock(place, state, 2);
                return;
            }
        }
    }
}
